# Matching rules and discrepancy taxonomy

This document describes exactly how the engine links records and decides
statuses, so a reviewer can challenge or tune it.

## 1. Pipeline order

1. **Exact identifiers**
   - invoice number → register invoice number, paired by description when one
     invoice contains several assets;
   - asset code → inventory, register, invoice line, GL;
   - serial number → inventory ↔ register.
2. **Fuzzy physical ↔ register**
   - description, brand, quantity.
3. **Fuzzy register ↔ invoice**
   - description, brand, quantity, amount, date.
4. **Fuzzy physical ↔ invoice** for items with no register row (completeness
   gap).
5. **Cluster assembly** with union-find.
6. **GL attachment** at invoice level and by asset code.
7. **Rules and status**.

Exact keys always win. A fuzzy link never overrides an exact link.

## 2. Exact keys

| Link | Key | Notes |
| --- | --- | --- |
| Invoice line ↔ register | `invoice_number` | If the invoice has several lines and the register several rows, pair greedily by description similarity |
| Inventory ↔ register | `asset_code` | Same code = same asset |
| Inventory ↔ register | `serial_number` | Serial must be at least 4 characters |
| Inventory ↔ invoice | `asset_code` | Only if the invoice prints the client's code |
| Register ↔ GL | `asset_code` | GL may also reference the invoice |
| Invoice ↔ GL | `invoice_number` / `document_ref` | Attached as evidence, not used to merge clusters |

Invoice-number pairing inside a multi-asset invoice uses description
similarity and a one-to-one greedy assignment, with a 0.96 floor because the
invoice number itself is strong evidence.

## 3. Fuzzy score

For a pair of records, each available component returns a score in [0, 1].
Missing components are excluded, then the weighted average is multiplied by an
**evidence coverage** factor:

```
score = (Σ weight_i × component_i / Σ weight_i) × (0.85 + 0.15 × coverage)
coverage = Σ weights of present components / Σ all weights
```

Two guards prevent thin evidence from becoming a match:

- fewer than two present components → score capped at 0.60;
- description similarity below 0.45 → score capped at 0.55.

### Weight profiles

| Pair | Description | Brand | Quantity | Amount | Date | Supplier |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Inventory ↔ register | 0.55 | 0.25 | 0.20 | — | — | — |
| Inventory ↔ invoice | 0.45 | 0.20 | 0.25 | — | 0.10 | — |
| Register ↔ invoice | 0.35 | 0.15 | 0.15 | 0.25 | 0.10 | — |
| GL ↔ register | 0.45 | — | — | 0.40 | 0.15 | — |
| GL ↔ invoice | 0.25 | — | — | 0.35 | 0.25 | 0.15 |

### Components

**Description** — blended token containment and sequence similarity after
synonym expansion. Extra words are tolerated; different products are not.

**Brand** — exact canonical brand = 1.0; containment (e.g. `HP` in
`HP INC`) = 0.80; different = 0; missing on one side = neutral (component
excluded).

**Quantity** — equal = 1.0; one side is 1 and the other >1 = 0.90
("grouping possible"); otherwise 0. The group is checked later, so a single
chair can link to a 10-chair invoice line and the shortfall is reported.

**Amount** — within tolerance = 1.0; consistent with 18% or 20% VAT = 0.80;
within 5% = 0.55; within 15% = 0.25; otherwise 0.

**Date** — absolute difference ≤30 days = 1.0; ≤90 = 0.75; ≤180 = 0.45;
≤365 = 0.20; otherwise 0.

**Supplier** — text similarity ≥0.85 = 1.0; ≥0.60 = 0.60; otherwise 0.

### Thresholds

| Threshold | Default | Effect |
| --- | ---: | --- |
| `auto_match_threshold` | 0.88 | Link accepted automatically |
| `review_match_threshold` | 0.72 | Candidate shown in the review queue |
| `manual_review_score` | 0.93 | A cluster whose weakest link is below this is flagged `AMBIGUOUS_MATCH` |
| `amount_tolerance_abs` | 1,000 FCFA | Absolute amount tolerance |
| `amount_tolerance_pct` | 0.5% | Relative amount tolerance |
| `min_extraction_confidence` | 0.75 | Below this, line goes to manual review |

Tune thresholds only after measuring on a labelled sample. Lowering the auto
threshold below 0.85 increases false links faster than it reduces manual work.

## 4. Blocking

Comparing every pair is quadratic. Candidate pairs are generated through
blocking keys:

- brand (`B:`);
- first and second description token (`T:`, `T2:`);
- supplier first word (`F:`);
- asset code (`C:`);
- site (`S:`);
- amount bucket (`A:`, rounded to 1,000);
- year (`Y:`).

If a record has no usable block key and the other side has ≤1,500 rows, the
engine falls back to all pairs. Large candidate sets are narrowed to shared
brand/code blocks. This keeps a 5,000-asset file tractable while preserving
recall on sparse records.

## 5. Assignment and quantity grouping

The engine does not simply union every accepted pair.

- An **inventory item** belongs to at most one cluster.
- A **register asset** is linked to at most one invoice line in this model.
- An **invoice line** can link to several register rows or several physical
  rows, but only up to its quantity budget. This is how "10 chairs" works.
- GL entries are attached after clustering and never merge clusters, because
  one posting often covers a whole invoice.

Example: invoice line quantity 10, register row quantity 10, eight inventory
rows of 1. The eight inventory rows link to the register row; the invoice line
links to the register row; the cluster has quantities 8 / 10 / 10 and reports
`QTY_MISMATCH` with expected 10, observed 8.

If a line has quantity 10 and only 6 physical rows are found, the cluster
reports the 4 missing units. If 12 rows are found, it reports an excess of 2.

## 6. Duplicates

| Code | Test |
| --- | --- |
| `DUPLICATE_INVOICE` | Same supplier + invoice number in two different scan files |
| `POSSIBLE_DUPLICATE_INVOICE` | Same supplier, amount within 0.1%, date within 3 days, description similarity ≥0.90, different invoice numbers |
| `DUPLICATE_REGISTER_ASSET` | Same asset code twice in the register |
| `DUPLICATE_SERIAL` | Same serial twice **inside one source** (same serial in inventory and register is a match, not a duplicate) |
| `DUPLICATE_GL` | Same entry ID twice |

Duplicate invoice lines are excluded from matching and reported separately, so
a double scan does not create a phantom asset. The duplicate file remains in
the extraction journal.

## 7. Discrepancy codes

Severity: **H** = affects existence, completeness or value; **M** = accounting
or cut-off issue requiring explanation; **L** = presentation/variance to
confirm.

| Code | Sev. | Meaning | Typical cause | Resolution |
| --- | --- | --- | --- | --- |
| `INV_NOT_IN_REGISTER` | H | Physical asset absent from register | Unrecorded purchase, code missing, register incomplete | Add to register or document disposal |
| `REGISTERED_NOT_FOUND` | H | Register asset not counted | Lost, stolen, transferred, scrapped, wrong site | Locate, write off, or document |
| `NO_INVOICE` | H | Asset without supporting invoice | Missing scan, pre-period purchase, self-constructed asset | Obtain invoice or alternative evidence |
| `INVOICE_NOT_IN_GL` | H | Invoice not posted to fixed-asset accounts | Cut-off, posted to expense, manual entry pending | Find posting or regularise |
| `REGISTER_WITHOUT_GL` | H | Register asset without ledger entry | Register maintained outside accounting | Reconcile register to GL |
| `GL_WITHOUT_ASSET` | H | Ledger entry without an identified asset | Expense capitalised, wrong account, asset not tagged | Identify asset or reclassify |
| `ASSET_NOT_IDENTIFIED` | H | Invoice with no asset in register or inventory | Consumable, service, low-value item, missing code | Identify or expense |
| `QTY_MISMATCH` | H | Quantities differ across sources | Partial delivery, theft, split rows, lot | Recount and correct the source |
| `AMOUNT_MISMATCH` | H | Invoice line total ≠ register cost | VAT, freight, discount, error | Confirm basis and correct |
| `GL_AMOUNT_MISMATCH` | H | Invoice total ≠ GL debit | Partial posting, VAT, multiple invoices | Reconcile the posting |
| `INVOICE_ARITHMETIC` | M | Quantity × unit price ≠ line total | Supplier error, discount, rounding | Confirm with supplier |
| `INVOICE_TOTAL_MISMATCH` | M | Sum of lines ≠ invoice total | Missing line, freight, discount | Check extraction and invoice |
| `DATE_BEFORE_INVOICE` | M | Acquisition date >30 days before invoice | Advance payment, wrong date | Confirm entry date |
| `LATE_CAPITALISATION` | M | In service >90 days after invoice | Asset received but not commissioned | Check depreciation start |
| `LATE_POSTING` | M | GL entry >60 days after invoice | Manual posting, cut-off | Check period |
| `CUTOFF_YEAR` | M | Invoice and GL entry in different fiscal years | Year-end lag | Analyse cut-off |
| `DESC_VARIANCE` | L | Descriptions differ materially | Different labels across departments | Confirm same asset |
| `BRAND_MISMATCH` | L | Brands differ | Data entry, rebranding, wrong model | Confirm brand |
| `MODEL_MISMATCH` | L | Models differ | Variant or error | Confirm reference |
| `SITE_MISMATCH` | L | Register site ≠ count site | Transfer not recorded | Update register |
| `STATUS_MISMATCH` | M | Disposed asset still counted, or active status with disposal date | Late update | Correct status |
| `PRE_PERIOD_ASSET` | L | Acquired before the audit period | Register includes older assets | Confirm scope |
| `OUT_OF_PERIOD` | L | Date outside the audit period | Scope or data error | Confirm period |
| `LOW_CONFIDENCE_EXTRACTION` | M | Scan confidence below threshold | Poor scan, handwriting | Re-read and correct |
| `MISSING_CRITICAL_FIELD` | M | Required field empty | Extraction or client data gap | Complete from source |
| `AMBIGUOUS_MATCH` | M | Weakest link below 0.93 | Similar assets, sparse data | Accept/reject in review |
| `UNMATCHED_INVOICE_LINE` | M | Invoice line with no asset | Consumable, service, missing register | Identify or expense |
| `UNMATCHED_GL_ENTRY` | M | GL entry with no asset | Manual entry, wrong account | Identify or reclassify |
| `INTANGIBLE_NO_PHYSICAL` | L | Intangible asset with no physical count | Software, licence | Verify title/licence instead |

## 8. Status decision

```
if only an invoice line                      → UNMATCHED_INVOICE
elif no asset and no invoice                 → UNMATCHED_GL
elif a blocking high-severity code exists    → DISCREPANCY
elif only missing-document codes             → MISSING_DOCUMENT
elif asset lacks invoice or GL               → MISSING_DOCUMENT
elif only low/medium variance codes          → PARTIALLY_RECONCILED
else                                         → FULLY_RECONCILED
```

`NO_INVOICE`, `INVOICE_NOT_IN_GL` and `REGISTER_WITHOUT_GL` are "missing
document" codes, not existence discrepancies. If an existence or value issue
coexists, the status is `DISCREPANCY`.

An intangible asset with matching invoice, register and GL, and no physical
count, is `FULLY_RECONCILED` with an informational
`INTANGIBLE_NO_PHYSICAL` code.

The **manual review flag** is set for:

- low-confidence extraction;
- missing critical fields;
- ambiguous match (weakest link <0.93);
- unmatched invoice or GL;
- any `MISSING_DOCUMENT` status.

## 9. Global tie-out

The dashboard compares, by fiscal year:

- total invoice amounts (unique invoice headers);
- total register acquisition cost;
- total GL debits.

Differences are not automatically errors: they reveal cut-off, missing
documents and amount variances. A difference must be explainable by the
findings in `03_Ecarts`; an unexplained difference is a scope or completeness
issue.

## 10. Edge cases and how they are handled

| Case | Handling |
| --- | --- |
| Intangible asset (software, licence) | Excluded from physical existence; `INTANGIBLE_NO_PHYSICAL` |
| Disposed asset still counted | `STATUS_MISMATCH` |
| Asset acquired before the period | `PRE_PERIOD_ASSET`; invoice not required in period |
| Same asset at two sites | Site mismatch, one cluster if descriptions/codes match |
| One invoice, several assets | Lines paired to register rows by description; one cluster per asset group |
| Several invoices for one asset | Register row links to one invoice; the others appear as unmatched invoice lines to review |
| One register row for a lot | Quantity compared at group level |
| GL posting for a whole invoice | Attached to every cluster of that invoice; amount compared at header level |
| VAT included in register, excluded on invoice | Amount component tests ×1.18/÷1.18 |
| Credit note | Keep separate, negative amount; do not net automatically |
| Foreign currency | Convert before loading and document the rate |
| Same serial in inventory and register | Match, not duplicate |
| Generic description (`Ordinateur`) | Low description specificity; likely review, not auto-match |
| Missing brand | Neutral, lowers coverage, may fall below auto threshold |
| Duplicate scan | Excluded from matching, reported in duplicates |

## 11. Tuning and validation

Build a labelled sample before changing thresholds:

1. Take 50–100 assets and 15–30 invoices from a real mission.
2. Label each true link and each expected discrepancy.
3. Run the engine.
4. Measure:
   - **match precision** = correct auto links / all auto links;
   - **match recall** = true pairs auto-linked / all true pairs;
   - **discrepancy precision/recall** by code;
   - **review rate** = items in the review queue / all items.
5. Target precision above 95% on auto links. Recall can be lower because the
   review queue catches the rest; a false link is more expensive than a missed
   link.
6. Improve normalization and aliases before touching thresholds. Most misses
   are vocabulary problems, not score problems.
7. Version every threshold change in the run log.

## 12. Worked example: the 10 chairs

**Sources**

- Invoice `FAC-2022-007`, one line: "Chaise bureau ergonomique", qty 10,
  unit 120,000, total 1,200,000.
- Register `IMM-004`: "Chaise de bureau ergonomique", qty 10, cost 1,200,000,
  invoice `FAC-2022-007`.
- Inventory: eight rows `IMM-004-01` … `IMM-004-08`, qty 1 each.

**Matching**

- Invoice ↔ register: exact invoice number → 1.0.
- Inventory ↔ register: description ≈1.0, brand 1.0, qty 1 vs 10 → 0.90
  component → score ≈0.98; all eight rows link to the same register row.
- Cluster: inventory 8, register 10, invoice 10.

**Result**

```
Status: DISCREPANCY
Code: QTY_MISMATCH (H)
Expected: facture 10 / registre 10
Observed: inventaire 8
Action: recompter, vérifier la ventilation, corriger la source erronée
```

Two chairs are not invented, and the file does not silently pass because the
register and invoice agree with each other. The physical count is the third
witness.
