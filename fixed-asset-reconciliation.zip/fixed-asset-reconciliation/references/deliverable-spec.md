# Deliverable specification

The output is an audit working paper, not a dashboard demo. It must let a
reviewer answer, for any asset: **what do the four sources say, what did the
tool match, what is wrong, what is the evidence, and what did the auditor
decide?**

## 1. Workbook structure

File: `rapprochement_immobilisations_YYYYMMDD_HHMM.xlsx`

| Sheet | Purpose |
| --- | --- |
| `00_Lisez-moi` | Scope, sources, hashes, thresholds, method, limitations |
| `01_Tableau_de_bord` | KPIs, status distribution, tie-out by fiscal year, top codes, site/family |
| `02_Rapprochement` | One row per asset group, four sources side by side |
| `03_Ecarts` | One row per finding, with expected/observed and evidence |
| `04_Verification_manuelle` | Review queue with suggested matches and decision columns |
| `05_Doublons` | Duplicate invoices, asset codes, serials, GL entries |
| `06_Factures_non_rapprochees` | Invoices and GL entries without an asset |
| `07_Qualite_donnees` | Import anomalies |
| `08_Journal_extraction` | Invoice line provenance and confidence |
| `09_Tracabilite` | Run metadata, file hashes, parameters |

CSV exports in the same folder: `ecarts.csv`, `verification_manuelle.csv`,
`factures_non_rapprochees.csv`, `ecritures_non_rapprochees.csv`,
`doublons.csv`. Semicolon-separated, UTF-8 BOM, for Excel compatibility.

## 2. `02_Rapprochement` columns

Seven fixed columns, then a nine-column block per source.

| Column | Content |
| --- | --- |
| `ID` | Cluster ID (`R0001`) |
| `Statut` | Status label |
| `Score` | Weakest link score in the cluster, 0–100% |
| `Sources` | Number of sources present (0–4) |
| `Codes d'écart` | Semicolon/pipe-separated codes |
| `Vérif. manuelle` | Oui / Non |
| `Action prioritaire` | Action of the most severe code |

Each source block (`Inventaire physique`, `Factures`, `Registre`,
`Grand livre`) has:

`Présent`, `Référence`, `Désignation`, `Marque`, `Qté`, `Montant`, `Date`,
`Site / pièce`, `Fichier / ligne`.

Rules:

- `Présent` is `Oui` if at least one record of that source is in the cluster.
- Multiple records in a source are joined with ` | ` and truncated with
  `(+N)`; the full list is in the evidence column of `03_Ecarts`.
- `Montant` for inventory is blank: a count sheet does not carry cost. That is
  not missing data to fix.
- `Date` is the count date for inventory, invoice date for invoices,
  acquisition date for the register, entry date for the GL.
- `Fichier / ligne` points to the workbook row; invoice lines also carry the
  scan file and page in `08_Journal_extraction`.
- Freeze panes at `C3`, autofilter on the header row, source blocks colour-coded.

Do not edit generated columns. If a match is wrong, record the decision in
`04_Verification_manuelle` or `03_Ecarts` and rerun with a correction; do not
overwrite the evidence.

## 3. `03_Ecarts` columns

`ID écart`, `Code`, `Libellé`, `Sévérité`, `Statut`, `Actif`, `Cluster`,
`Source(s)`, `Attendu`, `Constaté`, `Détail`, `Preuve (fichier / ligne)`,
`Action suggérée`, `Décision`, `Commentaire auditeur`.

- One row per code occurrence, not one per asset.
- Sorted by severity then cluster.
- `Attendu` / `Constaté` carry the comparable values (quantity, amount, date,
  site). For existence findings they are `1` / `0`.
- `Preuve` lists file and row for each source record.
- `Décision` is filled by the auditor: `Confirmé`, `Corrigé`, `Justifié`,
  `À obtenir`, `Faux positif`.
- `Commentaire` explains the resolution and the client response.

## 4. `04_Verification_manuelle` columns

`Cluster`, `Actif`, `Statut`, `Raison`, `Codes`, `Score`, `Sources`,
`Correspondances proposées`, `Décision`, `Commentaire`.

`Correspondances proposées` lists the top candidates (source, ID, description,
score) from the 0.72–0.88 band or the GL review band. `Décision` is a
data-validation list: `À vérifier`, `Validé`, `Rejeté`.

A validated suggestion does not automatically rewrite the cluster; it is
evidence for the auditor's conclusion. If the suggestion is correct, add the
alias/description to the normalization table or correct the source data and
rerun.

## 5. Status definitions

| Status | Definition | Sign-off |
| --- | --- | --- |
| `FULLY_RECONCILED` | Four sources present and consistent within tolerance | Sample check |
| `PARTIALLY_RECONCILED` | Minor variance only (description, brand, site, date, cut-off) | Confirm and document |
| `DISCREPANCY` | Existence, quantity or amount issue | Investigate, client response |
| `MISSING_DOCUMENT` | Asset or invoice lacks a document or ledger entry | Obtain or justify |
| `MANUAL_REVIEW` | Ambiguous match or low-confidence extraction | Accept/reject |
| `UNMATCHED_INVOICE` | Invoice line without an asset | Identify or expense |
| `UNMATCHED_GL` | GL entry without an asset | Identify or reclassify |

A `FULLY_RECONCILED` row is not an audit conclusion; it means the documents
agree. Existence, ownership and valuation still require audit procedures.

## 6. Dashboard

- KPI block: clusters, statuses, manual review, value tracked, value not
  reconciled, high-severity findings, duplicates.
- **Tie-out by fiscal year**: invoice total, register cost, GL debits, and the
  two differences. This is the first thing a reviewer reads.
- Status distribution with values.
- Top discrepancy codes.
- Distribution by site and family (count and value).

Caveats to state in the narrative:

- invoice totals are unique invoice headers (duplicates excluded);
- register cost includes pre-period assets if the register does;
- GL debits include non-asset entries if the extract does;
- the tie-out is a completeness indicator, not a proof.

## 7. Review workflow

1. **Preparer** runs the engine, checks data quality and extraction coverage,
   resolves obvious extraction errors, then clears the review queue.
2. **Reviewer** samples `FULLY_RECONCILED` rows (at least 10%, minimum 5),
   reviews all high-severity findings, and challenges every auto-match with a
   score below 0.95.
3. **Manager** reviews the tie-out, the high-severity summary, the limitations
   and the client requests before the report is issued.
4. **Client** responds to the open items; responses are recorded in the
   `Commentaire` column with a date and an owner.
5. **Archive** the workbook, the extraction file, the manifest and the source
   hashes together.

Four-eyes is mandatory for:

- any asset above the materiality threshold;
- any `DISCREPANCY` with value impact;
- any manual override of an automatic match;
- any change to thresholds or normalization during the mission.

## 8. Evidence and retention

Keep:

- the original four source files and the invoice folder (read-only);
- SHA-256 hashes (in `09_Tracabilite`);
- the extraction file with confidence and page references;
- the run configuration (thresholds, period, currency);
- the workbook with decisions and comments;
- the client's written responses.

Do not keep only the final workbook: it cannot be re-performed without the
inputs and the extraction file.

Retention follows the firm's policy and local regulation. Invoices contain
supplier data and possibly personal data; apply access control and encryption.

## 9. Narrative template

```
RAPPROCHEMENT DES IMMOBILISATIONS — [CLIENT] — [PÉRIODE]

1. Périmètre
   Sources reçues, sites, exercices, devise, seuils, exclusions.

2. Méthode
   Ingestion, extraction (nombre de factures/pages, confiance moyenne),
   normalisation, rapprochement exact puis flou, règles d'écart.

3. Résultats
   Nombre d'actifs suivis, valeur brute, % rapprochés, écarts par sévérité,
   tie-out par exercice.

4. Principaux constats
   5 à 10 constats, chiffrés, avec code, actif, source et action.

5. Limites
   Pages manquantes, scans illisibles, registre incomplet, périmètre,
   factures hors période, changes.

6. Demandes au client
   Liste actionnable: document, confirmation, correction, responsable, échéance.

7. Conclusion
   Ce qui est rapproché, ce qui reste ouvert, ce qui nécessite un
   approfondissement (existence, valorisation, dépréciation).
```

## 10. Presentation rules

- Amounts in FCFA with thousands separators; no decimals unless the source has
  them.
- Dates `DD/MM/YYYY`.
- Scores as percentages, with the components available in the evidence.
- One colour code for statuses, one for severity; do not rely on colour alone
  (the label is always present).
- No hidden rows or columns in the delivered file.
- Protect the workbook structure, not the decision columns, if it is shared.
- A PDF export is a snapshot; the `.xlsx` remains the working paper.
