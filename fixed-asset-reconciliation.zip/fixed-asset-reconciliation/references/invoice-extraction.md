# Invoice extraction protocol

The invoice is the weakest link in fixed-asset reconciliation: if a line is
missed or misread, no matching rule can recover it. This protocol is written
for the agent acting as the OCR/IDP layer, and for a developer wiring a vision
model or document-intelligence API.

## 1. What "extraction" means here

For every purchase invoice, produce:

- **header**: invoice number, supplier, invoice date, delivery date, currency,
  total excl. tax, tax, total incl. tax, payment terms, purchase order;
- **one row per line**: line number, description, brand, model, quantity, unit,
  unit price, discount, line total excl. tax, tax rate, asset code if printed;
- **provenance**: source file, page, extraction confidence, reviewer status;
- **flags**: illegible field, missing page, credit note, delivery note,
  duplicate, arithmetic inconsistency.

Do not produce a single "invoice total" row. Fixed-asset matching happens at
line level.

## 2. Triage first

Run the manifest:

```sh
python3 reconcile.py manifest ./factures -o manifeste_factures.csv
```

Classify each file:

| Type | What to do |
| --- | --- |
| `pdf_texte` | Extract text, but verify table layout and line breaks |
| `pdf_scan` | Read page by page with vision; check rotation and contrast |
| `image` | Read with vision; check crop, blur, flash reflection |
| encrypted / damaged | List as exception; request a readable copy |
| exact duplicate hash | Extract once; flag the duplicate file |
| multi-invoice PDF | Split by invoice number/date; record the page range |
| invoice + delivery note + PO in one PDF | Extract only the invoice; flag the others |
| credit note / proforma | Flag; do not treat as a purchase invoice |

A 300-page PDF is not one invoice. A 2-page invoice with a page break in the
middle of the line table is one invoice.

## 3. Reading rules

### Header

- **Invoice number**: exactly as printed, including prefixes and slashes.
  Do not normalize during extraction. `FAC/2024/001` stays as printed.
- **Supplier**: the issuer (the entity that sold), not the customer. On a
  French invoice, the supplier is usually top-left with the tax ID; the
  customer is "Facturé à" / "Client".
- **Invoice date**: the issue date, not the delivery date or the due date.
- **Delivery date**: only if explicitly printed ("Date de livraison",
  "Livré le", "BL n° ... du ..."). Do not infer it from the invoice date.
- **Currency**: `FCFA`, `XOF`, `EUR`, `USD`. If absent, use the client's
  currency and flag it.
- **Totals**: copy the printed totals. If the invoice shows only TTC, leave
  HT blank and flag it; do not divide by 1.18 silently.

### Lines

- One row per printed line. Do not merge similar lines; the auditor may need
  the split.
- **Description**: copy the printed wording, including abbreviations. Do not
  translate or "clean" it. Normalization happens later.
- **Brand**: only if printed in the line or clearly in the product reference.
  Do not infer a brand from the supplier name.
- **Model**: printed reference, part number or model.
- **Quantity**: the billed quantity. Watch for `10 U`, `10,00`, `10 pcs`,
  `1 lot de 10`. If it is a lot, keep `1` and put `lot de 10` in the
  description; flag the interpretation.
- **Unit price**: price per unit, excluding tax if the invoice distinguishes
  HT/TTC. If only a line total is printed, leave unit price blank.
- **Line total**: the printed line amount. If there is a discount column, the
  line total is after discount; record the discount separately if visible.
- **Tax**: tax rate or amount per line if printed. Otherwise use the header
  total.
- **Asset code**: only if the invoice itself references the client's asset or
  PO. Never copy the register code onto the invoice.

### Multi-page and multi-line

- Repeat header fields on every line row (the schema is flat).
- Record the page where the line appears.
- If a line continues across a page break, create one row and note the page
  range in `source_page` (e.g. `2-3`).
- If the same invoice appears twice in the folder, extract one and mark the
  other as duplicate.

### Handwriting, stamps and poor scans

- A handwritten invoice is valid evidence if legible; set confidence ≤ 0.75
  and `review_status = "À relire"`.
- A "PAYÉ" / "ACQUITTÉ" stamp does not change the amounts; note it.
- A supplier stamp can confirm the supplier name when the letterhead is
  unclear; record the source of the name in a comment.
- If a digit is ambiguous (`3` vs `8`, `1` vs `7`), do not choose silently:
  put the most likely value, set confidence below 0.75, and flag it.
- If a page is missing or unreadable, stop and list the invoice as incomplete.
  Do not reconstruct totals from other documents.

## 4. Confidence rubric

| Situation | Confidence |
| --- | --- |
| Typed PDF with a clean text layer, values read directly | 0.97–1.00 |
| Clear scan, all fields legible, arithmetic consistent | 0.90–0.96 |
| Readable scan, some noise or a small ambiguity resolved by arithmetic | 0.80–0.89 |
| Handwritten, stamped, rotated or partially obscured; plausible reading | 0.65–0.79 |
| Significant uncertainty, missing page, contradictory totals | < 0.65 |

Confidence is per line, not per invoice. A clean header with an illegible line
gets a low confidence on that line only.

Below `min_extraction_confidence` (default 0.75), the line enters the manual
review queue and any asset it touches is flagged
`LOW_CONFIDENCE_EXTRACTION`.

## 5. Validation before matching

Run:

```sh
python3 reconcile.py check-invoices ./factures_extraites.xlsx
```

Checks:

1. **Required columns** present.
2. **Required values** on every line: invoice number, supplier, date,
   description, quantity, line total.
3. **Arithmetic**: `quantity × unit_price ≈ line_total` (tolerance 0.1% or
   2 FCFA).
4. **Header total**: `sum(line_total) ≈ invoice_total` (tolerance 1% or
   1,000 FCFA).
5. **Dates**: invoice date ≤ delivery date is not required, but a delivery
   date far before the invoice date is suspicious; report it.
6. **Duplicates**: same supplier + invoice number in two files; identical file
   hashes.
7. **Confidence**: numeric, 0–1, and below-threshold lines listed.
8. **Coverage**: every page in the manifest appears in the extraction journal.

An arithmetic error is a finding about the invoice, not an instruction to
change the numbers. Record the printed values and flag the inconsistency.

## 6. Vision prompt for a developer

Use a schema-constrained call. Temperature 0. Do not let the model "fix"
arithmetic. Ask for `null` when a field is absent or illegible.

```text
You extract purchase invoices for a fixed-asset audit.
Read the attached document page by page. Return JSON only.

Rules:
- Copy text exactly as printed; do not translate, correct or normalise.
- The supplier is the issuer of the invoice, not the customer.
- One object per printed invoice line. Do not merge lines.
- Use null for any field that is absent, illegible or not printed.
- Never compute a missing value from another value, except:
  line_total = quantity * unit_price when the line total is not printed;
  in that case set "computed": true on the line.
- Keep the printed invoice number, including prefixes and separators.
- Set confidence per line: 0.97+ typed text, 0.90-0.96 clear scan,
  0.75-0.89 noisy but readable, below 0.75 manual review.
- If the document is a credit note, delivery note or proforma, set
  document_type accordingly and still extract its lines.
- If a page is missing or unreadable, add it to "issues" and do not guess.

JSON schema:
{
  "document_type": "invoice|credit_note|delivery_note|proforma|other",
  "invoice_number": string|null,
  "supplier": string|null,
  "supplier_tax_id": string|null,
  "invoice_date": "YYYY-MM-DD"|null,
  "delivery_date": "YYYY-MM-DD"|null,
  "currency": string|null,
  "po_number": string|null,
  "subtotal": number|null,
  "tax_amount": number|null,
  "total": number|null,
  "lines": [
    {
      "line_no": string|null,
      "description": string,
      "brand": string|null,
      "model": string|null,
      "quantity": number|null,
      "unit": string|null,
      "unit_price": number|null,
      "discount": number|null,
      "line_total": number|null,
      "tax_rate": number|null,
      "asset_code": string|null,
      "page": number,
      "confidence": number,
      "computed": boolean,
      "notes": string|null
    }
  ],
  "issues": [string]
}
```

Post-process the JSON, do not trust it blindly:

- reject lines with an empty description;
- recompute arithmetic and record mismatches;
- compare the header total to the sum of lines;
- check that every page number is within the PDF page count;
- cap confidence at 0.90 when the line was computed rather than printed;
- store the model name/version and prompt version in the run log.

## 7. Example row

```json
{
  "invoice_number": "FAC-2024-019",
  "supplier": "BUREAU PLUS",
  "invoice_date": "2024-06-18",
  "delivery_date": "2024-06-20",
  "description": "Imprimante multifonction EPSON L3150",
  "brand": "EPSON",
  "model": "L3150",
  "quantity": 1,
  "unit_price": 185000,
  "line_total": 185000,
  "invoice_total": 605000,
  "currency": "FCFA",
  "line_no": "1",
  "source_file": "scan_fac_2024_019.pdf",
  "source_page": 1,
  "extraction_confidence": 0.93,
  "review_status": "Relu"
}
```

## 8. Quality metrics to report

| Metric | Target |
| --- | --- |
| Page coverage (pages processed / pages in manifest) | 100%, exceptions listed |
| Critical-field completeness | ≥ 98% |
| Arithmetic consistency | ≥ 99% |
| Duplicate detection | 100% of exact hash duplicates |
| Low-confidence lines reviewed | 100% |
| Lines with `source_file` + `source_page` | 100% |

Report these in `08_Journal_extraction` and in the narrative. A reconciliation
built on 70% of the invoice pages is not a reconciliation; it is a sample.

## 9. Common traps

- **Supplier vs customer**: the biggest header error. Check the tax IDs and
  the "Facturé à" block.
- **Invoice number vs PO number**: do not put the PO in `invoice_number`.
- **HT vs TTC**: a register cost often includes VAT while a line total is HT.
  The matcher tests ×1.18/÷1.18, but the auditor must confirm the basis.
- **Discounts and freight**: a line total after discount plus a separate
  freight line is not the same as the register cost. Keep the lines separate
  and flag the composition.
- **Lots**: "1 lot de 10 chaises" is one invoice line with quantity 1 and a
  description containing 10. The matcher cannot group it unless the quantity
  is split or the lot is documented; flag it for review.
- **Credit notes**: a negative line reduces the asset cost only if it relates
  to the same asset; do not net it automatically.
- **Multi-currency**: convert before loading, or keep currencies separate and
  exclude cross-currency amount comparisons.
- **Duplicate scans**: a phone photo and a PDF of the same invoice are
  duplicates even if the hashes differ. Compare supplier + number + total +
  date.
