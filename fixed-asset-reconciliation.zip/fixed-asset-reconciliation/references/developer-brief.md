# Developer brief — fixed-asset reconciliation

Hand this page to the developer before the first sprint. It is deliberately
short; the detailed rules are in the other references.

## 1. Goal

Build a tool that takes a client's four fixed-asset sources, reads the
invoices (including scans), matches each asset across the sources, flags
discrepancies and produces a reviewable Excel working paper.

The tool is **not** a spreadsheet comparison. The invoice reading and the
cross-source asset identity are the project.

## 2. Inputs

| Input | Format | Volume assumption |
| --- | --- | --- |
| Physical inventory | XLSX/CSV | 500–5,000 rows |
| Supplier invoices | PDF, JPG, PNG + optional extracted table | 100–1,000 invoices, 1–5 pages each |
| Fixed-asset register | XLSX/CSV | 500–5,000 rows |
| General ledger extract | XLSX/CSV | 1,000–20,000 rows |
| Period | 5 fiscal years | — |
| Sites / currency | metadata | Multi-site, FCFA default |

## 3. Outputs

1. `rapprochement_immobilisations.xlsx` with the sheets defined in
   `deliverable-spec.md`.
2. CSV exports: discrepancies, review queue, unmatched invoices, unmatched GL,
   duplicates.
3. Extraction journal: every invoice line with file, page, confidence.
4. Run log: file hashes, thresholds, period, engine version.

## 4. Non-negotiable requirements

1. **Scanned invoices are first-class.** A demo with only clean Excel is a
   failed demo.
2. **Line-level extraction** with the 11 fields, page and confidence.
3. **No invented values.** Null + flag for anything absent or illegible.
4. **Arithmetic validation** (qty × unit price, sum of lines vs total) without
   silently correcting.
5. **Duplicate detection** by hash and by supplier + number + total + date.
6. **Four-source matching**: exact keys, then an explainable fuzzy score.
7. **Quantity grouping** (10 chairs vs 8 counted rows vs one register row).
8. **All seven discrepancy families**, with severity and evidence.
9. **Side-by-side table** and a manual review queue.
10. **Traceability** to file/sheet/row/page for every figure.
11. **Reproducibility**: same inputs + config = same output.
12. **No silent loss**: every input row appears somewhere in the output.
13. **French accents and FCFA formats** handled; English accepted.
14. **Human validation** required; no automatic accounting entries.
15. **Performance**: 500 invoices / 5,000 assets in under 30 minutes on a
    laptop, excluding the vision API latency.

## 5. Architecture

```
ingestion → extraction → normalization → matching → rules → review → report
```

- Extraction: use a document-intelligence API or a vision model. Do not build
  OCR. Keep the provider replaceable.
- Storage: files + Postgres (or SQLite for the prototype). Store the original
  file hash, never overwrite the source.
- Matching and rules: custom code, versioned, with the weights and thresholds
  in configuration.
- Report: Excel via `openpyxl` (or equivalent). CSV export mandatory.
- Review: start with the workbook's decision columns; build a UI only when
  volume or multi-user needs justify it.

## 6. Data contract

Use the canonical schema in `data-model.md`. The minimum invoice line is:

```
invoice_number, supplier, invoice_date, description, quantity, line_total,
source_file, source_page, extraction_confidence
```

The minimum register row is:

```
asset_code, description, acquisition_date, cost
```

The minimum inventory row is:

```
description, quantity
```

Missing required fields must raise a data-quality finding, not a crash.

## 7. Acceptance tests

The developer must deliver a dataset and a test report for each case. Expected
findings are exact codes; statuses are the expected final status.

| # | Case | Input | Expected |
| --- | --- | --- | --- |
| T1 | Clean match | 1 asset in all four sources, same code, same amount | `FULLY_RECONCILED`, no code |
| T2 | 10 chairs | Invoice qty 10, register qty 10, 8 inventory rows of 1 | `QTY_MISMATCH` (H), expected 10, observed 8, `DISCREPANCY` |
| T3 | Description variance | "PC portable HP EliteBook 840 G8" vs "Ordinateur portable HP EliteBook 840 G8" | Auto-match, no false `INV_NOT_IN_REGISTER` |
| T4 | Brand alias | "Hewlett-Packard" vs "HP" | Auto-match; brand component 1.0 |
| T5 | Duplicate scan | Same invoice in two files, one a photo | `DUPLICATE_INVOICE`, one cluster, no phantom asset |
| T6 | Missing invoice | Register asset with no invoice in the folder | `NO_INVOICE`, `MISSING_DOCUMENT` |
| T7 | Invoice not in GL | Invoice and register agree, no GL entry | `INVOICE_NOT_IN_GL`, `MISSING_DOCUMENT` |
| T8 | GL-only entry | GL debit with no invoice or asset | `GL_WITHOUT_ASSET`, `UNMATCHED_GL` |
| T9 | Amount mismatch | Invoice 1,200,000 vs register 1,180,000 | `AMOUNT_MISMATCH` (H) |
| T10 | VAT basis | Invoice HT 1,000,000, register 1,180,000 | No false amount mismatch; note VAT basis |
| T11 | Cut-off | Invoice 2024-12-20, GL entry 2025-01-10 | `CUTOFF_YEAR` (M), explainable tie-out |
| T12 | Low-confidence scan | Handwritten invoice, confidence 0.62 | `LOW_CONFIDENCE_EXTRACTION`, review queue |
| T13 | Intangible | Software licence, no physical count | `INTANGIBLE_NO_PHYSICAL`, `FULLY_RECONCILED` if invoice/register/GL agree |
| T14 | Disposed asset still counted | Register status "cédé", asset found physically | `STATUS_MISMATCH` |
| T15 | Pre-period asset | Acquired 2020, period 2021–2025 | `PRE_PERIOD_ASSET`, no `NO_INVOICE` in period |
| T16 | Multi-line invoice | 3 lines, 3 register rows, 1 invoice number | Three clusters, each matched to its line |
| T17 | Split purchase | One invoice line qty 5, five register rows qty 1 | One cluster, qty 5 = 5 |
| T18 | French headers | `N° inventaire`, `Désignation`, `Valeur brute`, `Date écriture` | Columns mapped, no required-column error |
| T19 | Missing required column | Register without `Valeur brute` | `REQUIRED_COLUMN_MISSING`, run continues with warning |
| T20 | Idempotence | Run twice on the same inputs | Same clusters, codes and totals |
| T21 | Scale | 500 invoices / 5,000 assets | Completes <30 min, no memory blow-up |
| T22 | Empty folder | No invoices | Run completes, `NO_INVOICE` for in-scope assets, coverage warning |

A test is only passed if the output workbook contains the expected code, the
expected status and the evidence (file/row or page).

## 8. Definition of done

- [ ] Demo on a real scanned invoice folder, not only synthetic Excel.
- [ ] Test report with T1–T22 and known-answer assertions.
- [ ] Precision/recall measured on a 50-asset labelled sample.
- [ ] Extraction coverage and confidence distribution reported.
- [ ] All input rows accounted for.
- [ ] Workbook opens in Excel/LibreOffice without repair prompts.
- [ ] CSV exports match the workbook.
- [ ] README: install, run, configure, known limitations.
- [ ] Thresholds and normalization tables documented and versioned.
- [ ] Data-protection note: where files are stored, who can access them,
      retention.

## 9. Questions to ask before signing

1. Show me the extraction on this handwritten invoice, with page and
   confidence.
2. What happens when two assets have the same description and no serial?
3. How do you prevent a double scan from creating a second asset?
4. How do you compare one invoice line for 10 chairs with 8 physical rows?
5. Where is the evidence for this match stored?
6. What happens when a column is not recognised?
7. How do you handle an invoice posted in the next fiscal year?
8. Can I rerun the reconciliation after correcting one invoice line?
9. What is the measured precision on my test set?
10. What is the cost and latency per 100 invoices, and what happens on a
    provider outage?

## 10. Out of scope for v1

- Depreciation recalculation and net book value testing (add later; the schema
  already carries the fields).
- Impairment, revaluation, component accounting.
- Lease classification (IFRS 16 / local GAAP).
- Automatic posting to the ERP.
- Full audit programme, sampling and opinion.
- Handwriting recognition beyond what the vision provider supports.

## 11. Red flags

- A proposal that starts with "we import the four Excel files".
- OCR treated as a later add-on.
- A single confidence number for the whole invoice instead of per line.
- No page/file provenance.
- No duplicate handling.
- A matching score with no components.
- No review queue or decision log.
- A per-page price with no accuracy target.
- A proprietary output format.

## 12. Commercial framing

Price the **outcome**, not the lines of code: a working extraction + matching
pipeline validated on the client's test set, with the acceptance tests above.
Separate the prototype (fixed scope, 1–2 weeks) from the application (phased).
Keep the data model and rules portable so a change of OCR provider or UI does
not restart the project.
