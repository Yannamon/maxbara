# Data model and normalization

The engine reads four source tables and maps them onto one canonical schema.
Client files are never edited. Every record carries its provenance so the
report can point back to the exact file, sheet and row (or invoice page).

## 1. Principles

1. **One row = one unit of evidence.**
   - Inventory: one physically identified asset (quantity 1), or a counted lot
     with an explicit quantity.
   - Invoice: one invoice line, header fields repeated.
   - Register: one capitalised asset line.
   - GL: one accounting entry line.
2. **Raw value + parsed value.** The loader keeps the original cell text in
   the source file; the engine stores parsed dates/amounts for comparison.
   Nothing is overwritten.
3. **Blank is information.** A missing brand, serial or invoice number is not
   replaced by a guess. It lowers match confidence and raises a data-quality
   flag.
4. **Identifiers are compared without formatting.** `IMM-001`, `IMM 001` and
   `imm001` are the same key. Descriptions are compared as canonical tokens.
5. **Amounts are numbers, not labels.** `1 250 000 FCFA`, `1.250.000` and
   `1,250,000.00` all parse to `1250000.00`; ambiguous separators are flagged.

## 2. Canonical schema

### Inventory (`inventory`)

| Field | Type | Req. | Notes |
| --- | --- | --- | --- |
| `asset_code` | text | no | Tag / inventory number; strongest physical key |
| `site` | text | no | Site or agency |
| `location` | text | no | Building, floor, room, department |
| `family` | text | no | Category used for grouping and blocking |
| `description` | text | **yes** | What was physically identified |
| `brand` | text | no | Normalised through the brand alias table |
| `model` | text | no | Model or manufacturer reference |
| `serial_number` | text | no | Strong key when present |
| `colour` | text | no | Physical attribute |
| `condition` | text | no | Bon / moyen / mauvais / hors service |
| `quantity` | number | no | Defaults to 1 only for inventory/register, and the default is flagged |
| `acquisition_date` | date | no | Often unknown on a count sheet |
| `count_date` | date | no | Date of the physical count |
| `label_status` | text | no | Tagged / not tagged |
| `notes` | text | no | Free text |

### Invoices (`invoices`)

| Field | Type | Req. | Notes |
| --- | --- | --- | --- |
| `invoice_number` | text | **yes** | Exactly as printed; key for register and GL |
| `supplier` | text | **yes** | Legal name or trade name as printed |
| `invoice_date` | date | **yes** | Date of issue |
| `delivery_date` | date | no | Delivery / receipt date |
| `description` | text | **yes** | Line description, copied not improved |
| `brand` | text | no | Only if printed |
| `model` | text | no | Only if printed |
| `quantity` | number | **yes** | Line quantity |
| `unit_price` | number | no | Unit price excl. tax if identifiable |
| `line_total` | number | **yes** | Line amount as printed |
| `invoice_total` | number | no | Header total, repeated on each line |
| `tax_amount` | number | no | VAT amount if printed |
| `currency` | text | no | Default FCFA |
| `line_no` | text | no | Printed line number |
| `po_number` | text | no | Purchase order |
| `asset_code` | text | no | Only if the invoice itself references it |
| `source_file` | text | no | Scan file name; defaults to the workbook name |
| `source_page` | text | no | Page in the PDF |
| `extraction_confidence` | 0–1 | no | Confidence of the extraction |
| `review_status` | text | no | À relire / Relu / Corrigé |

### Register (`register`)

| Field | Type | Req. | Notes |
| --- | --- | --- | --- |
| `asset_code` | text | **yes** | Capitalisation code |
| `description` | text | **yes** | Register label |
| `family` | text | no | Category |
| `brand` | text | no | Brand |
| `model` | text | no | Model |
| `serial_number` | text | no | Serial / VIN / IMEI |
| `quantity` | number | no | A register row may hold a lot (10 chairs) |
| `acquisition_date` | date | **yes** | Entry date |
| `in_service_date` | date | no | Commissioning date |
| `supplier` | text | no | Supplier |
| `invoice_number` | text | no | Invoice reference; strongest invoice key |
| `cost` | number | **yes** | Gross acquisition value |
| `currency` | text | no | Default FCFA |
| `site` | text | no | Site |
| `depreciation_method` | text | no | Linear / declining |
| `useful_life_years` | number | no | For a later depreciation module |
| `accumulated_depreciation` | number | no | Informational |
| `net_book_value` | number | no | Informational |
| `status` | text | no | Actif / cédé / rebut / transféré |
| `disposal_date` | date | no | Disposal or retirement date |
| `gl_account` | text | no | Fixed-asset account |

### General ledger (`gl`)

| Field | Type | Req. | Notes |
| --- | --- | --- | --- |
| `entry_id` | text | no | Journal entry number |
| `journal` | text | no | Journal code |
| `account_code` | text | **yes** | GL account |
| `account_label` | text | no | Account name |
| `entry_date` | date | **yes** | Posting date |
| `document_ref` | text | no | Document / invoice reference |
| `description` | text | **yes** | Entry label |
| `debit` | number | no | Debit amount |
| `credit` | number | no | Credit amount |
| `supplier` | text | no | Third party |
| `invoice_number` | text | no | Invoice reference |
| `asset_code` | text | no | Asset reference if posted analytically |
| `fiscal_year` | text | no | Fiscal year |
| `posting_status` | text | no | Validated / draft |

## 3. Provenance

Every record gets, at load time:

```
_source      inventory | invoices | register | gl
_id          INV-0001, INV-0002, REG-0001, ...
_file        source workbook/CSV name
_path        absolute path (used for hashing)
_sheet       worksheet name (or "CSV")
_row         Excel row number (1-based)
```

Invoice lines additionally keep `source_file` and `source_page` because one
workbook can hold hundreds of scans.

## 4. Normalization

### Text

- uppercase, accents stripped, punctuation collapsed to spaces;
- `N°` treated as `N`;
- repeated spaces removed.

`Code actif / N° inventaire` → `CODE ACTIF N INVENTAIRE`.

### Identifiers

`norm_key()` removes all non-alphanumeric characters:

```
IMM-001 → IMM001
FAC-2024/001 → FAC2024001
SN HP 001 → SNHP001
```

### Brands

A configurable alias table maps legal names to a canonical brand:

```
Hewlett-Packard, HP Inc, HP Inc. → HP
Samsung Electronics → SAMSUNG
Seiko Epson → EPSON
Mercedes-Benz → MERCEDES
```

Unknown brands are compared as normalized text. A missing brand is neutral
in the score, not a mismatch.

### Descriptions

Two steps:

1. **Phrase synonyms** (longest first):
   - `ORDINATEUR PORTABLE`, `PC PORTABLE`, `NOTEBOOK`, `LAPTOP` → `LAPTOP`
   - `ORDINATEUR DE BUREAU`, `PC DE BUREAU`, `DESKTOP` → `DESKTOP`
   - `FAUTEUIL`, `CHAISE`, `SIEGE`, `CHAIR` → `CHAIR`
   - `PHOTOCOPIEUR`, `PHOTOCOPIEUSE`, `COPIER` → `COPIER`
   - `CLIMATISEUR`, `CLIMATISATION`, `SPLIT` → `AC`
   - `GROUPE ELECTROGENE`, `GENERATEUR` → `GENERATOR`
   - `ONDULEUR`, `UPS` → `UPS`
   - `VEHICULE`, `VOITURE`, `CAR` → `VEHICLE`
   - and the common office/IT/energy vocabulary.
2. **Noise removal**: `DE`, `DU`, `LA`, `LE`, `ET`, `NEUF`, `DIVERS`,
   `MATERIEL`, `ARTICLE`, `U`, `PCS`, `LOT`, etc.

The result is a token list, e.g.:

```
"Ordinateur portable HP EliteBook 840 G8"
→ ["LAPTOP", "HP", "ELITEBOOK", "840", "G8"]
```

Similarity blends token containment (tolerates extra words) with sequence
similarity (rewards order and spelling), and is bounded to [0, 1].

### Dates

Accepted: Excel dates and serials, `YYYY-MM-DD`, `DD/MM/YYYY`, `DD-MM-YY`,
`YYYY/MM/DD`, `12 janvier 2024`, `12 JAN 2024`. Invalid dates are reported,
not coerced.

### Money

Accepted: numeric cells, `1 250 000`, `1.250.000`, `1,250,000.00`,
`1 250 000 FCFA`, `(12 500)` for negative, trailing currency codes.

Separator heuristic:

- both `.` and `,` → the last one is decimal;
- one separator with exactly three digits after it and a short integer part →
  thousands (`1,250` → 1250), flagged as ambiguous;
- otherwise decimal.

The engine compares amounts with an absolute tolerance (default 1,000 FCFA)
and a relative tolerance (default 0.5%). VAT-aware comparison also tests
×1.18 and ÷1.18 (UEMOA 18%) and reports a lower component score rather than a
false mismatch.

### Quantities

Numeric cells, `10`, `10 U`, `10 unités`, `10 pcs`. Blank is `None`, except
for inventory/register rows where the physical meaning of a row is one asset;
that default is recorded as a data-quality issue (`QTY_DEFAULTED`).

## 5. Header detection and aliases

The loader scans the first 25 rows for a header. It scores each row by how
many canonical fields it recognises, then maps columns in two passes:

1. exact alias match (longest alias first, to disambiguate `Total` vs
   `Total facture`);
2. partial match for headers such as `Code actif / N° inventaire`.

Aliases are French and English, e.g.:

| Field | Accepted headers |
| --- | --- |
| `asset_code` | Code actif, N° inventaire, Code immo, Code immobilisation, Asset code, Tag |
| `description` | Désignation, Libellé, Description, Intitulé, Matériel, Article |
| `brand` | Marque, Brand, Fabricant, Manufacturer |
| `quantity` | Quantité, Qté, Qty, Nombre, Nb |
| `cost` | Valeur brute, Valeur d'acquisition, Coût, Montant HT, Prix |
| `invoice_number` | N° facture, Facture N°, Invoice number, Pièce |
| `entry_date` | Date écriture, Date comptable, Date opération, Entry date |
| `document_ref` | Référence document, N° pièce, Doc ref, Référence |

Unmapped columns are listed in `07_Qualite_donnees`; they are never silently
ignored. To add an alias, edit `scripts/fa_recon/schema.py`.

## 6. Scope rules

- **Period**: assets acquired before `period_start` are flagged
  `PRE_PERIOD_ASSET` and are not required to have an in-period invoice.
- **Intangibles**: descriptions/families containing `LOGICIEL`, `LICENCE`,
  `BREVET`, `MARQUE`, `FONDS DE COMMERCE`, `GOODWILL`, `SITE WEB`,
  `DROIT AU BAIL` are excluded from the physical-existence test
  (`INTANGIBLE_NO_PHYSICAL`).
- **Disposals**: a register row with a disposal date or a status containing
  `CESSION`, `SORTIE`, `REBUT`, `DISPOSED`, `SOLD`, `RETIRED` is not expected
  physically. Finding it in the count raises `STATUS_MISMATCH`.
- **Foreign currency**: amounts are compared as stored. If sources are in
  different currencies, convert before loading and keep the rate in the run
  log; the engine does not invent an FX rate.
- **Credit notes**: keep them as separate invoice lines with a negative
  amount or a `CREDIT_NOTE` marker; do not net them silently.

## 7. Data-quality codes

| Code | Meaning |
| --- | --- |
| `REQUIRED_COLUMN_MISSING` | A mandatory column was not recognised |
| `REQUIRED_VALUE_MISSING` | A mandatory value is empty on a row |
| `COLUMNS_IGNORED` | Extra columns not mapped |
| `DATE_INVALID` | Date not parsable |
| `AMOUNT_INVALID` | Amount not parsable |
| `AMOUNT_AMBIGUOUS` | Decimal/thousands separator ambiguous |
| `QTY_INVALID` | Quantity not parsable |
| `QTY_DEFAULTED` | Quantity blank, defaulted to 1 |
| `CONFIDENCE_INVALID` | Extraction confidence not numeric |
| `SHEET_SKIPPED` | Worksheet without a recognisable header |
| `DUPLICATE_*` | Duplicate invoice/asset/serial/GL entry |

Quality issues are findings. They belong in the working paper, not in a
hidden log.

## 8. What not to store

- Full invoice images inside the workbook (keep the folder and hashes).
- Supplier bank details, personal data of employees, or payment information
  that is not needed for the reconciliation.
- Passwords, API keys or connection strings in the input files.
