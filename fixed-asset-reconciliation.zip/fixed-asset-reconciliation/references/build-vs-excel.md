# Excel automation or dedicated software?

Assessment for a five-year fixed-asset reconciliation across physical
inventory, supplier invoices (including scans), fixed-asset register and
general ledger.

## 1. Answer in one paragraph

**Excel alone cannot deliver this project.** Excel can hold the four sources,
join clean tables and produce a nice report, but it cannot reliably read
scanned invoices, extract multi-line invoice data with confidence, recognise
that "PC portable HP EliteBook 840 G8", "Ordinateur portable Hewlett-Packard
840 G8" and "HP 840 G8" are the same asset, or keep an audit trail of who
matched what and why. Power Query and Copilot improve the spreadsheet case but
do not close those gaps. The right target is a **small dedicated tool** whose
input and output are Excel/CSV: a pipeline that ingests the four sources,
extracts invoices with a vision/IDP layer, normalises and matches records,
applies discrepancy rules, and produces a reviewable workbook. This skill is a
working phase-1 version of that tool. A web application becomes justified when
the mission repeats across clients, several people review the file, or invoice
volume and evidence retention make a folder of spreadsheets unsafe.

## 2. Requirement-by-requirement comparison

| Requirement | Excel formulas / Power Query | Excel + Copilot / AI add-in | Python engine + Excel I/O (this skill) | Dedicated web app |
| --- | --- | --- | --- | --- |
| Read scanned PDFs/images | No native OCR; text-layer PDFs only, layout-dependent | Can summarise a document, not reliably transcribe 20 lines with provenance | Agent vision / IDP API; page and confidence stored | Same, with queue and retries |
| Extract 11 invoice fields per line | Manual or fragile regex | Non-deterministic; hard to audit | Structured schema + validation | Same + correction UI |
| Exact joins (invoice no., asset code, serial) | Good | Good | Good | Good |
| Fuzzy asset identity across descriptions | Very limited (`XLOOKUP`, wildcards); no scoring | Opaque | Explainable weighted score | Same + learned aliases |
| Quantity grouping (10 chairs vs 10 rows) | Possible with helper columns, brittle | Not reliable | Explicit group logic | Same |
| Discrepancy taxonomy with severity/evidence | Formulas become unmaintainable | No | Rules + evidence + codes | Same + workflow |
| Audit trail (who, when, why) | No (cell history is weak) | No | Run log + hashes + review columns | Immutable log, roles |
| Repeatability across clients | Rebuild formulas each mission | Re-prompt each time | Config + templates | Multi-tenant templates |
| Scale (5 years, several sites, hundreds of invoices) | Slows quickly; formula errors | Token/row limits | Fine to a few thousand assets | Designed for volume |
| Multi-user review | Email versions | No | Shared workbook (limited) | Real review workflow |
| Data residency / confidentiality | Local, but uncontrolled copies | Data leaves to vendor | Local or chosen API | Controlled hosting |

Excel is excellent for **input templates, ad-hoc analysis and the final
report**. It is not the extraction or matching engine.

## 3. Why "four Excel files compared with formulas" fails

1. **The invoices are not in Excel.** The client gives scans. Someone must
   read them. That step is the project, not a preprocessing detail.
2. **Invoice layout varies by supplier.** A fixed cell mapping breaks on the
   next supplier. You need line detection, not a template per supplier.
3. **Asset identity is not a key.** The same chair is "Chaise de bureau
   ergonomique" in the register, "Chaise bureau" on the invoice, and
   "Fauteuil" in the count. Exact joins miss it; `SEARCH()` produces false
   positives.
4. **Quantities are split.** One invoice line for 10 chairs, one register row
   for 10, ten physical rows for 1 each. A row-by-row join cannot reconcile
   that; a group comparison can.
5. **The general ledger is not one row per asset.** One posting often covers a
   whole invoice. Comparing line to line creates false discrepancies.
6. **There is no evidence chain.** An auditor must be able to say: this figure
   comes from this invoice, page 2, line 3, extracted with 0.93 confidence,
   matched to this register row with this score. A formula cell does not carry
   that.
7. **Silent failure.** A broken formula or a filtered-out row looks like a
   clean reconciliation. Audit work cannot rely on "the spreadsheet says so".
8. **Maintenance.** Every client has different headers, date formats, amount
   formats and site names. VBA macros become an untested application hidden
   in a workbook.

## 4. When Excel is legitimately enough

Use a spreadsheet-only approach only if **all** of these hold:

- one client, one period, one currency, one language;
- fewer than ~50 invoices, all with a text layer or already typed;
- clean, consistent descriptions and asset codes across sources;
- a single preparer, no four-eyes review;
- the output is a one-off schedule, not recurring evidence;
- the preparer accepts a manual review of every line.

Even then, the invoice extraction remains manual. The spreadsheet automates
the comparison, not the reading.

## 5. Recommended architecture

```
                 ┌─────────────────────────────────────────────┐
  Inventory ────►│ 1. Ingestion                                │
  Invoices  ────►│    hash, manifest, sheet/header detection   │
  Register  ────►│    provenance: file / sheet / row / page    │
  GL        ────►└──────────────────┬──────────────────────────┘
                                    ▼
                 ┌─────────────────────────────────────────────┐
                 │ 2. Invoice extraction                       │
                 │    text PDF → parser                        │
                 │    scan/photo → vision model or IDP API     │
                 │    schema + confidence + page + arithmetic  │
                 └──────────────────┬──────────────────────────┘
                                    ▼
                 ┌─────────────────────────────────────────────┐
                 │ 3. Normalisation                            │
                 │    accents, brands, synonyms, dates, money, │
                 │    quantities, sites, fiscal year           │
                 └──────────────────┬──────────────────────────┘
                                    ▼
                 ┌─────────────────────────────────────────────┐
                 │ 4. Matching                                 │
                 │    exact keys → fuzzy score → review queue  │
                 │    quantity grouping, GL at invoice level   │
                 └──────────────────┬──────────────────────────┘
                                    ▼
                 ┌─────────────────────────────────────────────┐
                 │ 5. Rules and status                         │
                 │    7 discrepancy families, severity,        │
                 │    expected/observed, evidence              │
                 └──────────────────┬──────────────────────────┘
                                    ▼
                 ┌─────────────────────────────────────────────┐
                 │ 6. Review and reporting                     │
                 │    accept/reject, comments, Excel/CSV/PDF   │
                 │    run log, hashes, sign-off                │
                 └─────────────────────────────────────────────┘
```

Build vs buy by layer:

| Layer | Recommendation | Reason |
| --- | --- | --- |
| OCR / document extraction | **Buy/API** (Azure Document Intelligence, Google Document AI, AWS Textract, Mistral OCR, a vision LLM) | Commodity, improves monthly; do not build OCR |
| Matching and discrepancy rules | **Build** | This is the firm's methodology and the real IP |
| Review UI | Build small, or start with the workbook | Four-eyes and evidence are specific to the audit workflow |
| Storage, auth, audit log | Buy/managed (Postgres + object storage) | Security is not the differentiator |
| Excel input/output | Keep | Clients and auditors live in Excel |
| ERP/accounting connectors | Later | Only after the core is proven |

## 6. Phased plan and effort

Indicative ranges for one experienced developer with an auditor as product
owner. Treat them as sizing, not quotes; fix scope and acceptance tests.

| Phase | Scope | Effort |
| --- | --- | --- |
| P0 — Data contract | Canonical schema, templates, 20-invoice test set, expected findings | 2–4 days |
| P1 — Prototype (this skill) | Ingestion, extraction protocol, normalization, matching, rules, Excel report, demo dataset | 1–2 weeks |
| P2 — Robust extraction | IDP/vision integration, retries, page coverage, correction loop, extraction metrics | 2–4 weeks |
| P3 — Review application | Database, upload, review queue, roles, comments, audit log, export | 4–8 weeks |
| P4 — Production | Auth, backups, monitoring, retention, multi-client templates, performance | 2–4 weeks |
| Maintenance | OCR/API changes, new supplier layouts, rule tuning | 10–20% of build per year |

A solo practitioner can run P1 on real files immediately. Do not start P3
before P1 has been validated on at least two real client datasets; most
requirements that look like UI needs are actually data-model or rule problems.

## 7. Decision checklist

Score each question; a "yes" pushes toward a dedicated tool.

1. Do you expect more than 100 scanned invoices per mission?
2. Will the mission repeat for more than two clients per year?
3. Are several people (preparer, reviewer, manager) involved?
4. Must the file be retained as audit evidence with who/when/why?
5. Are descriptions, brands or site names inconsistent across sources?
6. Do you need to demonstrate completeness of invoice extraction?
7. Is the ledger exported from an ERP with multi-line postings?
8. Do you need to run the same rules across a portfolio?
9. Is the client data too sensitive for ad-hoc spreadsheet copies?
10. Do you want the reconciliation to improve over time (aliases, thresholds)?

If 4 or more are "yes", a spreadsheet is the wrong target. If 1–3, the hybrid
Python engine is enough. If 8+, plan the application.

## 8. What to insist on with a developer

These are acceptance criteria, not wishes. They are also the test plan.

1. **Scanned input is first-class.** The demo must include at least one photo
   or scanned PDF per invoice type, not a folder of clean Excel.
2. **Line-level extraction.** Header fields plus every invoice line, with
   `source_file`, `source_page`, `extraction_confidence`.
3. **No invented values.** Illegible fields are blank and flagged; the tool
   never fills a gap with a plausible amount.
4. **Arithmetic validation.** Quantity × unit price = line total; sum of lines
   = invoice total; discrepancies reported, not corrected.
5. **Duplicate scans.** The same invoice photographed twice is one invoice,
   with an explicit duplicate finding.
6. **Four-source matching with explanations.** Exact keys first, then a score
   with visible components; no black-box "AI matched".
7. **The 10-chair test.** One invoice line for 10 chairs, one register row for
   10, eight physical rows: the tool reports 8 vs 10 and does not invent two
   chairs.
8. **Description variance.** "HP" vs "Hewlett-Packard", "PC portable" vs
   "laptop", "fauteuil" vs "chaise" must produce a suggested match, not a
   silent miss.
9. **All seven discrepancy families.** Missing register, missing physical,
   missing invoice, invoice not in GL, quantity/amount/description/date
   variances, duplicates, unmatched transactions.
10. **Side-by-side output.** One row per asset group, four source blocks,
    status, codes, action, evidence.
11. **Review queue.** Ambiguous matches and low-confidence scans are listed
    with the top candidate(s) and an accept/reject field.
12. **Traceability.** Every reported figure maps to a file/sheet/row or an
    invoice page.
13. **Reproducibility.** A run is defined by the four files, the period, the
    thresholds and the extraction file; rerunning gives the same result.
14. **No silent loss.** Every input row appears in the reconciliation, the
    unmatched list or the data-quality sheet.
15. **Known-answer test set.** At least 30 assets and 15 invoices with
    pre-labelled expected findings; precision/recall reported.

## 9. Red flags in a developer conversation

- "We'll just compare four Excel files." — The invoices are scans; this skips
  the core.
- "OCR is easy, we'll add it later." — Extraction quality drives the whole
  result.
- "The AI will handle it." — Ask for schema, confidence, provenance, failure
  behaviour and a measured accuracy on your test set.
- No review step. — An auditor must validate, not trust a score.
- No duplicate handling. — Double scans are the most common real-world error.
- No data-quality report. — Unmapped columns and invalid dates are findings,
  not noise.
- A per-page price with no accuracy commitment. — Tie payment to acceptance
  tests, not volume alone.
- Proprietary output format. — Excel/CSV export is mandatory for the audit
  file.

## 10. What the tool should and should not promise

**Can promise:** faster first-pass reconciliation, consistent rules, full
traceability, explicit uncertainty, less manual copy/paste, a reviewable
working paper.

**Cannot promise:** 100% automation, zero false positives, reading illegible
handwriting, deciding the accounting treatment, replacing the auditor's
judgment, or proving completeness when pages are missing from the client's
scans.

State these limits in the deliverable. They protect the auditor and set the
client's expectations.

## 11. Bottom line

- **Do not fund a four-Excel comparison tool.** It solves the easy 30% and
  leaves the expensive 70% manual.
- **Fund the extraction + matching + evidence chain**, with Excel as the
  interface.
- Start with the hybrid engine, validate on two real files, then decide on the
  application. The data model and rules in this skill are designed to survive
  that move.
