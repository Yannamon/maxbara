"""Create the four input templates in the canonical schema."""
from __future__ import annotations

import os

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from .schema import SOURCE_COLORS, SPECS

KIND_LABELS = {
    "text": "texte",
    "date": "date (AAAA-MM-JJ)",
    "money": "montant numérique",
    "qty": "nombre",
    "enum": "liste",
}


def _readme(workbook, source, spec):
    worksheet = workbook.active
    worksheet.title = "LISEZ-MOI"
    worksheet["A1"] = "Modèle — %s" % spec["label"]
    worksheet["A1"].font = Font(bold=True, size=15, color="FF1F3864")
    notes = [
        "Remplir la feuille « Données » à partir de la ligne 2. Ne pas renommer les colonnes.",
        "Une ligne = un actif (inventaire, registre) ou une ligne de facture / d'écriture.",
        "Les colonnes marquées obligatoires doivent être renseignées; laisser vide plutôt qu'inventer une valeur.",
        "Dates au format AAAA-MM-JJ (ou date Excel). Montants en nombre, sans texte ni devise dans la cellule.",
        "La feuille « Exemple » montre le format attendu; elle n'est pas lue par le moteur.",
        "Le fichier client d'origine peut être utilisé tel quel si les en-têtes sont reconnus: voir la feuille « Notice ».",
    ]
    row = 3
    for note in notes:
        cell = worksheet.cell(row=row, column=1, value="• " + note)
        cell.font = Font(size=10)
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        worksheet.merge_cells(start_row=row, start_column=1, end_row=row, end_column=5)
        worksheet.row_dimensions[row].height = 28
        row += 1
    worksheet["A%d" % (row + 1)] = "Colonnes obligatoires: %s" % ", ".join(
        spec["fields"][field][0] for field in spec["required"])
    worksheet["A%d" % (row + 1)].font = Font(bold=True, size=10)
    worksheet.column_dimensions["A"].width = 120
    worksheet.sheet_view.showGridLines = False


def _notice(workbook, spec):
    worksheet = workbook.create_sheet("Notice")
    headers = ["Champ", "Libellé", "Obligatoire", "Type", "En-têtes acceptés"]
    for column, header in enumerate(headers, start=1):
        cell = worksheet.cell(row=1, column=column, value=header)
        cell.fill = PatternFill("solid", fgColor="FF1F3864")
        cell.font = Font(bold=True, color="FFFFFFFF")
        cell.alignment = Alignment(horizontal="center", wrap_text=True)
    row = 1
    for field, (label, aliases, required, kind) in spec["fields"].items():
        row += 1
        values = [field, label, "Oui" if required else "Non",
                  KIND_LABELS.get(kind, kind), ", ".join(aliases[:8])]
        for column, value in enumerate(values, start=1):
            cell = worksheet.cell(row=row, column=column, value=value)
            cell.font = Font(size=10)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    for column, width in enumerate([22, 32, 12, 20, 80], start=1):
        worksheet.column_dimensions[get_column_letter(column)].width = width
    worksheet.freeze_panes = "A2"
    worksheet.auto_filter.ref = "A1:E%d" % row


def _data(workbook, source, spec):
    worksheet = workbook.create_sheet("Données")
    fields = list(spec["fields"].items())
    for column, (field, (label, _aliases, required, kind)) in enumerate(fields, start=1):
        header = label + (" *" if required else "")
        cell = worksheet.cell(row=1, column=column, value=header)
        cell.fill = PatternFill("solid", fgColor=SOURCE_COLORS[source])
        cell.font = Font(bold=True, size=10, color="FF000000")
        cell.alignment = Alignment(horizontal="center", vertical="center",
                                   wrap_text=True)
        worksheet.column_dimensions[get_column_letter(column)].width = max(
            12, min(28, len(label) + 4))
        if kind == "date":
            worksheet.column_dimensions[get_column_letter(column)].number_format = \
                "DD/MM/YYYY"
        if kind == "money":
            worksheet.column_dimensions[get_column_letter(column)].number_format = \
                '#,##0'
    worksheet.row_dimensions[1].height = 34
    worksheet.freeze_panes = "A2"
    worksheet.auto_filter.ref = "A1:%s2000" % get_column_letter(len(fields))
    worksheet.sheet_view.zoomScale = 90

    if source == "invoices":
        # Confidence must stay between 0 and 1.
        confidence_column = [field for field, _ in fields].index("extraction_confidence") + 1
        validation = DataValidation(type="decimal", operator="between",
                                    formula1="0", formula2="1", allow_blank=True)
        worksheet.add_data_validation(validation)
        letter = get_column_letter(confidence_column)
        validation.add("%s2:%s2000" % (letter, letter))


def _example(workbook, source, spec):
    worksheet = workbook.create_sheet("Exemple")
    examples = {
        "inventory": [
            {"asset_code": "IMM-0001", "site": "Abidjan",
             "location": "Siège - 2e étage", "family": "Informatique",
             "description": "Ordinateur portable HP EliteBook 840 G8",
             "brand": "HP", "model": "EliteBook 840 G8",
             "serial_number": "SN-HP-0001", "colour": "Gris",
             "condition": "Bon", "quantity": 1, "acquisition_date": "2024-03-12",
             "count_date": "2025-11-05", "label_status": "Étiqueté",
             "notes": ""},
            {"asset_code": "IMM-0002", "site": "Yamoussoukro",
             "location": "Agence", "family": "Mobilier",
             "description": "Chaise de bureau ergonomique", "brand": "Générique",
             "model": "CH-100", "serial_number": "", "colour": "Noir",
             "condition": "Bon", "quantity": 1, "acquisition_date": "2022-02-20",
             "count_date": "2025-11-06", "label_status": "Non étiqueté",
             "notes": "Une des 10 chaises"},
        ],
        "invoices": [
            {"invoice_number": "FAC-2024-001", "supplier": "SUPRA INFO",
             "invoice_date": "2024-03-12", "delivery_date": "2024-03-15",
             "description": "PC portable HP EliteBook 840 G8", "brand": "HP",
             "model": "840 G8", "quantity": 2, "unit_price": 850000,
             "line_total": 1700000, "invoice_total": 1700000, "tax_amount": 0,
             "currency": "FCFA", "line_no": 1, "po_number": "BC-2024-007",
             "asset_code": "", "source_file": "facture_2024_001.pdf",
             "source_page": 1, "extraction_confidence": 0.96,
             "review_status": "Relu"},
        ],
        "register": [
            {"asset_code": "IMM-0001", "description": "Ordinateur portable HP EliteBook 840 G8",
             "family": "Informatique", "brand": "HP", "model": "EliteBook 840 G8",
             "serial_number": "SN-HP-0001", "quantity": 1,
             "acquisition_date": "2024-03-12", "in_service_date": "2024-03-15",
             "supplier": "SUPRA INFO", "invoice_number": "FAC-2024-001",
             "cost": 1700000, "currency": "FCFA", "site": "Abidjan",
             "depreciation_method": "Linéaire", "useful_life_years": 3,
             "accumulated_depreciation": 1033333, "net_book_value": 666667,
             "status": "Actif", "disposal_date": "", "gl_account": "244100"},
        ],
        "gl": [
            {"entry_id": "EC-2024-0154", "journal": "AC", "account_code": "244100",
             "account_label": "Matériel informatique", "entry_date": "2024-03-31",
             "document_ref": "FAC-2024-001", "description": "Acquisition PC portables",
             "debit": 1700000, "credit": 0, "supplier": "SUPRA INFO",
             "invoice_number": "FAC-2024-001", "asset_code": "IMM-0001",
             "fiscal_year": 2024, "posting_status": "Validée"},
        ],
    }[source]
    fields = list(spec["fields"].items())
    for column, (field, (label, _aliases, _required, kind)) in enumerate(fields, start=1):
        cell = worksheet.cell(row=1, column=column, value=label)
        cell.fill = PatternFill("solid", fgColor="FF1F3864")
        cell.font = Font(bold=True, color="FFFFFFFF", size=10)
        cell.alignment = Alignment(horizontal="center", wrap_text=True)
        worksheet.column_dimensions[get_column_letter(column)].width = 20
    for offset, example in enumerate(examples, start=2):
        for column, (field, _definition) in enumerate(fields, start=1):
            cell = worksheet.cell(row=offset, column=column,
                                  value=example.get(field, ""))
            cell.font = Font(size=10)
    worksheet.freeze_panes = "A2"


def write_templates(output_directory):
    os.makedirs(output_directory, exist_ok=True)
    paths = []
    for source in ("inventory", "invoices", "register", "gl"):
        spec = SPECS[source]
        workbook = Workbook()
        _readme(workbook, source, spec)
        _data(workbook, source, spec)
        _notice(workbook, spec)
        _example(workbook, source, spec)
        path = os.path.join(output_directory, "modele_%s.xlsx" % source)
        workbook.save(path)
        paths.append(path)
    return paths
