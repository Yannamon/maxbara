"""Consolidated reconciliation workbook.

The workbook is the audit deliverable: a dashboard, a four-source side-by-side
table, an exhaustive discrepancy register, the manual-review queue and the
extraction / run traceability. Client files are never modified.
"""
from __future__ import annotations

import csv
import os
from collections import Counter, OrderedDict, defaultdict
from datetime import datetime

from openpyxl import Workbook
from openpyxl.chart import BarChart, PieChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

from . import normalize as nz
from .schema import (SEVERITY_COLORS, SEVERITY_LABELS, SOURCE_COLORS,
                     SOURCE_LABELS, STATUS_COLORS, STATUS_LABELS)

NAVY = "FF1F3864"
LIGHT = "FFF2F2F2"
WHITE = "FFFFFFFF"
BORDER_COLOR = "FFBFBFBF"

THIN = Side(style="thin", color=BORDER_COLOR)
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
MONEY_FORMAT = '#,##0 " FCFA"'
DATE_FORMAT = "DD/MM/YYYY"
SCORE_FORMAT = "0%"


def _header_cell(cell, fill=NAVY, color=WHITE, size=10, wrap=True):
    cell.fill = PatternFill("solid", fgColor=fill)
    cell.font = Font(bold=True, color=color, size=size)
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=wrap)
    cell.border = BORDER


def _body_cell(cell, wrap=False, align=None, number_format=None):
    cell.font = Font(size=10)
    cell.alignment = Alignment(vertical="top", wrap_text=wrap,
                               horizontal=align or "left")
    cell.border = BORDER
    if number_format:
        cell.number_format = number_format


def _widths(worksheet, widths):
    for index, width in enumerate(widths, start=1):
        worksheet.column_dimensions[get_column_letter(index)].width = width


def _title(worksheet, text, subtitle=None):
    worksheet["A1"] = text
    worksheet["A1"].font = Font(bold=True, size=16, color=NAVY)
    if subtitle:
        worksheet["A2"] = subtitle
        worksheet["A2"].font = Font(size=10, italic=True, color="FF595959")


def _table(worksheet, start_row, headers, rows, widths=None, number_formats=None,
           status_column=None, severity_column=None):
    for column, header in enumerate(headers, start=1):
        cell = worksheet.cell(row=start_row, column=column, value=header)
        _header_cell(cell)
    for offset, row in enumerate(rows, start=1):
        for column, value in enumerate(row, start=1):
            cell = worksheet.cell(row=start_row + offset, column=column, value=value)
            number_format = None
            if number_formats and column in number_formats:
                number_format = number_formats[column]
            _body_cell(cell, wrap=True, number_format=number_format)
        if status_column:
            cell = worksheet.cell(row=start_row + offset, column=status_column)
            status = cell.value
            if status in STATUS_COLORS:
                cell.fill = PatternFill("solid", fgColor=STATUS_COLORS[status])
        if severity_column:
            cell = worksheet.cell(row=start_row + offset, column=severity_column)
            severity = cell.value
            if severity in SEVERITY_COLORS:
                cell.fill = PatternFill("solid", fgColor=SEVERITY_COLORS[severity])
    worksheet.freeze_panes = worksheet.cell(row=start_row + 1, column=1)
    if rows:
        worksheet.auto_filter.ref = "A%d:%s%d" % (
            start_row, get_column_letter(len(headers)), start_row + len(rows))
    if widths:
        _widths(worksheet, widths)


def _fmt(value):
    if value is None or value == "":
        return ""
    if isinstance(value, float):
        return round(value, 2)
    return value


def _text(value):
    if isinstance(value, (datetime,)) or hasattr(value, "strftime"):
        return value.strftime("%d/%m/%Y")
    if isinstance(value, float):
        if value.is_integer():
            return str(int(value))
        return ("%.2f" % value).rstrip("0").rstrip(".")
    return str(value)


def _join(values, limit=3):
    values = [_text(value) for value in values if value not in (None, "")]
    if not values:
        return ""
    if len(values) > limit:
        return " | ".join(values[:limit]) + " (+%d)" % (len(values) - limit)
    return " | ".join(values)


def _record_amount(record):
    if record.get("_source") == "gl":
        debit = record.get("debit")
        return debit if debit not in (None, "", 0) else record.get("credit")
    for key in ("cost", "line_total"):
        value = record.get(key)
        if value not in (None, ""):
            return value
    return None


def _record_ref(record):
    if record is None:
        return ""
    return "%s ligne %s" % (record.get("_file") or "", record.get("_row") or "")


def _evidence(cluster):
    parts = []
    for source in ("inventory", "invoices", "register", "gl"):
        records = cluster["records"].get(source, []) if source != "gl" else cluster["gl"]
        for record in records:
            parts.append("%s: %s" % (SOURCE_LABELS[source], _record_ref(record)))
    return _join(parts, limit=6)


def _cluster_site(result):
    cluster = result["cluster"]
    for source in ("register", "inventory"):
        sites = [record.get("site") for record in cluster["records"][source]
                 if record.get("site")]
        if sites:
            return sites[0]
    return ""


def _cluster_family(result):
    cluster = result["cluster"]
    for source in ("register", "inventory"):
        families = [record.get("family") for record in cluster["records"][source]
                    if record.get("family")]
        if families:
            return families[0]
    return ""


def _codes_text(result):
    return " | ".join(sorted(set(entry["code"] for entry in result["codes"])))


def _top_action(result):
    if not result["codes"]:
        return ""
    order = {"H": 0, "M": 1, "L": 2}
    codes = sorted(result["codes"], key=lambda entry: order.get(entry["severity"], 3))
    return codes[0]["action"]


# --------------------------------------------------------------------- sheets

def _sheet_readme(workbook, context):
    worksheet = workbook.active
    worksheet.title = "00_Lisez-moi"
    _title(worksheet, "Rapprochement des immobilisations",
           "Inventaire physique · Factures · Registre des immobilisations · Grand livre")
    worksheet["A4"] = "Client / mission"
    worksheet["B4"] = context.get("client") or ""
    worksheet["A5"] = "Période auditée"
    worksheet["B5"] = "%s → %s" % (context["period_start"], context["period_end"])
    worksheet["A6"] = "Généré le"
    worksheet["B6"] = context["generated_at"]
    worksheet["A7"] = "Moteur"
    worksheet["B7"] = context["version"]
    worksheet["A8"] = "Devise"
    worksheet["B8"] = context.get("currency", "FCFA")
    for row in range(4, 9):
        worksheet.cell(row=row, column=1).font = Font(bold=True, size=10)
        worksheet.cell(row=row, column=2).font = Font(size=10)

    worksheet["A10"] = "Sources chargées"
    worksheet["A10"].font = Font(bold=True, size=12, color=NAVY)
    headers = ["Source", "Fichier", "Feuilles", "Lignes", "Colonnes reconnues",
               "SHA-256 (12)"]
    for column, header in enumerate(headers, start=1):
        _header_cell(worksheet.cell(row=11, column=column, value=header))
    row = 12
    for source in ("inventory", "invoices", "register", "gl"):
        data = context["data"][source]
        values = [SOURCE_LABELS[source], data["file"], ", ".join(data["sheets"]),
                  len(data["records"]), len(data["columns"]), data["hash"][:12]]
        for column, value in enumerate(values, start=1):
            cell = worksheet.cell(row=row, column=column, value=value)
            _body_cell(cell, wrap=True)
        worksheet.cell(row=row, column=1).fill = PatternFill(
            "solid", fgColor=SOURCE_COLORS[source])
        row += 1

    row += 1
    worksheet.cell(row=row, column=1, value="Statuts").font = Font(
        bold=True, size=12, color=NAVY)
    row += 1
    for status, label in STATUS_LABELS.items():
        cell = worksheet.cell(row=row, column=1, value=status)
        _body_cell(cell)
        cell.fill = PatternFill("solid", fgColor=STATUS_COLORS[status])
        worksheet.cell(row=row, column=2, value=label)
        _body_cell(worksheet.cell(row=row, column=2))
        row += 1

    row += 1
    worksheet.cell(row=row, column=1, value="Seuils appliqués").font = Font(
        bold=True, size=12, color=NAVY)
    row += 1
    thresholds = [
        ("Rapprochement automatique", "score ≥ %.0f%%" %
         (context["config"]["auto_match_threshold"] * 100)),
        ("File de vérification", "score ≥ %.0f%%" %
         (context["config"]["review_match_threshold"] * 100)),
        ("Tolérance montant", "%.0f FCFA ou %.1f%%" % (
            context["config"]["amount_tolerance_abs"],
            context["config"]["amount_tolerance_pct"] * 100)),
        ("Tolérance date", "%d jours" % context["config"]["date_tolerance_days"]),
        ("Confiance extraction minimale", "%.0f%%" %
         (context["config"]["min_extraction_confidence"] * 100)),
    ]
    for label, value in thresholds:
        worksheet.cell(row=row, column=1, value=label).font = Font(bold=True, size=10)
        worksheet.cell(row=row, column=2, value=value).font = Font(size=10)
        row += 1

    row += 1
    worksheet.cell(row=row, column=1, value="Méthode").font = Font(
        bold=True, size=12, color=NAVY)
    row += 1
    notes = [
        "1. Les quatre sources sont lues sans modification; chaque ligne du rapport garde son fichier, sa feuille et sa ligne d'origine.",
        "2. Les rapprochements exacts (n° de facture, code immo, n° de série) sont posés d'abord.",
        "3. Les rapprochements flous combinent désignation, marque, quantité, montant, date et fournisseur; le score et les composantes sont affichés.",
        "4. Les quantités sont comparées au niveau du groupe: une facture de 10 chaises peut correspondre à 10 lignes d'inventaire de 1 chaise.",
        "5. Un rapprochement automatique n'est jamais une validation: la file de vérification manuelle reste obligatoire.",
        "6. Les actifs incorporels (logiciels, licences) sont exclus du test d'existence physique.",
        "7. Les montants du grand livre sont comparés au total facture, pas ligne à ligne, car une écriture couvre souvent une facture entière.",
        "8. Ce classeur est un outil d'aide à l'audit; il ne remplace pas le jugement de l'auditeur.",
    ]
    for note in notes:
        cell = worksheet.cell(row=row, column=1, value=note)
        cell.font = Font(size=10)
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        worksheet.merge_cells(start_row=row, start_column=1, end_row=row,
                              end_column=6)
        worksheet.row_dimensions[row].height = 30
        row += 1

    row += 1
    worksheet.cell(row=row, column=1, value="Limites connues").font = Font(
        bold=True, size=12, color=NAVY)
    row += 1
    limits = [
        "La qualité du rapprochement dépend de la qualité de l'extraction des factures: toute ligne non extraite est invisible pour le moteur.",
        "Les factures manuscrites, tamponnées ou de mauvaise qualité doivent être relues et leurs champs corrigés avant la clôture.",
        "Un actif peut être décrit de façon trop différente pour être rapproché automatiquement: il apparaît alors en vérification manuelle.",
        "Le grand livre fourni doit couvrir les comptes d'immobilisations et les exercices de la période; les écritures de paie ou de charges ne sont pas interprétées.",
    ]
    for note in limits:
        cell = worksheet.cell(row=row, column=1, value=note)
        cell.font = Font(size=10)
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        worksheet.merge_cells(start_row=row, start_column=1, end_row=row,
                              end_column=6)
        worksheet.row_dimensions[row].height = 30
        row += 1

    _widths(worksheet, [34, 42, 22, 12, 24, 18])
    worksheet.sheet_view.showGridLines = False


def _sheet_dashboard(workbook, results, duplicates, data, config, headers):
    worksheet = workbook.create_sheet("01_Tableau_de_bord")
    _title(worksheet, "Tableau de bord du rapprochement",
           "Vue synthétique — les montants sont des valeurs brutes, non des valeurs nettes")

    status_counts = Counter(result["status"] for result in results)
    total_value = sum(result["value"] or 0 for result in results)
    open_value = sum(result["value"] or 0 for result in results
                     if result["status"] != "FULLY_RECONCILED")
    code_counter = Counter()
    severity_counter = Counter()
    for result in results:
        for entry in result["codes"]:
            code_counter[entry["code"]] += 1
            severity_counter[entry["severity"]] += 1

    kpis = [
        ("Groupes d'actifs", len(results)),
        ("Rapprochés", status_counts.get("FULLY_RECONCILED", 0)),
        ("Partiellement rapprochés", status_counts.get("PARTIALLY_RECONCILED", 0)),
        ("Écarts", status_counts.get("DISCREPANCY", 0)),
        ("Documents / écritures manquants", status_counts.get("MISSING_DOCUMENT", 0)),
        ("Vérifications manuelles", sum(1 for result in results if result["review"])),
        ("Valeur brute suivie", total_value),
        ("Valeur non rapprochée", open_value),
        ("Écarts de sévérité élevée", severity_counter.get("H", 0)),
        ("Doublons détectés", len(duplicates)),
    ]
    row = 4
    for index, (label, value) in enumerate(kpis):
        column = 1 + (index % 2) * 3
        if index and index % 2 == 0:
            row += 2
        worksheet.cell(row=row, column=column, value=label).font = Font(
            bold=True, size=10, color="FF595959")
        cell = worksheet.cell(row=row + 1, column=column, value=value)
        cell.font = Font(bold=True, size=16, color=NAVY)
        if "Valeur" in label:
            cell.number_format = MONEY_FORMAT
            cell.font = Font(bold=True, size=12, color=NAVY)

    row += 2
    worksheet.cell(row=row, column=1, value="Rapprochement global (tie-out)").font = \
        Font(bold=True, size=12, color=NAVY)
    row += 1
    headers_row = ["Exercice", "Factures", "Registre", "Grand livre",
                   "Écart factures-registre", "Écart registre-grand livre"]
    for column, header in enumerate(headers_row, start=1):
        _header_cell(worksheet.cell(row=row, column=column, value=header))
    by_year = defaultdict(lambda: {"invoices": 0.0, "register": 0.0, "gl": 0.0})
    for header in headers:
        if header.get("invoice_date") and header.get("total") is not None:
            by_year[header["invoice_date"].year]["invoices"] += header["total"]
    for record in data["register"]["records"]:
        if record.get("acquisition_date") and record.get("cost") is not None:
            by_year[record["acquisition_date"].year]["register"] += record["cost"]
    for record in data["gl"]["records"]:
        if record.get("entry_date") and record.get("debit") is not None:
            by_year[record["entry_date"].year]["gl"] += record["debit"]
    totals = {"invoices": 0.0, "register": 0.0, "gl": 0.0}
    for year in sorted(by_year):
        row += 1
        values = by_year[year]
        for key in totals:
            totals[key] += values[key]
        cells = [year, values["invoices"], values["register"], values["gl"],
                 values["invoices"] - values["register"],
                 values["register"] - values["gl"]]
        for column, value in enumerate(cells, start=1):
            cell = worksheet.cell(row=row, column=column, value=value)
            _body_cell(cell, number_format=MONEY_FORMAT if column > 1 else None)
    row += 1
    cells = ["Total", totals["invoices"], totals["register"], totals["gl"],
             totals["invoices"] - totals["register"],
             totals["register"] - totals["gl"]]
    for column, value in enumerate(cells, start=1):
        cell = worksheet.cell(row=row, column=column, value=value)
        _body_cell(cell, number_format=MONEY_FORMAT if column > 1 else None)
        cell.font = Font(bold=True, size=10)

    row += 3
    worksheet.cell(row=row, column=1, value="Répartition par statut").font = Font(
        bold=True, size=12, color=NAVY)
    row += 1
    headers = ["Statut", "Libellé", "Nombre", "Valeur brute"]
    for column, header in enumerate(headers, start=1):
        _header_cell(worksheet.cell(row=row, column=column, value=header))
    first_status_row = row + 1
    for status in STATUS_LABELS:
        row += 1
        values = [status, STATUS_LABELS[status], status_counts.get(status, 0),
                  sum(result["value"] or 0 for result in results
                      if result["status"] == status)]
        for column, value in enumerate(values, start=1):
            cell = worksheet.cell(row=row, column=column, value=value)
            _body_cell(cell, number_format=MONEY_FORMAT if column == 4 else None)
        worksheet.cell(row=row, column=1).fill = PatternFill(
            "solid", fgColor=STATUS_COLORS[status])
    status_table_end = row

    chart = PieChart()
    chart.title = "Statuts"
    chart.height = 7
    chart.width = 10
    labels = Reference(worksheet, min_col=2, min_row=first_status_row,
                       max_row=status_table_end)
    values = Reference(worksheet, min_col=3, min_row=first_status_row - 1,
                       max_row=status_table_end)
    chart.add_data(values, titles_from_data=True)
    chart.set_categories(labels)
    worksheet.add_chart(chart, "F4")

    row = status_table_end + 3
    worksheet.cell(row=row, column=1, value="Principaux écarts").font = Font(
        bold=True, size=12, color=NAVY)
    row += 1
    headers = ["Code", "Libellé", "Sévérité", "Occurrences"]
    for column, header in enumerate(headers, start=1):
        _header_cell(worksheet.cell(row=row, column=column, value=header))
    code_rows = []
    for code, count in code_counter.most_common():
        from .rules import CODES
        spec = CODES.get(code, {})
        code_rows.append([code, spec.get("label", ""), spec.get("severity", ""),
                          count])
    for values in code_rows:
        row += 1
        for column, value in enumerate(values, start=1):
            cell = worksheet.cell(row=row, column=column, value=value)
            _body_cell(cell)
        severity = values[2]
        if severity in SEVERITY_COLORS:
            worksheet.cell(row=row, column=3).fill = PatternFill(
                "solid", fgColor=SEVERITY_COLORS[severity])
    if code_rows:
        chart = BarChart()
        chart.type = "bar"
        chart.title = "Écarts par code"
        chart.height = 8
        chart.width = 14
        data_ref = Reference(worksheet, min_col=4,
                             min_row=row - len(code_rows),
                             max_row=row)
        cats = Reference(worksheet, min_col=1,
                         min_row=row - len(code_rows) + 1, max_row=row)
        chart.add_data(data_ref, titles_from_data=True)
        chart.set_categories(cats)
        worksheet.add_chart(chart, "F22")

    # By site and family.
    row += 3
    for label, key_function in (("Par site", _cluster_site),
                                ("Par famille", _cluster_family)):
        worksheet.cell(row=row, column=1, value=label).font = Font(
            bold=True, size=12, color=NAVY)
        row += 1
        headers = [label.replace("Par ", "").capitalize(), "Actifs",
                   "Non rapprochés", "Valeur brute"]
        for column, header in enumerate(headers, start=1):
            _header_cell(worksheet.cell(row=row, column=column, value=header))
        groups = defaultdict(lambda: [0, 0, 0.0])
        for result in results:
            key = key_function(result) or "(non renseigné)"
            groups[key][0] += 1
            if result["status"] != "FULLY_RECONCILED":
                groups[key][1] += 1
            groups[key][2] += result["value"] or 0
        for key, values in sorted(groups.items(), key=lambda item: -item[1][2]):
            row += 1
            cells = [key, values[0], values[1], values[2]]
            for column, value in enumerate(cells, start=1):
                cell = worksheet.cell(row=row, column=column, value=value)
                _body_cell(cell, number_format=MONEY_FORMAT if column == 4 else None)
        row += 2

    _widths(worksheet, [34, 36, 12, 18, 4, 12, 12, 12])
    worksheet.sheet_view.showGridLines = False


def _sheet_reconciliation(workbook, results):
    worksheet = workbook.create_sheet("02_Rapprochement")
    _title(worksheet, "Tableau de rapprochement — quatre sources côte à côte",
           "Une ligne par groupe d'actifs. Les colonnes « Présent » indiquent si la source contient l'actif.")

    base_headers = ["ID", "Statut", "Score", "Sources", "Codes d'écart",
                    "Vérif. manuelle", "Action prioritaire"]
    source_fields = ["Présent", "Référence", "Désignation", "Marque", "Qté",
                     "Montant", "Date", "Site / pièce", "Fichier / ligne"]
    sources = ("inventory", "invoices", "register", "gl")

    # Group header row.
    for column, header in enumerate(base_headers, start=1):
        cell = worksheet.cell(row=1, column=column, value=header)
        _header_cell(cell)
        worksheet.merge_cells(start_row=1, start_column=column, end_row=2,
                              end_column=column)
    column = len(base_headers) + 1
    for source in sources:
        first = column
        cell = worksheet.cell(row=1, column=first, value=SOURCE_LABELS[source])
        _header_cell(cell, fill=SOURCE_COLORS[source], color="FF000000", size=11)
        for offset, field in enumerate(source_fields):
            field_cell = worksheet.cell(row=2, column=first + offset, value=field)
            _header_cell(field_cell, fill=SOURCE_COLORS[source],
                         color="FF000000", size=9)
        worksheet.merge_cells(start_row=1, start_column=first, end_row=1,
                              end_column=first + len(source_fields) - 1)
        column += len(source_fields)

    worksheet.row_dimensions[1].height = 22
    worksheet.row_dimensions[2].height = 30

    row = 3
    for result in results:
        cluster = result["cluster"]
        records = cluster["records"]
        values = [
            cluster["id"],
            STATUS_LABELS[result["status"]],
            result["score"],
            sum(1 for present in result["sources"].values() if present),
            _codes_text(result),
            "Oui" if result["review"] else "Non",
            _top_action(result),
        ]
        for source in sources:
            source_records = cluster["gl"] if source == "gl" else records[source]
            present = "Oui" if source_records else "Non"
            references = [record.get("asset_code") or record.get("invoice_number")
                          or record.get("entry_id") or record.get("document_ref")
                          for record in source_records]
            descriptions = [record.get("description") for record in source_records]
            brands = [record.get("brand") for record in source_records]
            quantities = [record.get("quantity") for record in source_records]
            amounts = [_record_amount(record) for record in source_records]
            dates = [record.get("invoice_date") or record.get("acquisition_date")
                     or record.get("entry_date") or record.get("count_date")
                     for record in source_records]
            sites = [record.get("site") or record.get("source_page")
                     for record in source_records]
            files = ["%s L%s" % (record.get("_file") or "",
                                 record.get("_row") or "")
                     for record in source_records]
            values.extend([
                present,
                _join(references),
                _join(descriptions),
                _join(brands),
                _join(quantities),
                _join(amounts),
                _join(dates),
                _join(sites),
                _join(files),
            ])
        for column_index, value in enumerate(values, start=1):
            cell = worksheet.cell(row=row, column=column_index, value=_fmt(value))
            _body_cell(cell, wrap=True)
            if column_index == 2:
                cell.fill = PatternFill("solid", fgColor=STATUS_COLORS[result["status"]])
            if column_index == 3:
                cell.number_format = SCORE_FORMAT
            if column_index in (len(base_headers) + 6,
                                len(base_headers) + len(source_fields) + 6,
                                len(base_headers) + 2 * len(source_fields) + 6,
                                len(base_headers) + 3 * len(source_fields) + 6):
                cell.number_format = MONEY_FORMAT
            if column_index in (len(base_headers) + 7,
                                len(base_headers) + len(source_fields) + 7,
                                len(base_headers) + 2 * len(source_fields) + 7,
                                len(base_headers) + 3 * len(source_fields) + 7):
                cell.number_format = DATE_FORMAT
        row += 1

    worksheet.freeze_panes = "C3"
    worksheet.auto_filter.ref = "A2:%s%d" % (
        get_column_letter(len(base_headers) + 4 * len(source_fields)), row - 1)
    widths = [8, 24, 8, 9, 30, 10, 46]
    for _source in sources:
        widths += [8, 16, 32, 12, 8, 16, 12, 18, 26]
    _widths(worksheet, widths)
    worksheet.sheet_view.zoomScale = 85


def _sheet_discrepancies(workbook, results):
    worksheet = workbook.create_sheet("03_Ecarts")
    _title(worksheet, "Registre des écarts",
           "Une ligne par écart constaté, avec valeur attendue, valeur constatée et preuve.")
    headers = ["ID écart", "Code", "Libellé", "Sévérité", "Statut", "Actif",
               "Cluster", "Source(s)", "Attendu", "Constaté", "Détail",
               "Preuve (fichier / ligne)", "Action suggérée", "Décision",
               "Commentaire auditeur"]
    rows = []
    counter = 0
    order = {"H": 0, "M": 1, "L": 2}
    for result in sorted(results, key=lambda r: (
            min([order.get(e["severity"], 3) for e in r["codes"]] or [3]),
            r["cluster"]["id"])):
        for entry in sorted(result["codes"],
                            key=lambda e: order.get(e["severity"], 3)):
            counter += 1
            sources = ", ".join(SOURCE_LABELS[source]
                                for source, present in result["sources"].items()
                                if present)
            rows.append([
                "E%04d" % counter, entry["code"], entry["label"],
                SEVERITY_LABELS.get(entry["severity"], entry["severity"]),
                STATUS_LABELS[result["status"]], result["asset_label"],
                result["cluster"]["id"], sources, entry["expected"],
                entry["observed"], entry["detail"], _evidence(result["cluster"]),
                entry["action"], "", "",
            ])
    _table(worksheet, 4, headers, rows,
           widths=[9, 28, 40, 9, 26, 36, 9, 28, 18, 18, 50, 50, 46, 14, 30],
           status_column=5, severity_column=4)
    worksheet.freeze_panes = "C5"
    return rows


def _sheet_review(workbook, results, review_candidates):
    worksheet = workbook.create_sheet("04_Verification_manuelle")
    _title(worksheet, "File de vérification manuelle",
           "Rapprochements à confirmer ou à rejeter. La colonne Décision est à remplir par l'auditeur.")
    headers = ["Cluster", "Actif", "Statut", "Raison", "Codes", "Score",
               "Sources", "Correspondances proposées", "Décision", "Commentaire"]
    by_record = defaultdict(list)
    for candidate in review_candidates:
        by_record[(candidate.left["_source"], candidate.left["_id"])].append(candidate)
        by_record[(candidate.right["_source"], candidate.right["_id"])].append(candidate)

    rows = []
    for result in results:
        if not result["review"]:
            continue
        cluster = result["cluster"]
        suggestions = []
        seen = set()
        for source in ("inventory", "invoices", "register"):
            for record in cluster["records"][source]:
                for candidate in by_record.get((source, record["_id"]), []):
                    other = candidate.right if candidate.left is record else candidate.left
                    key = (other["_source"], other["_id"])
                    if key in seen:
                        continue
                    seen.add(key)
                    suggestions.append("%s %s — %s (%.0f%%)" % (
                        SOURCE_LABELS[other["_source"]], other["_id"],
                        (other.get("description") or "")[:60], candidate.score * 100))
        rows.append([
            cluster["id"], result["asset_label"],
            STATUS_LABELS[result["status"]], result["review_reason"],
            _codes_text(result), result["score"],
            ", ".join(SOURCE_LABELS[source] for source, present
                      in result["sources"].items() if present),
            _join(suggestions, limit=3), "", "",
        ])
    _table(worksheet, 4, headers, rows,
           widths=[9, 38, 26, 40, 32, 8, 28, 70, 16, 34],
           status_column=3, number_formats={6: SCORE_FORMAT})
    if rows:
        validation = DataValidation(type="list",
                                    formula1='"À vérifier,Validé,Rejeté"',
                                    allow_blank=True)
        worksheet.add_data_validation(validation)
        validation.add("I5:I%d" % (4 + len(rows)))
    return rows


def _sheet_duplicates(workbook, duplicates):
    worksheet = workbook.create_sheet("05_Doublons")
    _title(worksheet, "Doublons et enregistrements répétés",
           "Factures, codes d'actifs, numéros de série et écritures comptables.")
    headers = ["Code", "Sévérité", "Source", "Détail",
               "Enregistrement 1", "Enregistrement 2"]
    rows = []
    for duplicate in duplicates:
        records = duplicate["records"]
        rows.append([
            duplicate["code"],
            SEVERITY_LABELS.get(duplicate["severity"], duplicate["severity"]),
            SOURCE_LABELS.get(duplicate["source"], duplicate["source"]),
            duplicate["detail"],
            _record_ref(records[0]) if records else "",
            _record_ref(records[1]) if len(records) > 1 else "",
        ])
    _table(worksheet, 4, headers, rows,
           widths=[32, 10, 18, 70, 40, 40], severity_column=2)
    return rows


def _sheet_unmatched(workbook, data, results, headers):
    worksheet = workbook.create_sheet("06_Factures_non_rapprochees")
    _title(worksheet, "Factures et écritures non rapprochées",
           "Documents présents dans les sources mais sans actif identifié, ou actifs sans écriture.")

    matched_invoice_numbers = set()
    matched_gl_ids = set()
    for result in results:
        for line in result["cluster"]["records"]["invoices"]:
            if line.get("_invno_n"):
                matched_invoice_numbers.add(line["_invno_n"])
        for entry in result["cluster"]["gl"]:
            matched_gl_ids.add(entry["_id"])

    invoice_rows = []
    for header in headers:
        if header.get("invoice_number") and nz.norm_key(header["invoice_number"]) in \
                matched_invoice_numbers:
            continue
        invoice_rows.append([
            header.get("invoice_number"), header.get("supplier"),
            header.get("invoice_date"), header.get("total"),
            len(header.get("lines") or []),
            ", ".join(header.get("files") or []),
            "Aucun actif rapproché",
        ])

    worksheet.cell(row=4, column=1, value="Factures sans actif rapproché").font = Font(
        bold=True, size=12, color=NAVY)
    _table(worksheet, 5,
           ["N° facture", "Fournisseur", "Date", "Total", "Lignes",
            "Fichier", "Motif"],
           invoice_rows,
           widths=[18, 30, 12, 16, 8, 34, 34],
           number_formats={3: DATE_FORMAT, 4: MONEY_FORMAT})

    start = 5 + len(invoice_rows) + 3
    worksheet.cell(row=start, column=1,
                   value="Écritures du grand livre sans actif rapproché").font = Font(
        bold=True, size=12, color=NAVY)
    gl_rows = []
    for entry in data["gl"]["records"]:
        if entry["_id"] in matched_gl_ids:
            continue
        gl_rows.append([
            entry.get("entry_id"), entry.get("entry_date"), entry.get("account_code"),
            entry.get("account_label"), entry.get("description"),
            entry.get("debit"), entry.get("credit"),
            entry.get("invoice_number") or entry.get("document_ref"),
            _record_ref(entry),
        ])
    _table(worksheet, start + 1,
           ["N° écriture", "Date", "Compte", "Libellé compte", "Libellé",
            "Débit", "Crédit", "Pièce / facture", "Fichier / ligne"],
           gl_rows,
           widths=[14, 12, 12, 26, 46, 16, 16, 20, 30],
           number_formats={2: DATE_FORMAT, 6: MONEY_FORMAT, 7: MONEY_FORMAT})
    return invoice_rows, gl_rows


def _sheet_quality(workbook, data, results):
    worksheet = workbook.create_sheet("07_Qualite_donnees")
    _title(worksheet, "Qualité des données et anomalies d'import",
           "À traiter avant de conclure: colonnes non reconnues, dates invalides, champs vides, montants ambigus.")
    rows = []
    for source in ("inventory", "invoices", "register", "gl"):
        for issue in data[source]["issues"]:
            rows.append([SOURCE_LABELS[source], issue["file"], issue["code"],
                         issue["message"]])
    headers = ["Source", "Fichier", "Code", "Message"]
    _table(worksheet, 4, headers, rows, widths=[22, 30, 30, 100])
    return rows


def _sheet_extraction(workbook, data, results):
    worksheet = workbook.create_sheet("08_Journal_extraction")
    _title(worksheet, "Journal d'extraction des factures",
           "Provenance de chaque ligne extraite: fichier, page, confiance, statut de revue.")
    cluster_by_line = {}
    for result in results:
        for line in result["cluster"]["records"]["invoices"]:
            cluster_by_line[line["_id"]] = (result["cluster"]["id"],
                                            STATUS_LABELS[result["status"]])
    headers = ["Fichier source", "Page", "N° facture", "Fournisseur",
               "Date facture", "Désignation", "Marque", "Qté", "P.U.",
               "Montant ligne", "Total facture", "Confiance", "Statut revue",
               "Cluster", "Statut rapprochement"]
    rows = []
    for line in data["invoices"]["records"]:
        cluster_id, status = cluster_by_line.get(line["_id"], ("", "Non rapprochée"))
        rows.append([
            line.get("source_file") or line.get("_file"), line.get("source_page"),
            line.get("invoice_number"), line.get("supplier"),
            line.get("invoice_date"), line.get("description"), line.get("brand"),
            line.get("quantity"), line.get("unit_price"), line.get("line_total"),
            line.get("invoice_total"), line.get("extraction_confidence"),
            line.get("review_status") or "", cluster_id, status,
        ])
    _table(worksheet, 4, headers, rows,
           widths=[30, 7, 16, 26, 12, 40, 12, 7, 14, 16, 16, 10, 14, 9, 26],
           number_formats={5: DATE_FORMAT, 8: "#,##0", 9: MONEY_FORMAT,
                           10: MONEY_FORMAT, 11: MONEY_FORMAT, 12: SCORE_FORMAT})
    return rows


def _sheet_trace(workbook, data, context, results, duplicates):
    worksheet = workbook.create_sheet("09_Tracabilite")
    _title(worksheet, "Traçabilité de l'exécution",
           "Empreintes des fichiers, paramètres, volumes et résultats. À conserver au dossier d'audit.")
    rows = [
        ["Date d'exécution", context["generated_at"]],
        ["Moteur", context["version"]],
        ["Client / mission", context.get("client") or ""],
        ["Période", "%s → %s" % (context["period_start"], context["period_end"])],
        ["Devise", context.get("currency", "FCFA")],
        ["Groupes d'actifs", len(results)],
        ["Écarts", sum(len(result["codes"]) for result in results)],
        ["Doublons", len(duplicates)],
    ]
    row = 4
    for label, value in rows:
        worksheet.cell(row=row, column=1, value=label).font = Font(bold=True, size=10)
        cell = worksheet.cell(row=row, column=2, value=value)
        cell.font = Font(size=10)
        row += 1
    row += 1
    headers = ["Source", "Fichier", "SHA-256", "Feuilles", "Lignes"]
    for column, header in enumerate(headers, start=1):
        _header_cell(worksheet.cell(row=row, column=column, value=header))
    for source in ("inventory", "invoices", "register", "gl"):
        row += 1
        entry = data[source]
        values = [SOURCE_LABELS[source], entry["path"], entry["hash"],
                  ", ".join(entry["sheets"]), len(entry["records"])]
        for column, value in enumerate(values, start=1):
            cell = worksheet.cell(row=row, column=column, value=value)
            _body_cell(cell, wrap=True)
    row += 2
    worksheet.cell(row=row, column=1, value="Paramètres").font = Font(
        bold=True, size=12, color=NAVY)
    for key, value in context["config"].items():
        row += 1
        worksheet.cell(row=row, column=1, value=key).font = Font(size=10)
        worksheet.cell(row=row, column=2, value=str(value)).font = Font(size=10)
    _widths(worksheet, [34, 50, 70, 26, 10])
    worksheet.sheet_view.showGridLines = False


# --------------------------------------------------------------------- export

def write_workbook(path, context, results, duplicates, headers,
                   review_candidates, export_csv=True):
    workbook = Workbook()
    _sheet_readme(workbook, context)
    _sheet_dashboard(workbook, results, duplicates, context["data"],
                     context["config"], headers)
    _sheet_reconciliation(workbook, results)
    discrepancy_rows = _sheet_discrepancies(workbook, results)
    review_rows = _sheet_review(workbook, results, review_candidates)
    duplicate_rows = _sheet_duplicates(workbook, duplicates)
    invoice_rows, gl_rows = _sheet_unmatched(workbook, context["data"], results,
                                             headers)
    _sheet_quality(workbook, context["data"], results)
    _sheet_extraction(workbook, context["data"], results)
    _sheet_trace(workbook, context["data"], context, results, duplicates)

    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    workbook.save(path)

    if export_csv:
        directory = os.path.dirname(os.path.abspath(path))
        _write_csv(os.path.join(directory, "ecarts.csv"),
                   ["ID", "Code", "Libellé", "Sévérité", "Statut", "Actif",
                    "Cluster", "Source(s)", "Attendu", "Constaté", "Détail",
                    "Preuve", "Action", "Décision", "Commentaire"],
                   discrepancy_rows)
        _write_csv(os.path.join(directory, "verification_manuelle.csv"),
                   ["Cluster", "Actif", "Statut", "Raison", "Codes", "Score",
                    "Sources", "Correspondances proposées", "Décision",
                    "Commentaire"],
                   review_rows)
        _write_csv(os.path.join(directory, "factures_non_rapprochees.csv"),
                   ["N° facture", "Fournisseur", "Date", "Total", "Lignes",
                    "Fichier", "Motif"], invoice_rows)
        _write_csv(os.path.join(directory, "ecritures_non_rapprochees.csv"),
                   ["N° écriture", "Date", "Compte", "Libellé compte", "Libellé",
                    "Débit", "Crédit", "Pièce / facture", "Fichier / ligne"],
                   gl_rows)
        _write_csv(os.path.join(directory, "doublons.csv"),
                   ["Code", "Sévérité", "Source", "Détail",
                    "Enregistrement 1", "Enregistrement 2"], duplicate_rows)

    return {
        "workbook": path,
        "counts": {
            "clusters": len(results),
            "discrepancies": len(discrepancy_rows),
            "manual_review": len(review_rows),
            "duplicates": len(duplicate_rows),
            "unmatched_invoices": len(invoice_rows),
            "unmatched_gl": len(gl_rows),
        },
    }


def _write_csv(path, headers, rows):
    with open(path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle, delimiter=";")
        writer.writerow(headers)
        for row in rows:
            writer.writerow([_fmt(value) for value in row])
