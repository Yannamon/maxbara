"""Deterministic demo dataset used to test the engine end-to-end.

It intentionally contains: a 10-chair invoice with only 8 chairs counted, an
asset missing from the register, assets missing from the inventory, a duplicate
invoice scan, an invoice absent from the ledger, a ledger entry without an
asset, a description/brand variance, a site mismatch, a cut-off entry and a
low-confidence scan.
"""
from __future__ import annotations

import os

from openpyxl import Workbook

from .schema import SPECS

INVOICES = {
    "FAC-2021-001": {
        "supplier": "SUPRA INFO", "date": "2021-03-15",
        "file": "scan_fac_2021_001.pdf", "confidence": 0.97,
        "lines": [("PC portable HP EliteBook 840 G8", "HP", "840 G8", 2, 850000)],
    },
    "FAC-2021-014": {
        "supplier": "BUREAU PLUS", "date": "2021-06-10",
        "file": "scan_fac_2021_014.pdf", "confidence": 0.94,
        "lines": [("Imprimante laser HP LaserJet Pro M404", "HP", "M404", 1, 320000)],
    },
    "FAC-2022-007": {
        "supplier": "MOBILIER CI", "date": "2022-02-20",
        "file": "scan_fac_2022_007.pdf", "confidence": 0.96,
        "lines": [("Chaise bureau ergonomique", "GENERIC", "CH-100", 10, 120000)],
    },
    "FAC-2022-011": {
        "supplier": "ELECTRO CI", "date": "2022-04-05",
        "file": "scan_fac_2022_011.pdf", "confidence": 0.92,
        "lines": [("Climatiseur split Samsung 1.5CV", "SAMSUNG", "AR12", 2, 450000)],
    },
    "FAC-2022-030": {
        "supplier": "AUTO CI", "date": "2022-09-01",
        "file": "scan_fac_2022_030.pdf", "confidence": 0.98,
        "lines": [("Toyota Hilux double cabine", "TOYOTA", "HILUX", 1, 18000000)],
    },
    "FAC-2023-002": {
        "supplier": "SUPRA INFO", "date": "2023-01-20",
        "file": "scan_fac_2023_002.pdf", "confidence": 0.95,
        "lines": [("Serveur Dell PowerEdge R740", "DELL", "R740", 1, 4500000)],
    },
    "FAC-2023-009": {
        "supplier": "BUREAU PLUS", "date": "2023-03-11",
        "file": "scan_fac_2023_009.pdf", "confidence": 0.93,
        "lines": [("Photocopieur Canon IR2625", "CANON", "IR2625", 1, 2300000)],
    },
    "FAC-2023-021": {
        "supplier": "ENERGY CI", "date": "2023-07-01",
        "file": "scan_fac_2023_021.pdf", "confidence": 0.91,
        "lines": [("Groupe électrogène 100 KVA", "CATERPILLAR", "DE100", 1, 7500000),
                  ("Onduleur APC Smart-UPS 3000VA", "APC", "SUA3000", 2, 550000)],
    },
    "FAC-2024-003": {
        "supplier": "MOBILIER CI", "date": "2024-01-15",
        "file": "scan_fac_2024_003.pdf", "confidence": 0.96,
        "lines": [("Table de réunion 12 places", "GENERIC", "TR-12", 1, 650000)],
    },
    "FAC-2024-006": {
        "supplier": "SUPRA INFO", "date": "2024-02-02",
        "file": "scan_fac_2024_006.pdf", "confidence": 0.95,
        "lines": [("Ordinateur de bureau Dell OptiPlex 7090", "DELL", "7090", 1, 780000),
                  ("Téléphone IP Cisco 8841", "CISCO", "8841", 5, 90000)],
    },
    "FAC-2024-019": {
        "supplier": "BUREAU PLUS", "date": "2024-06-18",
        "file": "scan_fac_2024_019.pdf", "confidence": 0.90,
        "lines": [("Imprimante Epson L3150", "EPSON", "L3150", 1, 185000),
                  ("Vidéoprojecteur Epson EB-X51", "EPSON", "EB-X51", 1, 420000)],
    },
    "FAC-2024-025": {
        "supplier": "BUREAU PLUS", "date": "2024-09-01",
        "file": "scan_fac_2024_025.pdf", "confidence": 0.94,
        "lines": [("Photocopieur Ricoh MP 2014", "RICOH", "MP2014", 1, 1800000)],
    },
    "FAC-2025-004": {
        "supplier": "ELECTRO CI", "date": "2025-02-10",
        "file": "scan_fac_2025_004.pdf", "confidence": 0.93,
        "lines": [("Machine à laver Samsung 8 kg", "SAMSUNG", "WW80", 1, 350000),
                  ("Réfrigérateur Samsung 400 L", "SAMSUNG", "RT40", 1, 480000)],
    },
    "FAC-2025-008": {
        "supplier": "SUPRA INFO", "date": "2025-03-05",
        "file": "scan_fac_2025_008.pdf", "confidence": 0.96,
        "lines": [("Ordinateur portable Lenovo ThinkPad T14", "LENOVO", "T14", 1, 920000)],
    },
    "FAC-2025-009": {
        "supplier": "MOBILIER CI", "date": "2025-03-05",
        "file": "scan_fac_2025_009.pdf", "confidence": 0.95,
        "lines": [("Chaise visiteur", "GENERIC", "CH-200", 6, 60000)],
    },
    "FAC-2025-011": {
        "supplier": "SOFT CI", "date": "2025-04-01",
        "file": "scan_fac_2025_011.pdf", "confidence": 0.90,
        "lines": [("Logiciel de gestion Sage 100", "SAGE", "100", 1, 1500000)],
    },
    "FAC-2025-015": {
        "supplier": "ELECTRO CI", "date": "2025-05-12",
        "file": "scan_fac_2025_015.pdf", "confidence": 0.92,
        "lines": [("Climatiseur split LG 1CV", "LG", "S4-Q12", 1, 450000)],
    },
    "FAC-2025-018": {
        "supplier": "AUTO CI", "date": "2025-06-01",
        "file": "scan_fac_2025_018.pdf", "confidence": 0.97,
        "lines": [("Toyota Hiace", "TOYOTA", "HIACE", 1, 22000000)],
    },
    "FAC-2025-020": {
        "supplier": "MOBILIER CI", "date": "2025-06-20",
        "file": "scan_fac_2025_020.pdf", "confidence": 0.94,
        "lines": [("Étagère métallique 4 niveaux", "GENERIC", "ET-4", 8, 30000)],
    },
    "FAC-2025-022": {
        "supplier": "SUPRA INFO", "date": "2025-07-02",
        "file": "scan_fac_2025_022.pdf", "confidence": 0.95,
        "lines": [("Switch Cisco SG250 24 ports", "CISCO", "SG250", 1, 550000)],
    },
    "FAC-2025-026": {
        "supplier": "ENERGY CI", "date": "2025-08-10",
        "file": "scan_fac_2025_026.pdf", "confidence": 0.55,
        "lines": [("Onduleur Eaton 5S1500", "EATON", "5S1500", 1, 380000)],
    },
}

# code, description, family, brand, model, serial, qty, acquisition, supplier,
# invoice, cost, site, status, in_service, disposal, gl_account, inventory_qty
REGISTER = [
    ("IMM-001", "Ordinateur portable HP EliteBook 840 G8", "INFORMATIQUE", "HP",
     "EliteBook 840 G8", "SN-HP-001", 1, "2021-03-15", "SUPRA INFO",
     "FAC-2021-001", 850000, "Abidjan", "ACTIF", "2021-03-20", None, "244100", 1),
    ("IMM-002", "Ordinateur portable HP EliteBook 840 G8", "INFORMATIQUE", "HP",
     "EliteBook 840 G8", "SN-HP-002", 1, "2021-03-15", "SUPRA INFO",
     "FAC-2021-001", 850000, "Abidjan", "ACTIF", "2021-03-20", None, "244100", 1),
    ("IMM-003", "Imprimante laser HP LaserJet Pro M404", "IMPRIMANTE", "HP",
     "M404", "SN-HP-003", 1, "2021-06-10", "BUREAU PLUS",
     "FAC-2021-014", 320000, "Abidjan", "ACTIF", "2021-06-15", None, "244100", 1),
    ("IMM-004", "Chaise de bureau ergonomique", "MOBILIER", "GENERIC",
     "CH-100", "", 10, "2022-02-20", "MOBILIER CI",
     "FAC-2022-007", 1200000, "Abidjan", "ACTIF", "2022-02-25", None, "244200", 8),
    ("IMM-005", "Climatiseur split Samsung 1.5CV", "CLIMATISATION", "SAMSUNG",
     "AR12", "", 2, "2022-04-05", "ELECTRO CI",
     "FAC-2022-011", 900000, "Yamoussoukro", "ACTIF", "2022-04-10", None, "244300", 2),
    ("IMM-006", "Véhicule Toyota Hilux", "VEHICULE", "TOYOTA",
     "HILUX", "SN-VIN-006", 1, "2022-09-01", "AUTO CI",
     "FAC-2022-030", 18000000, "Abidjan", "ACTIF", "2022-09-05", None, "245100", 1),
    ("IMM-007", "Serveur Dell PowerEdge R740", "INFORMATIQUE", "DELL",
     "R740", "SN-DELL-007", 1, "2023-01-20", "SUPRA INFO",
     "FAC-2023-002", 4500000, "Abidjan", "ACTIF", "2023-01-25", None, "244100", 1),
    ("IMM-008", "Photocopieur Canon imageRUNNER", "PHOTOCOPIEUR", "CANON",
     "IR2625", "SN-CANON-008", 1, "2023-03-11", "BUREAU PLUS",
     "FAC-2023-009", 2300000, "Abidjan", "ACTIF", "2023-03-15", None, "244100", 1),
    ("IMM-009", "Groupe électrogène 100 KVA", "ENERGIE", "CATERPILLAR",
     "DE100", "SN-GEN-009", 1, "2023-07-01", "ENERGY CI",
     "FAC-2023-021", 7500000, "Yamoussoukro", "ACTIF", "2023-07-10", None, "244300", 1),
    ("IMM-010", "Onduleur APC 3000VA", "ENERGIE", "APC",
     "SUA3000", "SN-APC-010", 2, "2023-07-01", "ENERGY CI",
     "FAC-2023-021", 1100000, "Yamoussoukro", "ACTIF", "2023-07-10", None, "244300", 2),
    ("IMM-011", "Table de réunion 12 places", "MOBILIER", "GENERIC",
     "TR-12", "", 1, "2024-01-15", "MOBILIER CI",
     "FAC-2024-003", 620000, "Abidjan", "ACTIF", "2024-01-20", None, "244200", 1),
    ("IMM-012", "Ordinateur de bureau Dell OptiPlex 7090", "INFORMATIQUE", "DELL",
     "7090", "SN-DELL-012", 1, "2024-02-02", "SUPRA INFO",
     "FAC-2024-006", 780000, "Abidjan", "ACTIF", "2024-02-10", None, "244100", 1),
    ("IMM-013", "Téléphone IP Cisco 8841", "TELEPHONIE", "CISCO",
     "8841", "", 5, "2024-02-02", "SUPRA INFO",
     "FAC-2024-006", 450000, "Abidjan", "ACTIF", "2024-02-10", None, "244100", 5),
    ("IMM-014", "Imprimante multifonction Epson L3150", "IMPRIMANTE", "EPSON",
     "L3150", "SN-EPSON-014", 1, "2024-06-18", "BUREAU PLUS",
     "FAC-2024-019", 185000, "Yamoussoukro", "ACTIF", "2024-06-25", None, "244100", 1),
    ("IMM-015", "Vidéoprojecteur Epson EB-X51", "AUDIOVISUEL", "EPSON",
     "EB-X51", "SN-EPSON-015", 1, "2024-06-18", "BUREAU PLUS",
     "FAC-2024-019", 420000, "Abidjan", "ACTIF", "2024-06-25", None, "244100", 1),
    ("IMM-016", "Machine à laver Samsung 8kg", "ELECTROMENAGER", "SAMSUNG",
     "WW80", "SN-SAM-016", 1, "2025-02-10", "ELECTRO CI",
     "FAC-2025-004", 350000, "Yamoussoukro", "ACTIF", "2025-02-15", None, "244400", 1),
    ("IMM-017", "Réfrigérateur Samsung 400L", "ELECTROMENAGER", "SAMSUNG",
     "RT40", "SN-SAM-017", 1, "2025-02-10", "ELECTRO CI",
     "FAC-2025-004", 480000, "Yamoussoukro", "ACTIF", "2025-02-15", None, "244400", 1),
    ("IMM-018", "Ordinateur portable Lenovo ThinkPad T14", "INFORMATIQUE", "LENOVO",
     "T14", "SN-LEN-018", 1, "2025-03-05", "SUPRA INFO",
     "FAC-2025-008", 920000, "Abidjan", "ACTIF", "2025-03-10", None, "244100", 1),
    ("IMM-019", "Chaise visiteur", "MOBILIER", "GENERIC",
     "CH-200", "", 6, "2025-03-05", "MOBILIER CI",
     "FAC-2025-009", 360000, "Abidjan", "ACTIF", "2025-03-10", None, "244200", 6),
    ("IMM-020", "Logiciel de gestion Sage 100", "LOGICIEL", "SAGE",
     "100", "LICENSE-SAGE", 1, "2025-04-01", "SOFT CI",
     "FAC-2025-011", 1500000, "Abidjan", "ACTIF", "2025-04-01", None, "241000", 0),
    ("IMM-021", "Climatiseur split LG 1CV", "CLIMATISATION", "SAMSUNG",
     "S4-Q12", "", 1, "2025-05-12", "ELECTRO CI",
     "FAC-2025-015", 450000, "Yamoussoukro", "ACTIF", "2025-05-20", None, "244300", 1),
    ("IMM-022", "Camionnette Toyota Hiace", "VEHICULE", "TOYOTA",
     "HIACE", "SN-VIN-022", 1, "2025-05-01", "AUTO CI",
     "FAC-2025-018", 22000000, "Abidjan", "ACTIF", "2025-06-10", None, "245100", 1),
    ("IMM-023", "Étagère métallique", "MOBILIER", "GENERIC",
     "ET-4", "", 8, "2025-06-20", "MOBILIER CI",
     "FAC-2025-020", 240000, "Yamoussoukro", "ACTIF", "2025-06-25", None, "244200", 8),
    ("IMM-024", "Switch Cisco 24 ports", "RESEAU", "CISCO",
     "SG250", "SN-CISCO-024", 1, "2025-07-02", "SUPRA INFO",
     "FAC-2025-022", 550000, "Abidjan", "ACTIF", "2025-07-10", None, "244100", 1),
    ("IMM-025", "Imprimante HP LaserJet 1102", "IMPRIMANTE", "HP",
     "1102", "SN-HP-025", 1, "2020-05-10", "BUREAU PLUS",
     "", 250000, "Abidjan", "ACTIF", "2020-05-15", None, "244100", 1),
    ("IMM-026", "Photocopieur Ricoh MP 2014", "PHOTOCOPIEUR", "RICOH",
     "MP2014", "SN-RICOH-026", 1, "2024-09-01", "BUREAU PLUS",
     "FAC-2024-025", 1800000, "Abidjan", "ACTIF", "2024-09-05", None, "244100", 0),
    ("IMM-027", "Onduleur Eaton 1500VA", "ENERGIE", "EATON",
     "5S1500", "SN-EATON-027", 1, "2025-08-10", "ENERGY CI",
     "FAC-2025-026", 380000, "Abidjan", "ACTIF", "2025-08-15", None, "244300", 0),
]

UNREGISTERED_INVENTORY = [
    ("", "Climatiseur split Midea 1CV", "CLIMATISATION", "MIDEA", "MSA-12",
     "", 1, "Yamoussoukro", "Bon"),
    ("", "Bureau directeur en bois", "MOBILIER", "", "BD-01",
     "", 1, "Abidjan", "Moyen"),
]


def _headers(source):
    return [definition[0] for definition in SPECS[source]["fields"].values()]


def _write(source, path, rows):
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = "Données"
    for column, header in enumerate(_headers(source), start=1):
        worksheet.cell(row=1, column=column, value=header)
    fields = list(SPECS[source]["fields"].keys())
    for row_index, row in enumerate(rows, start=2):
        for column, field in enumerate(fields, start=1):
            value = row.get(field, "")
            worksheet.cell(row=row_index, column=column, value=value)
    worksheet.freeze_panes = "A2"
    os.makedirs(os.path.dirname(path), exist_ok=True)
    workbook.save(path)
    return path


def write_sample_data(directory):
    inventory_rows = []
    for (code, description, family, brand, model, serial, qty, acquisition,
         supplier, invoice, cost, site, status, in_service, disposal, account,
         counted) in REGISTER:
        for unit in range(counted or 0):
            inventory_rows.append({
                "asset_code": code if counted == 1 else "%s-%02d" % (code, unit + 1),
                "site": "Abidjan" if code == "IMM-014" else site,
                "location": "Siège" if site == "Abidjan" else "Agence",
                "family": family,
                "description": description,
                "brand": brand,
                "model": model,
                "serial_number": serial if counted == 1 else "",
                "colour": "Noir",
                "condition": "Bon" if unit % 4 else "Moyen",
                "quantity": 1,
                "acquisition_date": acquisition,
                "count_date": "2025-11-05",
                "label_status": "Étiqueté" if unit % 3 else "Non étiqueté",
                "notes": "",
            })
    for (code, description, family, brand, model, serial, qty, site,
         condition) in UNREGISTERED_INVENTORY:
        inventory_rows.append({
            "asset_code": code, "site": site, "location": "Site",
            "family": family, "description": description, "brand": brand,
            "model": model, "serial_number": serial, "colour": "Blanc",
            "condition": condition, "quantity": qty,
            "acquisition_date": "", "count_date": "2025-11-06",
            "label_status": "Non étiqueté", "notes": "Trouvé au comptage",
        })

    register_rows = []
    for (code, description, family, brand, model, serial, qty, acquisition,
         supplier, invoice, cost, site, status, in_service, disposal, account,
         counted) in REGISTER:
        register_rows.append({
            "asset_code": code, "description": description, "family": family,
            "brand": brand, "model": model, "serial_number": serial,
            "quantity": qty, "acquisition_date": acquisition,
            "in_service_date": in_service, "supplier": supplier,
            "invoice_number": invoice, "cost": cost, "currency": "FCFA",
            "site": site, "depreciation_method": "Linéaire",
            "useful_life_years": 3 if "INFORMATIQUE" in family else 5,
            "accumulated_depreciation": round(cost * 0.4, 0),
            "net_book_value": round(cost * 0.6, 0), "status": status,
            "disposal_date": disposal or "", "gl_account": account,
        })

    invoice_rows = []
    for number, header in INVOICES.items():
        total = sum(line[3] * line[4] for line in header["lines"])
        for line_number, (description, brand, model, qty, unit) in enumerate(
                header["lines"], start=1):
            invoice_rows.append({
                "invoice_number": number, "supplier": header["supplier"],
                "invoice_date": header["date"], "delivery_date": header["date"],
                "description": description, "brand": brand, "model": model,
                "quantity": qty, "unit_price": unit, "line_total": qty * unit,
                "invoice_total": total, "tax_amount": 0, "currency": "FCFA",
                "line_no": line_number, "po_number": "",
                "asset_code": "",
                "source_file": header["file"], "source_page": 1,
                "extraction_confidence": header["confidence"],
                "review_status": "Relu" if header["confidence"] >= 0.9 else "À relire",
            })
    # Duplicate scan of FAC-2023-009 in a second file.
    for line in list(invoice_rows):
        if line["invoice_number"] == "FAC-2023-009":
            duplicate = dict(line)
            duplicate["source_file"] = "scan_doublon_fac_2023_009.pdf"
            invoice_rows.append(duplicate)
            break

    gl_rows = []
    entry = 1
    for number, header in INVOICES.items():
        if number == "FAC-2025-020":
            continue
        total = sum(line[3] * line[4] for line in header["lines"])
        entry_date = header["date"]
        if number == "FAC-2024-019":
            entry_date = "2024-12-30"
        if number == "FAC-2024-025":
            entry_date = "2025-01-15"
        gl_rows.append({
            "entry_id": "EC-%s-%03d" % (header["date"][:4], entry),
            "journal": "AC", "account_code": "244100",
            "account_label": "Matériel et outillage",
            "entry_date": entry_date, "document_ref": number,
            "description": "Acquisition %s" % header["lines"][0][0],
            "debit": total, "credit": 0, "supplier": header["supplier"],
            "invoice_number": number, "asset_code": "",
            "fiscal_year": entry_date[:4], "posting_status": "Validée",
        })
        entry += 1
    gl_rows.append({
        "entry_id": "EC-2025-900", "journal": "OD", "account_code": "244300",
        "account_label": "Installations techniques", "entry_date": "2025-09-30",
        "document_ref": "", "description": "Frais d'installation immobilisés",
        "debit": 350000, "credit": 0, "supplier": "ENERGY CI",
        "invoice_number": "", "asset_code": "", "fiscal_year": 2025,
        "posting_status": "Validée",
    })

    return {
        "inventory": _write("inventory", os.path.join(directory, "inventaire.xlsx"),
                            inventory_rows),
        "invoices": _write("invoices", os.path.join(directory, "factures.xlsx"),
                           invoice_rows),
        "register": _write("register", os.path.join(directory, "registre.xlsx"),
                           register_rows),
        "gl": _write("gl", os.path.join(directory, "grand_livre.xlsx"), gl_rows),
    }
