"""Audit rules: turn matched clusters into findings and a reconciliation status.

Every finding carries a severity, the expected and observed values, the
source evidence and a suggested action. Statuses follow the audit brief:
fully reconciled, partially reconciled, discrepancy, missing document,
manual verification.
"""
from __future__ import annotations

from . import normalize as nz

CODES = {
    "INV_NOT_IN_REGISTER": {
        "severity": "H",
        "label": "Actif inventorié absent du registre",
        "action": "Rattacher l'actif au registre ou justifier sa sortie / son absence.",
    },
    "REGISTERED_NOT_FOUND": {
        "severity": "H",
        "label": "Actif au registre non retrouvé physiquement",
        "action": "Localiser l'actif, constater sa sortie ou engager une procédure de manquant.",
    },
    "NO_INVOICE": {
        "severity": "H",
        "label": "Actif sans facture justificative",
        "action": "Obtenir la facture, le bon de livraison ou documenter l'acquisition.",
    },
    "INVOICE_NOT_IN_GL": {
        "severity": "H",
        "label": "Facture non comptabilisée au grand livre",
        "action": "Rechercher l'écriture, régulariser ou justifier le hors livre.",
    },
    "REGISTER_WITHOUT_GL": {
        "severity": "H",
        "label": "Actif au registre sans écriture au grand livre",
        "action": "Rapprocher le registre du compte d'immobilisation et corriger.",
    },
    "GL_WITHOUT_ASSET": {
        "severity": "H",
        "label": "Écriture d'immobilisation sans actif identifié",
        "action": "Identifier l'actif financé ou requalifier l'écriture.",
    },
    "QTY_MISMATCH": {
        "severity": "H",
        "label": "Écart de quantité",
        "action": "Recompter, vérifier la ventilation des lignes et corriger la source erronée.",
    },
    "AMOUNT_MISMATCH": {
        "severity": "H",
        "label": "Écart de montant facture / registre",
        "action": "Vérifier la TVA, les frais accessoires et la ventilation comptable.",
    },
    "GL_AMOUNT_MISMATCH": {
        "severity": "H",
        "label": "Écart de montant facture / grand livre",
        "action": "Rapprocher le total facture du débit du compte d'immobilisation.",
    },
    "ASSET_NOT_IDENTIFIED": {
        "severity": "H",
        "label": "Facture sans actif identifié",
        "action": "Identifier le bien acheté et le rattacher au registre et à l'inventaire.",
    },
    "INVOICE_ARITHMETIC": {
        "severity": "M",
        "label": "Incohérence arithmétique de la facture",
        "action": "Contrôler quantité × prix unitaire et le total facture.",
    },
    "INVOICE_TOTAL_MISMATCH": {
        "severity": "M",
        "label": "Total facture différent de la somme des lignes",
        "action": "Vérifier les lignes non extraites, les remises et les frais de port.",
    },
    "DATE_BEFORE_INVOICE": {
        "severity": "M",
        "label": "Acquisition antérieure à la facture",
        "action": "Vérifier la date d'entrée en service et l'exercice de rattachement.",
    },
    "LATE_CAPITALISATION": {
        "severity": "M",
        "label": "Mise en service tardive",
        "action": "Vérifier le déclenchement de l'amortissement et le cut-off.",
    },
    "LATE_POSTING": {
        "severity": "M",
        "label": "Comptabilisation tardive",
        "action": "Vérifier la date d'écriture et le rattachement à l'exercice.",
    },
    "CUTOFF_YEAR": {
        "severity": "M",
        "label": "Écriture sur un exercice différent de la facture",
        "action": "Analyser le cut-off et les charges à payer / factures non parvenues.",
    },
    "DESC_VARIANCE": {
        "severity": "L",
        "label": "Désignation variable entre sources",
        "action": "Confirmer que les libellés désignent bien le même actif.",
    },
    "BRAND_MISMATCH": {
        "severity": "L",
        "label": "Marque différente entre sources",
        "action": "Vérifier la marque réelle et corriger la source erronée.",
    },
    "MODEL_MISMATCH": {
        "severity": "L",
        "label": "Modèle différent entre sources",
        "action": "Vérifier la référence constructeur.",
    },
    "SITE_MISMATCH": {
        "severity": "L",
        "label": "Site différent entre registre et inventaire",
        "action": "Confirmer la localisation et mettre à jour le registre.",
    },
    "STATUS_MISMATCH": {
        "severity": "M",
        "label": "Statut du registre incohérent avec le terrain",
        "action": "Mettre à jour le statut (actif, cédé, rebut) et la date de sortie.",
    },
    "PRE_PERIOD_ASSET": {
        "severity": "L",
        "label": "Actif acquis avant la période auditée",
        "action": "Confirmer le périmètre; facture et écriture d'origine hors période.",
    },
    "OUT_OF_PERIOD": {
        "severity": "L",
        "label": "Date hors de la période auditée",
        "action": "Vérifier le périmètre et les exercices couverts.",
    },
    "LOW_CONFIDENCE_EXTRACTION": {
        "severity": "M",
        "label": "Extraction de facture à faible confiance",
        "action": "Relire la facture source et corriger les champs extraits.",
    },
    "MISSING_CRITICAL_FIELD": {
        "severity": "M",
        "label": "Champ critique manquant",
        "action": "Compléter la donnée depuis le document source.",
    },
    "AMBIGUOUS_MATCH": {
        "severity": "M",
        "label": "Rapprochement ambigu",
        "action": "Valider ou rejeter le rapprochement proposé.",
    },
    "UNMATCHED_INVOICE_LINE": {
        "severity": "M",
        "label": "Ligne de facture non rapprochée",
        "action": "Identifier l'actif ou justifier la charge.",
    },
    "UNMATCHED_GL_ENTRY": {
        "severity": "M",
        "label": "Écriture non rapprochée",
        "action": "Identifier la facture ou l'actif correspondant.",
    },
    "INTANGIBLE_NO_PHYSICAL": {
        "severity": "L",
        "label": "Immobilisation incorporelle sans existence physique",
        "action": "Contrôler le titre de propriété ou la licence, pas le comptage.",
    },
}

DISPOSED_WORDS = ("CESSION", "CEDE", "SORTI", "SORTIE", "REBUT", "DISPOSED",
                  "SOLD", "RETIRED", "MISE AU REBUT", "TRANSFERE")
INTANGIBLE_WORDS = ("LOGICIEL", "LICENCE", "LICENSE", "BREVET", "MARQUE",
                    "FONDS DE COMMERCE", "GOODWILL", "INCORPORELLE", "SITE WEB",
                    "NOM DE DOMAINE", "DROIT AU BAIL", "CLIENTELE")


def _is_intangible(records):
    for record in records:
        text = nz.norm_text((record.get("description") or "") + " "
                            + (record.get("family") or ""))
        if any(word in text for word in INTANGIBLE_WORDS):
            return True
    return False


def _is_disposed(records):
    for record in records:
        status = nz.norm_text(record.get("status") or "")
        if any(word in status for word in DISPOSED_WORDS):
            return True
        disposal = record.get("disposal_date")
        if disposal:
            return True
    return False


def _unique(values):
    seen, out = set(), []
    for value in values:
        if value is None or value == "":
            continue
        key = str(value)
        if key not in seen:
            seen.add(key)
            out.append(value)
    return out


def _fmt(value):
    if value is None or value == "":
        return ""
    if isinstance(value, float):
        return ("%.2f" % value).rstrip("0").rstrip(".")
    return str(value)


def evaluate_all(clusters, data, config, headers):
    headers_by_invoice = {}
    for header in headers:
        key = header.get("invoice_number")
        if key:
            headers_by_invoice.setdefault(nz.norm_key(key), []).append(header)

    results = []
    for cluster in clusters:
        results.append(evaluate_cluster(cluster, data, config, headers_by_invoice))
    return results


def evaluate_cluster(cluster, data, config, headers_by_invoice):
    inventory = cluster["records"]["inventory"]
    register = cluster["records"]["register"]
    invoices = cluster["records"]["invoices"]
    gl = cluster["gl"]

    has_inv = bool(inventory)
    has_reg = bool(register)
    has_invoice = bool(invoices)
    has_gl = bool(gl)
    intangible = _is_intangible(register + inventory)
    disposed = _is_disposed(register)
    period_start = config.get("period_start")
    period_end = config.get("period_end")

    codes = []
    manual_reasons = []

    def add(code, detail, expected=None, observed=None):
        spec = CODES[code]
        codes.append({
            "code": code,
            "severity": spec["severity"],
            "label": spec["label"],
            "detail": detail,
            "expected": _fmt(expected),
            "observed": _fmt(observed),
            "action": spec["action"],
        })

    descriptions = _unique([record.get("description") for record in
                            register + invoices + inventory])
    asset_label = descriptions[0] if descriptions else ""
    if len(descriptions) > 1:
        asset_label = descriptions[0] + " / " + descriptions[1]

    # ---------------------------------------------------------- existence
    if has_inv and not has_reg:
        if intangible:
            add("INTANGIBLE_NO_PHYSICAL",
                "Actif incorporel présent au comptage, absent du registre")
        else:
            add("INV_NOT_IN_REGISTER",
                "Actif identifié physiquement mais absent du registre",
                expected="1 actif au registre", observed="0")
    if has_reg and not has_inv:
        if intangible:
            add("INTANGIBLE_NO_PHYSICAL",
                "Immobilisation incorporelle: pas de comptage physique attendu")
        elif not disposed:
            add("REGISTERED_NOT_FOUND",
                "Actif inscrit au registre mais non identifié lors de l'inventaire",
                expected="1 actif physique", observed="0")

    if not has_reg and not has_inv and has_invoice:
        add("ASSET_NOT_IDENTIFIED",
            "Facture sans actif correspondant au registre ni à l'inventaire")

    # ---------------------------------------------------------- documents
    invoice_dates = [line["invoice_date"] for line in invoices
                     if line.get("invoice_date")]
    register_dates = [asset["acquisition_date"] for asset in register
                      if asset.get("acquisition_date")]
    earliest_register_date = min(register_dates) if register_dates else None
    pre_period = bool(period_start and earliest_register_date
                      and earliest_register_date < period_start)

    if (has_inv or has_reg) and not has_invoice and not intangible:
        if pre_period:
            add("PRE_PERIOD_ASSET",
                "Actif acquis avant la période: facture hors périmètre",
                expected="facture dans la période",
                observed=earliest_register_date)
        else:
            add("NO_INVOICE", "Aucune facture rapprochée pour cet actif")

    if has_invoice and not has_gl:
        add("INVOICE_NOT_IN_GL", "Facture rapprochée mais aucune écriture au grand livre")
    if has_reg and not has_gl and not has_invoice:
        add("REGISTER_WITHOUT_GL", "Actif au registre sans écriture au grand livre")

    # ---------------------------------------------------------- quantities
    inv_qty = sum(record.get("quantity") or 0 for record in inventory) if has_inv else None
    reg_qty = sum(record.get("quantity") or 0 for record in register) if has_reg else None
    line_qty = sum(line.get("quantity") or 0 for line in invoices) if has_invoice else None
    quantities = [value for value in (inv_qty, reg_qty, line_qty) if value is not None]
    if len(set(round(value, 4) for value in quantities)) > 1:
        add("QTY_MISMATCH", "Quantités différentes entre les sources",
            expected=("facture %s / registre %s" % (_fmt(line_qty), _fmt(reg_qty))),
            observed=("inventaire %s" % _fmt(inv_qty)))

    # ---------------------------------------------------------- amounts
    reg_cost = sum(record.get("cost") or 0 for record in register) if has_reg else None
    line_total = sum(line.get("line_total") or 0 for line in invoices) if has_invoice else None
    if reg_cost is not None and line_total is not None:
        if not nz.money_equal(reg_cost, line_total, config["amount_tolerance_abs"],
                              config["amount_tolerance_pct"]):
            add("AMOUNT_MISMATCH", "Montant facturé et valeur au registre différents",
                expected=line_total, observed=reg_cost)

    # Invoice arithmetic per line.
    for line in invoices:
        qty = line.get("quantity")
        unit = line.get("unit_price")
        total = line.get("line_total")
        if qty and unit and total:
            expected = round(qty * unit, 2)
            if not nz.money_equal(expected, total, max(2.0, 0.001 * abs(expected)), 0.001):
                add("INVOICE_ARITHMETIC",
                    "Ligne %s: quantité × prix unitaire ≠ montant ligne"
                    % (line.get("line_no") or line.get("_id")),
                    expected=expected, observed=total)

    # Invoice total versus sum of extracted lines.
    seen_headers = set()
    header_total = 0.0
    for line in invoices:
        key = nz.norm_key(line.get("invoice_number"))
        for header in headers_by_invoice.get(key, []):
            if id(header) in seen_headers:
                continue
            seen_headers.add(id(header))
            if header.get("total_mismatch"):
                add("INVOICE_TOTAL_MISMATCH",
                    "Facture %s: total déclaré %s, somme des lignes %s"
                    % (header["invoice_number"], _fmt(header["total_stated"]),
                       _fmt(header["total_lines"])),
                    expected=header["total_stated"], observed=header["total_lines"])
            if header.get("total") is not None:
                header_total += header["total"]

    if has_gl and invoices:
        gl_amount = sum(entry.get("debit") or 0 for entry in gl)
        if not gl_amount:
            gl_amount = sum(entry.get("credit") or 0 for entry in gl)
        reference = header_total or line_total
        if reference and gl_amount:
            if not nz.money_equal(gl_amount, reference,
                                  max(config["amount_tolerance_abs"], 1000),
                                  max(config["amount_tolerance_pct"], 0.02)):
                add("GL_AMOUNT_MISMATCH",
                    "Débit du grand livre différent du total facture",
                    expected=reference, observed=gl_amount)

    # ---------------------------------------------------------- dates
    invoice_date = min(invoice_dates) if invoice_dates else None
    acquisition_date = min(register_dates) if register_dates else None
    service_dates = [asset["in_service_date"] for asset in register
                     if asset.get("in_service_date")]
    service_date = min(service_dates) if service_dates else None
    gl_dates = [entry["entry_date"] for entry in gl if entry.get("entry_date")]
    gl_date = min(gl_dates) if gl_dates else None

    if invoice_date and acquisition_date:
        if (acquisition_date - invoice_date).days < -30:
            add("DATE_BEFORE_INVOICE",
                "Date d'acquisition antérieure de plus de 30 jours à la facture",
                expected=invoice_date, observed=acquisition_date)
        if service_date and (service_date - invoice_date).days > 90:
            add("LATE_CAPITALISATION",
                "Mise en service plus de 90 jours après la facture",
                expected=invoice_date, observed=service_date)
    if invoice_date and gl_date and (gl_date - invoice_date).days > 60:
        add("LATE_POSTING", "Écriture comptabilisée plus de 60 jours après la facture",
            expected=invoice_date, observed=gl_date)
    if invoice_date and gl_date and invoice_date.year != gl_date.year:
        add("CUTOFF_YEAR", "Facture et écriture sur deux exercices différents",
            expected=invoice_date.year, observed=gl_date.year)

    if period_start and period_end:
        for label, value in (("facture", invoice_date), ("acquisition", acquisition_date),
                             ("écriture", gl_date)):
            if value and not (period_start <= value <= period_end):
                add("OUT_OF_PERIOD", "%s hors période (%s → %s)"
                    % (label, period_start, period_end), observed=value)

    # ---------------------------------------------------------- descriptions
    if has_invoice and has_reg:
        for line in invoices:
            for asset in register:
                similarity = nz.similarity(line.get("_desc_tokens"),
                                           asset.get("_desc_tokens"))
                if similarity < 0.60:
                    add("DESC_VARIANCE",
                        "Libellés différents: « %s » / « %s » (%.0f%%)"
                        % (line.get("description"), asset.get("description"),
                           similarity * 100))
                if (line.get("_brand_n") and asset.get("_brand_n")
                        and line["_brand_n"] != asset["_brand_n"]):
                    add("BRAND_MISMATCH", "Marques différentes entre facture et registre",
                        expected=line.get("brand"), observed=asset.get("brand"))
                if (line.get("_model_n") and asset.get("_model_n")
                        and nz.similarity(line["_model_n"], asset["_model_n"]) < 0.6):
                    add("MODEL_MISMATCH", "Modèles différents entre facture et registre",
                        expected=line.get("model"), observed=asset.get("model"))

    if has_inv and has_reg:
        inv_sites = _unique([record.get("site") for record in inventory])
        reg_sites = _unique([record.get("site") for record in register])
        if inv_sites and reg_sites and set(map(nz.norm_text, inv_sites)) != set(
                map(nz.norm_text, reg_sites)):
            add("SITE_MISMATCH", "Sites différents entre inventaire et registre",
                expected=", ".join(map(str, reg_sites)),
                observed=", ".join(map(str, inv_sites)))

    # ---------------------------------------------------------- status
    if disposed and has_inv:
        add("STATUS_MISMATCH", "Actif cédé / sorti mais toujours présent physiquement")
    for asset in register:
        if asset.get("disposal_date") and nz.norm_text(asset.get("status") or "") in (
                "", "ACTIF", "ACTIVE", "EN SERVICE"):
            add("STATUS_MISMATCH", "Date de cession renseignée mais statut actif")

    # ---------------------------------------------------------- extraction quality
    for line in invoices:
        confidence = line.get("extraction_confidence")
        if confidence is not None and confidence < config["min_extraction_confidence"]:
            add("LOW_CONFIDENCE_EXTRACTION",
                "Facture %s page %s: confiance %.0f%%"
                % (line.get("invoice_number"), line.get("source_page") or "-",
                   confidence * 100))
            manual_reasons.append("extraction à faible confiance")
        missing = [field for field in ("invoice_number", "supplier", "invoice_date",
                                       "quantity", "line_total")
                   if line.get(field) in (None, "")]
        if missing:
            add("MISSING_CRITICAL_FIELD",
                "Facture %s: champs manquants: %s"
                % (line.get("invoice_number") or line.get("_id"), ", ".join(missing)))
            manual_reasons.append("champs critiques manquants")

    # ---------------------------------------------------------- match confidence
    scores = [link["score"] for link in cluster.get("links", [])]
    min_score = min(scores) if scores else None
    if min_score is not None and min_score < config["manual_review_score"]:
        add("AMBIGUOUS_MATCH",
            "Rapprochement automatique avec un score de %.0f%%" % (min_score * 100))
        manual_reasons.append("score de rapprochement %.0f%%" % (min_score * 100))

    if has_invoice and not has_reg and not has_inv:
        add("UNMATCHED_INVOICE_LINE", "Ligne de facture sans actif identifié")

    # ---------------------------------------------------------- status
    severities = set(entry["severity"] for entry in codes)
    missing_codes = {"NO_INVOICE", "INVOICE_NOT_IN_GL", "REGISTER_WITHOUT_GL"}
    blocking_high = set(entry["code"] for entry in codes
                        if entry["severity"] == "H") - missing_codes
    if not has_reg and not has_inv and has_invoice:
        status = "UNMATCHED_INVOICE"
    elif not has_inv and not has_reg and not has_invoice:
        status = "UNMATCHED_GL"
    elif blocking_high:
        status = "DISCREPANCY"
    elif "H" in severities:
        status = "MISSING_DOCUMENT"
    elif (has_inv or has_reg) and (not has_invoice or not has_gl):
        status = "MISSING_DOCUMENT"
    elif codes:
        status = "PARTIALLY_RECONCILED"
    else:
        status = "FULLY_RECONCILED"

    # An intangible asset has no physical existence to prove: the absence of a
    # count is not a partial reconciliation when invoice, register and GL agree.
    if status == "PARTIALLY_RECONCILED" and set(
            entry["code"] for entry in codes) == {"INTANGIBLE_NO_PHYSICAL"}:
        status = "FULLY_RECONCILED"

    review = bool(manual_reasons) or status in ("UNMATCHED_INVOICE", "UNMATCHED_GL")
    if status == "MISSING_DOCUMENT":
        review = True
    if any(entry["code"] == "AMBIGUOUS_MATCH" for entry in codes):
        review = True

    value = reg_cost if reg_cost else line_total
    fiscal_years = sorted(set(
        value.year for value in (invoice_dates + register_dates + gl_dates) if value))

    return {
        "cluster": cluster,
        "status": status,
        "codes": codes,
        "review": review,
        "review_reason": "; ".join(_unique(manual_reasons)),
        "asset_label": asset_label,
        "value": value,
        "score": min_score,
        "intangible": intangible,
        "disposed": disposed,
        "quantities": {"inventory": inv_qty, "register": reg_qty,
                       "invoice": line_qty},
        "amounts": {"register": reg_cost, "invoice": line_total,
                    "gl": (sum(entry.get("debit") or 0 for entry in gl) if gl else None)},
        "dates": {"invoice": invoice_date, "acquisition": acquisition_date,
                  "in_service": service_date, "gl": gl_date},
        "fiscal_years": fiscal_years,
        "sources": {
            "inventory": has_inv,
            "invoices": has_invoice,
            "register": has_reg,
            "gl": has_gl,
        },
        "counts": {
            "inventory": len(inventory),
            "invoices": len(invoices),
            "register": len(register),
            "gl": len(gl),
        },
    }
