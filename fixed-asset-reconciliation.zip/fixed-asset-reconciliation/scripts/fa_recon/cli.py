"""Command-line entry point for the fixed-asset reconciliation toolkit."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from datetime import date, datetime

from . import loaders, matching, report, rules
from .normalize import parse_date

VERSION = "1.0.0"
DEFAULT_CONFIG = {
    "auto_match_threshold": 0.88,
    "review_match_threshold": 0.72,
    "manual_review_score": 0.93,
    "amount_tolerance_abs": 1000.0,
    "amount_tolerance_pct": 0.005,
    "date_tolerance_days": 30,
    "min_extraction_confidence": 0.75,
    "currency": "FCFA",
    "period_start": None,
    "period_end": None,
}


def load_config(path=None, overrides=None):
    config = dict(DEFAULT_CONFIG)
    if path:
        with open(path, "r", encoding="utf-8") as handle:
            config.update(json.load(handle))
    for key, value in (overrides or {}).items():
        if value is not None:
            config[key] = value
    for key in ("period_start", "period_end"):
        if isinstance(config.get(key), str):
            parsed, _ambiguous, error = parse_date(config[key])
            if error:
                raise SystemExit("Date de période invalide (%s): %s" % (key, error))
            config[key] = parsed
    return config


def _require(value, message):
    if not value:
        raise SystemExit(message)
    return value


def cmd_templates(args):
    from .make_templates import write_templates
    paths = write_templates(args.output)
    print("Modèles créés:")
    for path in paths:
        print("  %s" % path)
    return 0


def cmd_manifest(args):
    from .invoice_tools import write_manifest
    path, summary = write_manifest(args.folder, args.output)
    print("Manifeste: %s" % path)
    print("Fichiers: %(files)d · PDF texte: %(text_pdf)d · scans: %(scans)d · "
          "images: %(images)d · doublons: %(duplicates)d" % summary)
    return 0


def cmd_check_invoices(args):
    data = loaders.load_source(args.invoices, "invoices", sheet=args.sheet)
    issues = list(data["issues"])
    seen = {}
    for line in data["records"]:
        key = (line.get("_supplier_n"), line.get("_invno_n"))
        if line.get("_invno_n"):
            seen.setdefault(key, []).append(line)
        quantity = line.get("quantity")
        unit = line.get("unit_price")
        total = line.get("line_total")
        if quantity and unit and total:
            expected = round(quantity * unit, 2)
            if abs(expected - total) > max(2.0, abs(expected) * 0.001):
                issues.append({
                    "code": "INVOICE_ARITHMETIC",
                    "message": "Facture %s ligne %s: %.2f × %.2f ≠ %.2f" % (
                        line.get("invoice_number"), line.get("line_no"),
                        quantity, unit, total),
                    "source": "invoices", "file": line.get("_file"),
                })
        if line.get("extraction_confidence") is not None \
                and line["extraction_confidence"] < 0.75:
            issues.append({
                "code": "LOW_CONFIDENCE",
                "message": "Facture %s: confiance %.0f%%" % (
                    line.get("invoice_number"), line["extraction_confidence"] * 100),
                "source": "invoices", "file": line.get("_file"),
            })
    for key, lines in seen.items():
        if len(lines) > 1:
            files = set(line.get("source_file") or line.get("_file") for line in lines)
            if len(files) > 1:
                issues.append({
                    "code": "DUPLICATE_INVOICE",
                    "message": "Facture %s présente dans %s" % (
                        lines[0].get("invoice_number"), ", ".join(sorted(files))),
                    "source": "invoices", "file": lines[0].get("_file"),
                })
    print("Lignes de facture: %d" % len(data["records"]))
    print("Anomalies: %d" % len(issues))
    for issue in issues[:200]:
        print("  [%s] %s" % (issue["code"], issue["message"]))
    if len(issues) > 200:
        print("  ... %d autres" % (len(issues) - 200))
    return 1 if any(issue["code"] in (
        "REQUIRED_COLUMN_MISSING", "REQUIRED_VALUE_MISSING", "INVOICE_ARITHMETIC",
        "DUPLICATE_INVOICE") for issue in issues) else 0


def cmd_run(args):
    config = load_config(args.config, {
        "period_start": args.period_start,
        "period_end": args.period_end,
        "currency": args.currency,
    })
    _require(config.get("period_start"), "Indiquer --period-start (AAAA-MM-JJ)")
    _require(config.get("period_end"), "Indiquer --period-end (AAAA-MM-JJ)")
    if config["period_start"] > config["period_end"]:
        raise SystemExit("La période est inversée")

    data = {
        "inventory": loaders.load_source(
            args.inventory, "inventory",
            sheet=args.inventory_sheet or args.sheet,
            all_sheets=args.all_sheets),
        "invoices": loaders.load_source(
            args.invoices, "invoices",
            sheet=args.invoices_sheet or args.sheet,
            all_sheets=args.all_sheets),
        "register": loaders.load_source(
            args.register, "register",
            sheet=args.register_sheet or args.sheet,
            all_sheets=args.all_sheets),
        "gl": loaders.load_source(
            args.gl, "gl",
            sheet=args.gl_sheet or args.sheet,
            all_sheets=args.all_sheets),
    }

    duplicates = matching.mark_duplicates(data)
    duplicates += matching.detect_duplicates(data)
    clusters, review_candidates = matching.build_clusters(data, config)
    headers = matching.invoice_headers(data["invoices"]["records"], config)
    results = rules.evaluate_all(clusters, data, config, headers)

    output = args.output
    if os.path.isdir(output) or not os.path.splitext(output)[1]:
        os.makedirs(output, exist_ok=True)
        filename = "rapprochement_immobilisations_%s.xlsx" % datetime.now().strftime(
            "%Y%m%d_%H%M")
        output = os.path.join(output, filename)
    elif not output.lower().endswith(".xlsx"):
        raise SystemExit("Le fichier de sortie doit être un .xlsx")

    context = {
        "client": args.client or "",
        "period_start": config["period_start"],
        "period_end": config["period_end"],
        "currency": config["currency"],
        "generated_at": datetime.now().strftime("%d/%m/%Y %H:%M"),
        "version": "fa-recon %s" % VERSION,
        "config": config,
        "data": data,
    }
    summary = report.write_workbook(output, context, results, duplicates, headers,
                                    review_candidates,
                                    export_csv=not args.no_csv)

    print("Rapprochement terminé")
    print("  Client       : %s" % (args.client or "(non renseigné)"))
    print("  Période      : %s → %s" % (config["period_start"], config["period_end"]))
    print("  Classeur     : %s" % summary["workbook"])
    print("  Groupes      : %(clusters)d" % summary["counts"])
    print("  Écarts       : %(discrepancies)d" % summary["counts"])
    print("  À vérifier   : %(manual_review)d" % summary["counts"])
    print("  Doublons     : %(duplicates)d" % summary["counts"])
    print("  Factures sans actif : %(unmatched_invoices)d" % summary["counts"])
    print("  Écritures sans actif: %(unmatched_gl)d" % summary["counts"])
    for source in ("inventory", "invoices", "register", "gl"):
        if data[source]["issues"]:
            print("  Qualité %-10s: %d anomalies d'import"
                  % (source, len(data[source]["issues"])))
    return 0


def cmd_demo(args):
    from .make_sample_data import write_sample_data
    data_dir = os.path.join(args.output, "donnees_demo")
    paths = write_sample_data(data_dir)
    print("Données de démonstration: %s" % data_dir)
    run_args = argparse.Namespace(
        inventory=paths["inventory"], invoices=paths["invoices"],
        register=paths["register"], gl=paths["gl"], output=args.output,
        client="DEMO SARL", period_start="2021-01-01", period_end="2025-12-31",
        currency="FCFA", config=None, sheet=None, inventory_sheet=None,
        invoices_sheet=None, register_sheet=None, gl_sheet=None,
        all_sheets=False, no_csv=False,
    )
    return cmd_run(run_args)


def build_parser():
    parser = argparse.ArgumentParser(
        prog="reconcile.py",
        description="Rapprochement d'immobilisations: inventaire, factures, "
                    "registre, grand livre.")
    subparsers = parser.add_subparsers(dest="command")

    templates = subparsers.add_parser(
        "templates", help="Créer les modèles Excel des quatre sources")
    templates.add_argument("-o", "--output", default="modeles")
    templates.set_defaults(func=cmd_templates)

    manifest = subparsers.add_parser(
        "manifest", help="Inventorier un dossier de factures scannées")
    manifest.add_argument("folder")
    manifest.add_argument("-o", "--output", default="manifeste_factures.csv")
    manifest.set_defaults(func=cmd_manifest)

    check = subparsers.add_parser(
        "check-invoices", help="Valider le fichier de factures extraites")
    check.add_argument("invoices")
    check.add_argument("--sheet")
    check.set_defaults(func=cmd_check_invoices)

    run = subparsers.add_parser("run", help="Exécuter le rapprochement complet")
    run.add_argument("--inventory", required=True)
    run.add_argument("--invoices", required=True)
    run.add_argument("--register", required=True)
    run.add_argument("--gl", required=True)
    run.add_argument("--output", default="sortie")
    run.add_argument("--client")
    run.add_argument("--period-start", required=True)
    run.add_argument("--period-end", required=True)
    run.add_argument("--currency", default="FCFA")
    run.add_argument("--config")
    run.add_argument("--sheet", help="Nom de feuille commun aux quatre fichiers")
    run.add_argument("--inventory-sheet")
    run.add_argument("--invoices-sheet")
    run.add_argument("--register-sheet")
    run.add_argument("--gl-sheet")
    run.add_argument("--all-sheets", action="store_true",
                     help="Concaténer toutes les feuilles reconnues")
    run.add_argument("--no-csv", action="store_true")
    run.set_defaults(func=cmd_run)

    demo = subparsers.add_parser(
        "demo", help="Générer un jeu de données et exécuter le rapprochement")
    demo.add_argument("-o", "--output", default="demo")
    demo.set_defaults(func=cmd_demo)
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 2
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
