"""Cross-source matching: exact keys first, then explainable fuzzy scoring.

Design rules
------------
* An automatic link must be explainable: score, method and the components
  that produced it are stored and printed in the workbook.
* Missing data lowers confidence instead of being silently ignored.
* Quantity is compared at group level, so one invoice line for 10 chairs can
  reconcile against 10 physical rows of 1 chair each.
* General-ledger entries are attached as evidence and do not merge clusters,
  because one GL posting often covers a whole invoice.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date

from . import normalize as nz

PROFILES = {
    ("inventory", "register"): {"desc": 0.55, "brand": 0.25, "qty": 0.20},
    ("inventory", "invoices"): {"desc": 0.45, "brand": 0.20, "qty": 0.25,
                                "date": 0.10},
    ("register", "invoices"): {"desc": 0.35, "brand": 0.15, "qty": 0.15,
                               "amount": 0.25, "date": 0.10},
    ("gl", "register"): {"desc": 0.45, "amount": 0.40, "date": 0.15},
    ("gl", "invoices"): {"desc": 0.25, "amount": 0.35, "date": 0.25,
                         "supplier": 0.15},
}

COMPONENT_LABELS = {
    "desc": "description",
    "brand": "marque",
    "qty": "quantité",
    "amount": "montant",
    "date": "date",
    "supplier": "fournisseur",
}


class Candidate(object):
    __slots__ = ("left", "right", "score", "method", "reasons", "components")

    def __init__(self, left, right, score, method, reasons, components=None):
        self.left = left
        self.right = right
        self.score = round(score, 4)
        self.method = method
        self.reasons = reasons
        self.components = components or {}

    def as_dict(self):
        return {
            "left_id": self.left["_id"],
            "left_source": self.left["_source"],
            "right_id": self.right["_id"],
            "right_source": self.right["_source"],
            "score": self.score,
            "method": self.method,
            "reasons": "; ".join(self.reasons),
            "components": self.components,
        }


def _amount_component(a, b):
    """Register cost vs invoice line total, VAT-aware (18% UEMOA default)."""
    if a is None or b is None:
        return None, "montant absent"
    if nz.money_equal(a, b, tol_abs=1000, tol_pct=0.01):
        return 1.0, "montants identiques"
    for factor, label in ((1.18, "TVA 18%"), (1.0 / 1.18, "TVA 18% (net)"),
                          (1.20, "TVA 20%"), (1.0 / 1.20, "TVA 20% (net)")):
        if nz.money_equal(a, b * factor, tol_abs=1000, tol_pct=0.01):
            return 0.80, "montants cohérents (%s)" % label
    diff = abs(a - b) / max(abs(a), abs(b), 1)
    if diff <= 0.05:
        return 0.55, "écart de montant %.1f%%" % (diff * 100)
    if diff <= 0.15:
        return 0.25, "écart de montant %.1f%%" % (diff * 100)
    return 0.0, "montants différents (%.0f vs %.0f)" % (a, b)


def _date_component(a, b):
    if a is None or b is None:
        return None, "date absente"
    days = abs((a - b).days)
    if days <= 30:
        return 1.0, "dates à %d jours" % days
    if days <= 90:
        return 0.75, "dates à %d jours" % days
    if days <= 180:
        return 0.45, "dates à %d jours" % days
    if days <= 365:
        return 0.20, "dates à %d jours" % days
    return 0.0, "dates éloignées (%d jours)" % days


def _qty_component(a, b, groupable=False):
    if a is None or b is None:
        return None, "quantité absente"
    if a == b:
        return 1.0, "quantités identiques"
    if groupable and (a == 1 or b == 1):
        return 0.90, "regroupement de lignes possible"
    return 0.0, "quantités différentes (%.0f vs %.0f)" % (a, b)


def _brand_component(a, b):
    if not a or not b:
        return None, "marque absente"
    if a == b:
        return 1.0, "marque identique"
    if a in b or b in a:
        return 0.80, "marque proche"
    return 0.0, "marques différentes (%s vs %s)" % (a, b)


def _supplier_component(a, b):
    if not a or not b:
        return None, "fournisseur absent"
    similarity = nz.text_similarity(a, b)
    if similarity >= 0.85:
        return 1.0, "fournisseur identique"
    if similarity >= 0.60:
        return 0.60, "fournisseur proche"
    return 0.0, "fournisseurs différents"


def score_pair(left, right, profile_name):
    weights = PROFILES[profile_name]
    components = {}
    reasons = []
    present_weight = 0.0
    total_weight = sum(weights.values())
    weighted = 0.0

    if "desc" in weights:
        score = nz.similarity(left.get("_desc_tokens"), right.get("_desc_tokens"))
        components["desc"] = round(score, 3)
        if score >= 0.45:
            reasons.append("description %.0f%%" % (score * 100))
        weighted += weights["desc"] * score
        present_weight += weights["desc"]

    if "brand" in weights:
        score, reason = _brand_component(left.get("_brand_n"), right.get("_brand_n"))
        if score is not None:
            components["brand"] = score
            weighted += weights["brand"] * score
            present_weight += weights["brand"]
            if score < 1:
                reasons.append(reason)

    if "qty" in weights:
        groupable = profile_name in (("inventory", "invoices"),
                                     ("inventory", "register"),
                                     ("register", "invoices"))
        score, reason = _qty_component(left.get("quantity"), right.get("quantity"),
                                       groupable=groupable)
        if score is not None:
            components["qty"] = score
            weighted += weights["qty"] * score
            present_weight += weights["qty"]
            if score < 1:
                reasons.append(reason)

    if "amount" in weights:
        score, reason = _amount_component(left.get("cost", left.get("line_total")),
                                          right.get("line_total", right.get("cost")))
        if score is not None:
            components["amount"] = score
            weighted += weights["amount"] * score
            present_weight += weights["amount"]
            if score < 1:
                reasons.append(reason)

    if "date" in weights:
        left_date = left.get("_date")
        right_date = right.get("_date")
        score, reason = _date_component(left_date, right_date)
        if score is not None:
            components["date"] = score
            weighted += weights["date"] * score
            present_weight += weights["date"]
            if score < 1:
                reasons.append(reason)

    if "supplier" in weights:
        score, reason = _supplier_component(left.get("_supplier_n"),
                                            right.get("_supplier_n"))
        if score is not None:
            components["supplier"] = score
            weighted += weights["supplier"] * score
            present_weight += weights["supplier"]
            if score < 1:
                reasons.append(reason)

    if present_weight <= 0:
        return 0.0, {}, ["aucune donnée comparable"]

    score = weighted / present_weight
    coverage = present_weight / total_weight
    score *= 0.85 + 0.15 * coverage
    if len(components) < 2:
        score = min(score, 0.60)
        reasons.append("preuve insuffisante")
    if components.get("desc", 1.0) < 0.45:
        score = min(score, 0.55)
    return score, components, reasons


def _block_keys(record):
    keys = []
    if record.get("_brand_n"):
        keys.append("B:" + record["_brand_n"])
    tokens = record.get("_desc_tokens") or []
    if tokens:
        keys.append("T:" + tokens[0])
        if len(tokens) > 1:
            keys.append("T2:" + tokens[1])
    if record.get("_supplier_n"):
        keys.append("F:" + record["_supplier_n"].split(" ")[0])
    if record.get("_code_n"):
        keys.append("C:" + record["_code_n"])
    if record.get("_site_n"):
        keys.append("S:" + record["_site_n"])
    amount = record.get("cost", record.get("line_total"))
    if amount:
        keys.append("A:%d" % int(round(amount / 1000.0)))
    if record.get("_date"):
        keys.append("Y:%d" % record["_date"].year)
    return keys


def _candidates(left, rights, right_index):
    found = set()
    for key in _block_keys(left):
        found.update(right_index.get(key, ()))
    if not found and len(rights) <= 1500:
        found = set(range(len(rights)))
    return found


def match_pairs(lefts, rights, profile_name, auto_threshold, review_threshold,
                max_candidates=800):
    """Score all plausible pairs. Returns (accepted, review)."""
    right_index = defaultdict(list)
    for index, record in enumerate(rights):
        for key in _block_keys(record):
            right_index[key].append(index)

    scored = []
    for left in lefts:
        indices = _candidates(left, rights, right_index)
        if len(indices) > max_candidates:
            # Keep the most promising block: same brand, then same token.
            narrowed = set()
            for key in _block_keys(left):
                if key.startswith(("B:", "C:")):
                    narrowed.update(right_index.get(key, ()))
            indices = narrowed or set(list(indices)[:max_candidates])
        for index in indices:
            right = rights[index]
            if left is right:
                continue
            score, components, reasons = score_pair(left, right, profile_name)
            if score >= review_threshold:
                scored.append(Candidate(left, right, score, "FLOU", reasons,
                                        components))

    scored.sort(key=lambda candidate: candidate.score, reverse=True)
    accepted = [candidate for candidate in scored if candidate.score >= auto_threshold]
    review = [candidate for candidate in scored
              if review_threshold <= candidate.score < auto_threshold]
    return accepted, review


# ------------------------------------------------------------------ exact keys

def _link_by_invoice_number(invoice_lines, register_records):
    """Pair invoice lines with register rows sharing an invoice number.

    When an invoice bundles several assets, pairing inside the invoice by
    description prevents every line from merging into every register row.
    """
    register_by_invoice = defaultdict(list)
    for record in register_records:
        if record.get("_invno_n"):
            register_by_invoice[record["_invno_n"]].append(record)
    lines_by_invoice = defaultdict(list)
    for record in invoice_lines:
        if record.get("_invno_n"):
            lines_by_invoice[record["_invno_n"]].append(record)

    links = []
    for invoice_number, lines in lines_by_invoice.items():
        rows = register_by_invoice.get(invoice_number, [])
        if not rows:
            continue
        if len(rows) == 1:
            for line in lines:
                links.append(Candidate(line, rows[0], 1.0, "N° facture",
                                       ["même numéro de facture"]))
            continue
        if len(lines) == 1:
            for row in rows:
                links.append(Candidate(lines[0], row, 1.0, "N° facture",
                                       ["même numéro de facture"]))
            continue
        # Greedy best-description pairing, one register row at a time.
        pairs = []
        for line in lines:
            for row in rows:
                similarity = nz.similarity(line.get("_desc_tokens"),
                                           row.get("_desc_tokens"))
                pairs.append((similarity, line, row))
        pairs.sort(key=lambda item: item[0], reverse=True)
        used_lines, used_rows = set(), set()
        for similarity, line, row in pairs:
            if line["_id"] in used_lines or row["_id"] in used_rows:
                continue
            if similarity < 0.25:
                continue
            links.append(Candidate(line, row, max(0.96, similarity), "N° facture",
                                   ["même numéro de facture",
                                    "description %.0f%%" % (similarity * 100)]))
            used_lines.add(line["_id"])
            used_rows.add(row["_id"])
        for line in lines:
            if line["_id"] not in used_lines:
                # Do not force a link: an unpaired line is itself a finding.
                continue
    return links


def _link_by_key(lefts, rights, left_field, right_field, method):
    index = defaultdict(list)
    for record in rights:
        key = record.get(right_field)
        if key:
            index[key].append(record)
    links = []
    for record in lefts:
        key = record.get(left_field)
        if key and key in index:
            for other in index[key]:
                links.append(Candidate(record, other, 1.0, method,
                                       ["clé identique: %s" % key]))
    return links


def _link_serial(lefts, rights):
    index = defaultdict(list)
    for record in rights:
        if record.get("_serial_n") and len(record["_serial_n"]) >= 4:
            index[record["_serial_n"]].append(record)
    links = []
    for record in lefts:
        serial = record.get("_serial_n")
        if serial and len(serial) >= 4 and serial in index:
            for other in index[serial]:
                links.append(Candidate(record, other, 1.0, "N° de série",
                                       ["numéro de série identique"]))
    return links


# ------------------------------------------------------------------ clustering

class _UnionFind(object):
    def __init__(self):
        self.parent = {}

    def add(self, key):
        self.parent.setdefault(key, key)

    def find(self, key):
        root = key
        while self.parent[root] != root:
            root = self.parent[root]
        while self.parent[key] != root:
            self.parent[key], key = root, self.parent[key]
        return root

    def union(self, a, b):
        self.add(a)
        self.add(b)
        root_a, root_b = self.find(a), self.find(b)
        if root_a != root_b:
            self.parent[root_b] = root_a

    def groups(self):
        groups = defaultdict(list)
        for key in self.parent:
            groups[self.find(key)].append(key)
        return list(groups.values())


def _key(record):
    return (record["_source"], record["_id"])


def mark_duplicates(data):
    """Flag invoice lines that repeat an invoice already seen in another file.

    Duplicates are excluded from matching so that a double scan does not create
    a phantom asset, and are reported in the duplicates sheet instead.
    """
    duplicates = []
    seen = {}
    for line in data["invoices"]["records"]:
        if not line.get("_invno_n"):
            continue
        key = (line.get("_supplier_n"), line["_invno_n"])
        first = seen.get(key)
        if first is None:
            seen[key] = line
            continue
        first_file = first.get("source_file") or first.get("_file")
        line_file = line.get("source_file") or line.get("_file")
        if first_file == line_file:
            continue
        line["_duplicate"] = True
        duplicates.append({
            "code": "DUPLICATE_INVOICE",
            "severity": "H",
            "source": "invoices",
            "records": [first, line],
            "detail": "Facture %s du fournisseur %s présente dans %s et %s"
                      % (line.get("invoice_number"), line.get("supplier"),
                         first.get("source_file") or first.get("_file"),
                         line.get("source_file") or line.get("_file")),
        })
    return duplicates


def build_clusters(data, config):
    inventory = data["inventory"]["records"]
    invoices = [line for line in data["invoices"]["records"]
                if not line.get("_duplicate")]
    register = data["register"]["records"]
    gl = data["gl"]["records"]

    auto = config["auto_match_threshold"]
    review = config["review_match_threshold"]

    review_candidates = []
    used = defaultdict(set)      # source -> record ids already committed
    budget = defaultdict(float)  # invoice line -> quantity already explained
    chosen = []

    def take(candidates, unique_sources=(), invoice_budget=False):
        """Greedy assignment with one-to-many support through a qty budget."""
        for candidate in sorted(candidates, key=lambda c: c.score, reverse=True):
            records = (candidate.left, candidate.right)
            blocked = any(record["_source"] in unique_sources
                          and record["_id"] in used[record["_source"]]
                          for record in records)
            line = None
            if invoice_budget:
                line = next((record for record in records
                             if record["_source"] == "invoices"), None)
                if line is not None:
                    capacity = line.get("quantity") or 1.0
                    if budget[line["_id"]] >= capacity - 0.001:
                        blocked = True
            if blocked:
                continue
            for record in records:
                if record["_source"] in unique_sources:
                    used[record["_source"]].add(record["_id"])
            if line is not None:
                other = candidate.right if line is candidate.left else candidate.left
                budget[line["_id"]] += other.get("quantity") or 1.0
            chosen.append(candidate)

    # 1. Exact invoice number -> register, then exact asset codes.
    key_links = _link_by_invoice_number(invoices, register)
    take(key_links, unique_sources=("register",), invoice_budget=True)
    take(_link_by_key(inventory, register, "_code_n", "_code_n", "Code immo"),
         unique_sources=("inventory",))
    take(_link_by_key(inventory, invoices, "_code_n", "_code_n", "Code immo"),
         unique_sources=("inventory",), invoice_budget=True)
    take(_link_serial(inventory, register), unique_sources=("inventory",))

    # 2. Fuzzy physical <-> register (register may hold several counted items).
    accepted, candidates = match_pairs(
        inventory, register, ("inventory", "register"), auto, review)
    take(accepted, unique_sources=("inventory",))
    review_candidates += candidates

    # 3. Fuzzy register <-> invoice, then physical <-> invoice for assets that
    #    have no register row at all (register completeness gap).
    accepted, candidates = match_pairs(
        register, invoices, ("register", "invoices"), auto, review)
    take(accepted, unique_sources=("register",), invoice_budget=True)
    review_candidates += candidates

    unlinked_inventory = [record for record in inventory
                          if record["_id"] not in used["inventory"]]
    accepted, candidates = match_pairs(
        unlinked_inventory, invoices, ("inventory", "invoices"), auto, review)
    take(accepted, unique_sources=("inventory",), invoice_budget=True)
    review_candidates += candidates

    union = _UnionFind()
    for record in inventory + register + invoices:
        union.add(_key(record))
    for candidate in chosen:
        union.union(_key(candidate.left), _key(candidate.right))

    record_index = {}
    for record in inventory + register + invoices + gl:
        record_index[_key(record)] = record

    clusters = []
    for group in union.groups():
        members = defaultdict(list)
        for key in group:
            record = record_index[key]
            members[record["_source"]].append(record)
        clusters.append({
            "id": None,
            "records": {source: members.get(source, [])
                        for source in ("inventory", "invoices", "register")},
            "gl": [],
            "links": [],
        })

    # Keep the link that produced each cluster, for the evidence column.
    cluster_by_key = {}
    for cluster in clusters:
        for source, records in cluster["records"].items():
            for record in records:
                cluster_by_key[_key(record)] = cluster
    for candidate in chosen:
        cluster = cluster_by_key.get(_key(candidate.left))
        if cluster is not None:
            cluster["links"].append(candidate.as_dict())

    # Attach GL entries: invoice-number key first, then asset code, then fuzzy.
    _attach_gl(clusters, gl, config, review_candidates)
    clusters.sort(key=lambda cluster: _cluster_sort_key(cluster))
    for index, cluster in enumerate(clusters, start=1):
        cluster["id"] = "R%04d" % index
    return clusters, review_candidates


def _cluster_sort_key(cluster):
    for source in ("register", "inventory", "invoices"):
        records = cluster["records"].get(source) or []
        if records:
            return (records[0].get("_desc_n") or "", cluster["id"] or "")
    return ("", "")


def _attach_gl(clusters, gl_records, config, review_candidates):
    invoice_to_clusters = defaultdict(list)
    code_to_clusters = defaultdict(list)
    for cluster in clusters:
        for line in cluster["records"]["invoices"]:
            if line.get("_invno_n"):
                invoice_to_clusters[line["_invno_n"]].append(cluster)
        for source in ("register", "inventory"):
            for record in cluster["records"][source]:
                if record.get("_code_n"):
                    code_to_clusters[record["_code_n"]].append(cluster)

    attached = set()
    for entry in gl_records:
        targets = []
        for key in (entry.get("_invno_n"), entry.get("_docref_n")):
            if key and key in invoice_to_clusters:
                targets = invoice_to_clusters[key]
                break
        if not targets and entry.get("_code_n") in code_to_clusters:
            targets = code_to_clusters[entry["_code_n"]]
        if targets:
            seen = set()
            for cluster in targets:
                if id(cluster) in seen:
                    continue
                seen.add(id(cluster))
                cluster["gl"].append(entry)
            attached.add(entry["_id"])

    # Fuzzy GL attachment for entries without a usable reference.
    unmatched = [entry for entry in gl_records if entry["_id"] not in attached]
    for entry in unmatched:
        best = None
        for cluster in clusters:
            candidates = []
            candidates += cluster["records"]["register"]
            candidates += cluster["records"]["invoices"]
            for record in candidates:
                score, components, reasons = score_pair(
                    entry, record, ("gl", "invoices")
                    if record["_source"] == "invoices" else ("gl", "register"))
                if best is None or score > best[0]:
                    best = (score, cluster, record, reasons)
        if best and best[0] >= config["auto_match_threshold"]:
            best[1]["gl"].append(entry)
            attached.add(entry["_id"])
        elif best and best[0] >= config["review_match_threshold"]:
            review_candidates.append(Candidate(
                entry, best[2], best[0], "FLOU (GL)", best[3]))
    return attached


def unmatched_records(clusters, data):
    """Records that no cluster holds (GL handled separately)."""
    present = set()
    for cluster in clusters:
        for records in cluster["records"].values():
            for record in records:
                present.add(_key(record))
        for entry in cluster["gl"]:
            present.add(_key(entry))
    result = {}
    for source in ("inventory", "invoices", "register", "gl"):
        result[source] = [record for record in data[source]["records"]
                          if _key(record) not in present
                          and not record.get("_duplicate")]
    return result


def invoice_headers(invoice_lines, config):
    groups = defaultdict(list)
    for line in invoice_lines:
        if line.get("_duplicate"):
            continue
        key = (line.get("_supplier_n"), line.get("_invno_n"))
        if not line.get("_invno_n"):
            key = ("SANS-NUMERO", line["_id"])
        groups[key].append(line)
    headers = []
    for key, lines in groups.items():
        totals = [line.get("line_total") for line in lines
                  if line.get("line_total") is not None]
        stated = [line.get("invoice_total") for line in lines
                  if line.get("invoice_total") is not None]
        total_lines = round(sum(totals), 2) if totals else None
        total_stated = stated[0] if stated else None
        headers.append({
            "key": key,
            "supplier": lines[0].get("supplier"),
            "invoice_number": lines[0].get("invoice_number"),
            "invoice_date": min([line["invoice_date"] for line in lines
                                 if line.get("invoice_date")], default=None),
            "lines": lines,
            "total_lines": total_lines,
            "total_stated": total_stated,
            "total": total_stated if total_stated is not None else total_lines,
            "total_mismatch": (
                total_stated is not None and total_lines is not None
                and not nz.money_equal(total_stated, total_lines, 1000, 0.01)
            ),
            "files": sorted(set(line.get("source_file") or line.get("_file")
                                for line in lines)),
        })
    headers.sort(key=lambda header: (header["invoice_date"] or date.min,
                                     header["invoice_number"] or ""))
    return headers


# ------------------------------------------------------------------ duplicates

def detect_duplicates(data, clusters=None):
    duplicates = []
    seen = {}

    seen_codes = {}
    for asset in data["register"]["records"]:
        code = asset.get("_code_n")
        if not code:
            continue
        if code in seen_codes:
            duplicates.append({
                "code": "DUPLICATE_REGISTER_ASSET",
                "severity": "H",
                "source": "register",
                "records": [seen_codes[code], asset],
                "detail": "Code %s présent plusieurs fois dans le registre"
                          % asset.get("asset_code"),
            })
        else:
            seen_codes[code] = asset

    seen_serials = {}
    for source in ("inventory", "register"):
        for record in data[source]["records"]:
            serial = record.get("_serial_n")
            if not serial or len(serial) < 4:
                continue
            key = serial
            if key in seen_serials:
                other = seen_serials[key]
                # The same serial in inventory and register is the expected
                # match; only two rows inside one source are a duplicate.
                if other["_source"] == source:
                    duplicates.append({
                        "code": "DUPLICATE_SERIAL",
                        "severity": "M",
                        "source": source,
                        "records": [other, record],
                        "detail": "N° de série %s présent dans %s et %s"
                                  % (record.get("serial_number"),
                                     other["_source"], source),
                    })
            else:
                seen_serials[key] = record

    seen_entries = {}
    for entry in data["gl"]["records"]:
        key = entry.get("_entryid_n")
        if not key:
            continue
        if key in seen_entries:
            duplicates.append({
                "code": "DUPLICATE_GL",
                "severity": "M",
                "source": "gl",
                "records": [seen_entries[key], entry],
                "detail": "Écriture %s présente plusieurs fois" % entry.get("entry_id"),
            })
        else:
            seen_entries[key] = entry

    # Near-duplicate invoice lines: same supplier, amount, close date, similar
    # description, different invoice numbers.
    lines = data["invoices"]["records"]
    for i, left in enumerate(lines):
        for right in lines[i + 1:]:
            if left.get("_duplicate") or right.get("_duplicate"):
                continue
            if left.get("_invno_n") == right.get("_invno_n"):
                continue
            if left.get("_supplier_n") != right.get("_supplier_n"):
                continue
            if left.get("line_total") is None or right.get("line_total") is None:
                continue
            if not nz.money_equal(left["line_total"], right["line_total"], 100, 0.001):
                continue
            if left.get("_date") and right.get("_date"):
                if abs((left["_date"] - right["_date"]).days) > 3:
                    continue
            if nz.similarity(left.get("_desc_tokens"),
                             right.get("_desc_tokens")) < 0.90:
                continue
            duplicates.append({
                "code": "POSSIBLE_DUPLICATE_INVOICE",
                "severity": "M",
                "source": "invoices",
                "records": [left, right],
                "detail": "Lignes similaires: %s (%s) et %s (%s)"
                          % (left.get("invoice_number"), left.get("_file"),
                             right.get("invoice_number"), right.get("_file")),
            })

    return duplicates
