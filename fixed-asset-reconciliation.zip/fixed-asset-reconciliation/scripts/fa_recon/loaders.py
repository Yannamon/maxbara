"""Read client workbooks/CSV and map them onto the canonical schema.

Nothing is written back to client files. Each record keeps its file, sheet
and row so every figure in the report can be traced to the source.
"""
from __future__ import annotations

import csv
import hashlib
import os
from datetime import date

from openpyxl import load_workbook

from . import normalize as nz
from .schema import SPECS

MAX_HEADER_SCAN = 25
_HEADER_STOPWORDS = {"DE", "DU", "D", "DES", "L", "LA", "LE", "LES", "A", "AU",
                     "AUX", "ET", "EN", "THE", "OF"}


def _header_key(value):
    """Header comparison ignores accents, punctuation and small connectors."""
    return " ".join(token for token in nz.norm_text(value).split()
                    if token not in _HEADER_STOPWORDS)


def file_sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_csv(path):
    with open(path, "rb") as handle:
        raw = handle.read()
    for encoding in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            text = raw.decode(encoding)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise ValueError("Encodage du fichier CSV non reconnu: %s" % path)
    try:
        dialect = csv.Sniffer().sniff(text[:8192], delimiters=";,\t|")
        delimiter = dialect.delimiter
    except csv.Error:
        delimiter = ";" if text.count(";") > text.count(",") else ","
    rows = list(csv.reader(text.splitlines(), delimiter=delimiter))
    return [("CSV", rows)]


def _read_xlsx(path):
    workbook = load_workbook(path, read_only=True, data_only=True)
    sheets = []
    try:
        for worksheet in workbook.worksheets:
            rows = []
            for row in worksheet.iter_rows(values_only=True):
                rows.append(list(row))
            if any(any(cell not in (None, "") for cell in row) for row in rows):
                sheets.append((worksheet.title, rows))
    finally:
        workbook.close()
    return sheets


def read_tables(path):
    extension = os.path.splitext(path)[1].lower()
    if extension in (".csv", ".tsv", ".txt"):
        return _read_csv(path)
    if extension in (".xlsx", ".xlsm"):
        return _read_xlsx(path)
    if extension == ".xls":
        raise ValueError("Format .xls non supporté: convertir en .xlsx (%s)" % path)
    raise ValueError("Format de fichier non supporté: %s" % path)


def _header_score(cells, source):
    """How many canonical fields a candidate header row matches."""
    spec = SPECS[source]["fields"]
    normalized = [_header_key(cell) for cell in cells]
    hits = {}
    for field, (_label, aliases, _required, _kind) in spec.items():
        for alias in (_header_key(item) for item in aliases):
            exact = alias in normalized
            partial = any(
                header and len(alias) >= 4
                and (alias in header or (len(header) >= 4 and header in alias))
                for header in normalized)
            if exact or partial:
                hits[field] = 1
                break
    return len(hits), hits


def _map_header(cells, source):
    """Map canonical field -> column index using exact then partial matches."""
    spec = SPECS[source]["fields"]
    normalized = [_header_key(cell) for cell in cells]
    mapping, used = {}, set()
    # Pass 1: exact alias matches (longest alias first to disambiguate).
    candidates = []
    for field, (_label, aliases, _required, _kind) in spec.items():
        for alias in (_header_key(item) for item in aliases):
            if alias in normalized:
                candidates.append((len(alias), field, normalized.index(alias)))
    for _length, field, index in sorted(candidates, reverse=True):
        if field not in mapping and index not in used:
            mapping[field] = index
            used.add(index)
    # Pass 2: partial matches on remaining fields/columns. A header such as
    # "Code actif / N° inventaire" must still map to asset_code.
    for field, (_label, aliases, _required, _kind) in spec.items():
        if field in mapping:
            continue
        aliases = [_header_key(item) for item in aliases]
        best = None
        for index, header in enumerate(normalized):
            if not header or index in used:
                continue
            for alias in aliases:
                if len(alias) < 4:
                    continue
                if alias in header or (len(header) >= 4 and header in alias):
                    score = len(alias) + (2 if alias in header else 0)
                    if best is None or score > best[0]:
                        best = (score, index)
        if best is not None:
            mapping[field] = best[1]
            used.add(best[1])
    return mapping


def _best_header_row(rows, source):
    best = (0, None, None)
    limit = min(len(rows), MAX_HEADER_SCAN)
    for index in range(limit):
        score, hits = _header_score(rows[index], source)
        if score > best[0]:
            best = (score, index, hits)
    if best[0] < 2:
        return None, None
    return best[1], best[2]


def _coerce(value, kind, source, field):
    issues = []
    if kind == "date":
        parsed, ambiguous, error = nz.parse_date(value)
        if error:
            issues.append(("DATE_INVALID", "%s: %s (%r)" % (field, error, value)))
        return parsed, issues
    if kind == "money":
        parsed, ambiguous, error = nz.parse_money(value)
        if error:
            issues.append(("AMOUNT_INVALID", "%s: %s (%r)" % (field, error, value)))
        if ambiguous:
            issues.append(("AMOUNT_AMBIGUOUS",
                           "%s: séparateur décimal ambigu (%r)" % (field, value)))
        return parsed, issues
    if kind == "qty":
        parsed, error = nz.parse_qty(value)
        if error:
            issues.append(("QTY_INVALID", "%s: %s (%r)" % (field, error, value)))
        return parsed, issues
    if value is None:
        return "", issues
    if isinstance(value, (date,)):
        return value.isoformat(), issues
    return str(value).strip(), issues


def load_source(path, source, sheet=None, all_sheets=False):
    spec = SPECS[source]
    issues = []
    records = []
    columns_used = {}
    sheets_used = []
    header_rows = []

    tables = read_tables(path)
    selected = []
    if sheet:
        selected = [(name, rows) for name, rows in tables
                    if nz.norm_text(name) == nz.norm_text(sheet)]
        if not selected:
            raise ValueError("Feuille '%s' introuvable dans %s" % (sheet, path))
    elif all_sheets:
        for name, rows in tables:
            header_row, hits = _best_header_row(rows, source)
            if header_row is not None:
                selected.append((name, rows))
    else:
        best = None
        for name, rows in tables:
            header_row, hits = _best_header_row(rows, source)
            if header_row is None:
                continue
            score = len(hits or {})
            if best is None or score > best[0]:
                best = (score, name, rows)
        if best is None:
            raise ValueError(
                "Aucune ligne d'en-tête reconnue pour '%s' dans %s. "
                "Créer un fichier au format des modèles (voir make_templates)."
                % (source, os.path.basename(path)))
        selected = [(best[1], best[2])]

    for sheet_name, rows in selected:
        header_row, _hits = _best_header_row(rows, source)
        if header_row is None:
            issues.append(("SHEET_SKIPPED",
                           "Feuille '%s': en-tête non reconnu" % sheet_name))
            continue
        header = rows[header_row]
        mapping = _map_header(header, source)
        missing_required = [field for field in spec["required"] if field not in mapping]
        if missing_required:
            issues.append((
                "REQUIRED_COLUMN_MISSING",
                "Feuille '%s': colonnes obligatoires absentes: %s"
                % (sheet_name, ", ".join(spec["fields"][f][0] for f in missing_required)),
            ))
        unmapped = [str(cell) for index, cell in enumerate(header)
                    if cell not in (None, "") and index not in mapping.values()]
        if unmapped:
            issues.append(("COLUMNS_IGNORED",
                           "Feuille '%s': colonnes non utilisées: %s"
                           % (sheet_name, ", ".join(unmapped[:12]))))
        columns_used.update({field: str(header[index])
                             for field, index in mapping.items()})
        sheets_used.append(sheet_name)
        header_rows.append(header_row + 1)

        for offset, row in enumerate(rows[header_row + 1:], start=header_row + 2):
            if not any(cell not in (None, "") for cell in row):
                continue
            record = {
                "_source": source,
                "_file": os.path.basename(path),
                "_path": os.path.abspath(path),
                "_sheet": sheet_name,
                "_row": offset,
            }
            for field, index in mapping.items():
                kind = spec["fields"][field][3]
                value = row[index] if index < len(row) else None
                parsed, field_issues = _coerce(value, kind, source, field)
                record[field] = parsed
                for code, message in field_issues:
                    issues.append((code, "Ligne %d: %s" % (offset, message)))
            for field, (_label, _aliases, required, kind) in spec["fields"].items():
                if field not in record:
                    record[field] = None if kind in ("date", "money", "qty") else ""
                if required and record[field] in (None, ""):
                    issues.append((
                        "REQUIRED_VALUE_MISSING",
                        "Ligne %d: %s vide" % (offset, spec["fields"][field][0]),
                    ))
            # Quantities default to 1 only where that is the physical meaning
            # of a row, and the default is recorded as a data-quality issue.
            if source in ("inventory", "register") and record.get("quantity") is None:
                record["quantity"] = 1.0
                record["_qty_defaulted"] = True
                issues.append(("QTY_DEFAULTED",
                               "Ligne %d: quantité absente, 1 par défaut" % offset))
            if source == "invoices":
                if not record.get("source_file"):
                    record["source_file"] = os.path.basename(path)
                if record.get("extraction_confidence") in (None, ""):
                    record["extraction_confidence"] = None
                else:
                    try:
                        confidence = float(str(record["extraction_confidence"])
                                           .replace(",", "."))
                        record["extraction_confidence"] = confidence
                    except ValueError:
                        issues.append(("CONFIDENCE_INVALID",
                                       "Ligne %d: confiance non numérique (%r)"
                                       % (offset, record["extraction_confidence"])))
                        record["extraction_confidence"] = None
            _derive_keys(record, source)
            records.append(record)

    for index, record in enumerate(records, start=1):
        record["_id"] = "%s-%04d" % (source.upper()[:3], index)

    return {
        "source": source,
        "path": os.path.abspath(path),
        "file": os.path.basename(path),
        "hash": file_sha256(path),
        "sheets": sheets_used,
        "header_rows": header_rows,
        "columns": columns_used,
        "unmapped": [],
        "records": records,
        "issues": [{"code": code, "message": message, "file": os.path.basename(path),
                    "source": source} for code, message in issues],
    }


def _derive_keys(record, source):
    record["_desc_n"] = nz.norm_text(record.get("description"))
    record["_desc_tokens"] = nz.desc_tokens(record.get("description"))
    record["_brand_n"] = nz.brand_key(record.get("brand"))
    record["_supplier_n"] = nz.norm_text(record.get("supplier"))
    record["_invno_n"] = nz.norm_key(record.get("invoice_number"))
    record["_code_n"] = nz.norm_key(record.get("asset_code"))
    record["_site_n"] = nz.norm_text(record.get("site"))
    record["_serial_n"] = nz.norm_key(record.get("serial_number"))
    record["_model_n"] = nz.norm_text(record.get("model"))
    record["_docref_n"] = nz.norm_key(record.get("document_ref"))
    record["_entryid_n"] = nz.norm_key(record.get("entry_id"))
    record["_date"] = (record.get("invoice_date") or record.get("acquisition_date")
                       or record.get("entry_date"))
