"""Fixed-asset reconciliation toolkit (inventory, invoices, register, GL)."""

__version__ = "1.0.0"
