"""Invoice folder inventory and optional text-layer extraction.

The agent (vision model) is the primary OCR/IDP layer: it opens each scan,
transcribes it into the canonical invoice schema and records the page and a
confidence score. These helpers cover the mechanical part: hashing, page
counts, text-layer detection and duplicate detection, so a 500-invoice folder
can be triaged before extraction.
"""
from __future__ import annotations

import csv
import hashlib
import os

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}
DOCUMENT_EXTENSIONS = IMAGE_EXTENSIONS | {".pdf"}

COLUMNS = ["fichier", "chemin", "type", "pages", "taille_ko", "sha256",
           "doublon_sha256", "statut_extraction", "facture_no", "fournisseur",
           "date_facture", "total", "confiance", "commentaire"]


def _sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _pdf_info(path):
    try:
        from pypdf import PdfReader
    except ImportError:
        return None, "inconnu"
    try:
        reader = PdfReader(path)
        pages = len(reader.pages)
        text = ""
        for page in reader.pages[:5]:
            text += page.extract_text() or ""
        kind = "pdf_texte" if len(text.strip()) > 80 else "pdf_scan"
        return pages, kind
    except Exception as error:  # damaged or encrypted PDF
        return None, "illisible:%s" % type(error).__name__


def pdf_text(path, max_pages=50):
    """Best-effort text extraction; returns '' for scans without a text layer."""
    try:
        from pypdf import PdfReader
    except ImportError:
        return ""
    try:
        reader = PdfReader(path)
        parts = []
        for page in reader.pages[:max_pages]:
            parts.append(page.extract_text() or "")
        return "\n".join(parts)
    except Exception:
        return ""


def write_manifest(folder, output):
    folder = os.path.abspath(folder)
    if not os.path.isdir(folder):
        raise SystemExit("Dossier introuvable: %s" % folder)
    rows = []
    hashes = {}
    summary = {"files": 0, "text_pdf": 0, "scans": 0, "images": 0, "duplicates": 0}
    for root, _dirs, files in os.walk(folder):
        for name in sorted(files):
            extension = os.path.splitext(name)[1].lower()
            if extension not in DOCUMENT_EXTENSIONS:
                continue
            path = os.path.join(root, name)
            digest = _sha256(path)
            size_kb = round(os.path.getsize(path) / 1024.0, 1)
            pages, kind = (None, "image")
            if extension == ".pdf":
                pages, kind = _pdf_info(path)
            duplicate = ""
            if digest in hashes:
                duplicate = "OUI — identique à %s" % hashes[digest]
                summary["duplicates"] += 1
            else:
                hashes[digest] = os.path.relpath(path, folder)
            if kind == "pdf_texte":
                summary["text_pdf"] += 1
            elif kind in ("pdf_scan", "inconnu"):
                summary["scans"] += 1
            elif kind == "image":
                summary["images"] += 1
            summary["files"] += 1
            rows.append([
                os.path.relpath(path, folder), path, kind, pages or "", size_kb,
                digest, duplicate, "À extraire", "", "", "", "", "", "",
            ])
    with open(output, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle, delimiter=";")
        writer.writerow(COLUMNS)
        writer.writerows(rows)
    return output, summary
