"""Canonical data model for fixed-asset reconciliation.

Every source is mapped onto a flat, source-specific table. Client files are
never edited: values are read, coerced and tagged with provenance so the
audit trail points back to the original file, sheet and row.
"""
from __future__ import annotations

# Field spec: (canonical name, human label FR/EN, aliases, required, kind)
# kind: text | date | money | qty | enum

SPECS = {
    "inventory": {
        "label": "Inventaire physique / Physical inventory",
        "required": ["description"],
        "fields": {
            "asset_code": (
                "Code actif / N° inventaire",
                ["code actif", "code", "n inventaire", "numero inventaire", "no inventaire",
                 "code immo", "code immobilisation", "code materiel", "tag", "asset id",
                 "asset code", "identifiant", "reference", "ref", "numero"],
                False, "text"),
            "site": (
                "Site",
                ["site", "localisation", "emplacement", "agence", "succursale", "bureau",
                 "location", "site name", "ville"],
                False, "text"),
            "location": (
                "Emplacement détaillé",
                ["batiment", "salle", "etage", "service", "departement", "room", "floor",
                 "emplacement detaille", "zone"],
                False, "text"),
            "family": (
                "Famille",
                ["famille", "categorie", "category", "type", "nature", "groupe", "family",
                 "class", "classe"],
                False, "text"),
            "description": (
                "Désignation",
                ["designation", "libelle", "description", "intitule", "materiel",
                 "asset description", "nom", "name", "bien", "article"],
                True, "text"),
            "brand": (
                "Marque",
                ["marque", "brand", "fabricant", "manufacturer", "make"],
                False, "text"),
            "model": (
                "Modèle",
                ["modele", "model", "reference constructeur", "ref constructeur",
                 "modele type", "type modele"],
                False, "text"),
            "serial_number": (
                "N° de série",
                ["numero de serie", "n serie", "no serie", "serial", "serial number",
                 "imei", "vin", "chassis", "matricule"],
                False, "text"),
            "colour": (
                "Couleur",
                ["couleur", "color", "colour"],
                False, "text"),
            "condition": (
                "État",
                ["etat", "condition", "etat general", "physical condition",
                 "statut physique", "etat du bien"],
                False, "text"),
            "quantity": (
                "Quantité",
                ["quantite", "qte", "qty", "nombre", "nb", "quantity",
                 "nombre d unites", "unites"],
                False, "qty"),
            "acquisition_date": (
                "Date d'acquisition",
                ["date acquisition", "date d acquisition", "date achat", "purchase date",
                 "acquisition date", "date entree"],
                False, "date"),
            "count_date": (
                "Date d'inventaire",
                ["date inventaire", "date de comptage", "date recensement", "count date",
                 "date constat", "date du comptage"],
                False, "date"),
            "label_status": (
                "Étiquette",
                ["etiquette", "presence etiquette", "tag status", "plaque",
                 "numero plaque", "marquage"],
                False, "text"),
            "notes": (
                "Observations",
                ["observations", "commentaire", "comment", "notes", "remarque",
                 "observation"],
                False, "text"),
        },
    },
    "invoices": {
        "label": "Factures fournisseurs / Supplier invoices",
        "required": ["invoice_number", "supplier", "invoice_date", "description",
                     "quantity", "line_total"],
        "fields": {
            "invoice_number": (
                "N° facture",
                ["numero facture", "n facture", "no facture", "num facture",
                 "facture n", "ref facture", "invoice number", "invoice no",
                 "invoice num", "piece", "numero piece"],
                True, "text"),
            "supplier": (
                "Fournisseur",
                ["fournisseur", "supplier", "vendeur", "vendor", "raison sociale",
                 "emetteur", "nom fournisseur"],
                True, "text"),
            "invoice_date": (
                "Date facture",
                ["date facture", "date de facture", "invoice date", "date emission",
                 "date d emission"],
                True, "date"),
            "delivery_date": (
                "Date de livraison",
                ["date livraison", "date de livraison", "delivery date",
                 "date reception", "date de reception", "bon de livraison", "bl"],
                False, "date"),
            "description": (
                "Désignation ligne",
                ["designation", "description", "libelle", "article", "produit", "item",
                 "description article", "designation article"],
                True, "text"),
            "brand": (
                "Marque",
                ["marque", "brand", "fabricant", "manufacturer"],
                False, "text"),
            "model": (
                "Modèle / référence",
                ["modele", "model", "reference", "ref article", "reference article",
                 "ref produit"],
                False, "text"),
            "quantity": (
                "Quantité",
                ["quantite", "qte", "qty", "nombre", "quantity", "nb", "unites"],
                True, "qty"),
            "unit_price": (
                "Prix unitaire",
                ["prix unitaire", "pu", "prix unitaire ht", "unit price", "p u",
                 "prix u", "prix unitaire hors taxe"],
                False, "money"),
            "line_total": (
                "Montant ligne",
                ["montant", "montant ligne", "total ligne", "total ht", "montant ht",
                 "line total", "prix total", "total", "montant hors taxe"],
                True, "money"),
            "invoice_total": (
                "Total facture",
                ["total facture", "montant facture", "total ttc", "net a payer",
                 "invoice total", "grand total", "total general", "montant total"],
                False, "money"),
            "tax_amount": (
                "TVA",
                ["tva", "montant tva", "vat", "tax", "taxe"],
                False, "money"),
            "currency": (
                "Devise",
                ["devise", "currency", "monnaie"],
                False, "text"),
            "line_no": (
                "N° ligne",
                ["n ligne", "ligne", "line", "line no", "position", "no ligne"],
                False, "text"),
            "po_number": (
                "Bon de commande",
                ["bon de commande", "n bc", "no bc", "bc", "purchase order", "po",
                 "commande", "ref commande"],
                False, "text"),
            "asset_code": (
                "Code actif",
                ["code actif", "code immo", "n inventaire", "asset code",
                 "code immobilisation"],
                False, "text"),
            "source_file": (
                "Fichier source",
                ["fichier source", "source file", "fichier", "file", "nom fichier"],
                False, "text"),
            "source_page": (
                "Page",
                ["page", "page source", "source page"],
                False, "text"),
            "extraction_confidence": (
                "Confiance extraction",
                ["confiance", "confidence", "score extraction", "confidence score"],
                False, "text"),
            "review_status": (
                "Statut revue",
                ["statut revue", "review status", "verification", "statut verification"],
                False, "text"),
        },
    },
    "register": {
        "label": "Registre des immobilisations / Fixed-asset register",
        "required": ["asset_code", "description", "acquisition_date", "cost"],
        "fields": {
            "asset_code": (
                "Code immobilisation",
                ["code immobilisation", "code immo", "code actif", "n inventaire",
                 "numero inventaire", "asset code", "asset id", "code", "reference"],
                True, "text"),
            "description": (
                "Désignation",
                ["designation", "libelle", "description", "intitule", "materiel",
                 "asset description", "nom", "name", "bien"],
                True, "text"),
            "family": (
                "Famille",
                ["famille", "categorie", "category", "type", "nature", "groupe",
                 "family", "class"],
                False, "text"),
            "brand": (
                "Marque",
                ["marque", "brand", "fabricant", "manufacturer"],
                False, "text"),
            "model": (
                "Modèle",
                ["modele", "model", "reference constructeur", "ref constructeur"],
                False, "text"),
            "serial_number": (
                "N° de série",
                ["numero de serie", "n serie", "serial", "serial number", "imei",
                 "vin", "chassis", "matricule"],
                False, "text"),
            "quantity": (
                "Quantité",
                ["quantite", "qte", "qty", "nombre", "nb", "quantity"],
                False, "qty"),
            "acquisition_date": (
                "Date d'acquisition",
                ["date acquisition", "date d acquisition", "date achat",
                 "purchase date", "acquisition date", "date entree"],
                True, "date"),
            "in_service_date": (
                "Mise en service",
                ["date mise en service", "date de mise en service", "mise en service",
                 "in service date", "commissioning date"],
                False, "date"),
            "supplier": (
                "Fournisseur",
                ["fournisseur", "supplier", "vendeur", "vendor"],
                False, "text"),
            "invoice_number": (
                "N° facture",
                ["numero facture", "n facture", "no facture", "facture",
                 "invoice number", "invoice no", "piece justificative", "ref facture"],
                False, "text"),
            "cost": (
                "Valeur brute",
                ["valeur", "valeur d acquisition", "cout", "cout d acquisition",
                 "montant", "prix", "cost", "acquisition cost", "valeur brute",
                 "montant ht", "prix d achat"],
                True, "money"),
            "currency": (
                "Devise",
                ["devise", "currency"],
                False, "text"),
            "site": (
                "Site",
                ["site", "localisation", "emplacement", "agence", "location"],
                False, "text"),
            "depreciation_method": (
                "Méthode d'amortissement",
                ["methode amortissement", "mode amortissement", "depreciation method",
                 "methode", "mode"],
                False, "text"),
            "useful_life_years": (
                "Durée de vie (ans)",
                ["duree de vie", "duree amortissement", "duree", "useful life",
                 "duree en annees", "duree de vie en annees"],
                False, "qty"),
            "accumulated_depreciation": (
                "Amortissements cumulés",
                ["amortissements cumules", "amort cumules", "accumulated depreciation",
                 "depreciation cumulee", "amortissement cumule"],
                False, "money"),
            "net_book_value": (
                "Valeur nette comptable",
                ["valeur nette comptable", "vnc", "net book value", "valeur residuelle",
                 "valeur nette"],
                False, "money"),
            "status": (
                "Statut",
                ["statut", "status", "situation", "etat du bien", "statut actif"],
                False, "text"),
            "disposal_date": (
                "Date de cession",
                ["date cession", "date de cession", "date sortie", "date de sortie",
                 "disposal date", "date mise au rebut"],
                False, "date"),
            "gl_account": (
                "Compte comptable",
                ["compte comptable", "compte", "account", "gl account",
                 "compte immobilisation", "numero compte"],
                False, "text"),
        },
    },
    "gl": {
        "label": "Grand livre / General ledger",
        "required": ["entry_date", "account_code", "description"],
        "fields": {
            "entry_id": (
                "N° écriture",
                ["n ecriture", "numero ecriture", "no ecriture", "entry id", "piece",
                 "numero piece", "ecriture", "id", "numero"],
                False, "text"),
            "journal": (
                "Journal",
                ["journal", "journal code", "type journal", "code journal"],
                False, "text"),
            "account_code": (
                "Compte",
                ["compte", "numero compte", "n compte", "account", "account code",
                 "compte general", "compte gl", "compte comptable"],
                True, "text"),
            "account_label": (
                "Libellé compte",
                ["libelle compte", "intitule compte", "account label", "account name",
                 "libelle du compte"],
                False, "text"),
            "entry_date": (
                "Date écriture",
                ["date ecriture", "date comptable", "date operation", "entry date",
                 "date", "date de saisie", "date ecriture comptable"],
                True, "date"),
            "document_ref": (
                "Référence pièce",
                ["reference document", "ref document", "piece jointe", "n piece",
                 "no piece", "document", "doc ref", "reference", "facture",
                 "reference piece"],
                False, "text"),
            "description": (
                "Libellé écriture",
                ["libelle", "description", "designation", "intitule", "wording",
                 "libelle ecriture", "libelle operation"],
                True, "text"),
            "debit": (
                "Débit",
                ["debit", "montant debit", "debit fcfa", "debit xof"],
                False, "money"),
            "credit": (
                "Crédit",
                ["credit", "montant credit", "credit fcfa", "credit xof"],
                False, "money"),
            "supplier": (
                "Tiers / Fournisseur",
                ["fournisseur", "supplier", "tiers", "beneficiaire", "client"],
                False, "text"),
            "invoice_number": (
                "N° facture",
                ["n facture", "numero facture", "no facture", "facture", "invoice",
                 "invoice number", "ref facture"],
                False, "text"),
            "asset_code": (
                "Code immobilisation",
                ["code immo", "code actif", "n inventaire", "asset code",
                 "code immobilisation"],
                False, "text"),
            "fiscal_year": (
                "Exercice",
                ["exercice", "annee", "fiscal year", "year", "exercice comptable"],
                False, "text"),
            "posting_status": (
                "Statut",
                ["statut", "etat", "posting status", "valide", "lettrage", "statut piece"],
                False, "text"),
        },
    },
}

SOURCE_LABELS = {
    "inventory": "Inventaire physique",
    "invoices": "Factures",
    "register": "Registre",
    "gl": "Grand livre",
}

SOURCE_COLORS = {
    "inventory": "FFE2EFDA",
    "invoices": "FFFFF2CC",
    "register": "FFDDEBF7",
    "gl": "FFEDE7F6",
}

STATUS_LABELS = {
    "FULLY_RECONCILED": "Rapproché",
    "PARTIALLY_RECONCILED": "Partiellement rapproché",
    "DISCREPANCY": "Écart",
    "MISSING_DOCUMENT": "Document / écriture manquant",
    "MANUAL_REVIEW": "Vérification manuelle",
    "UNMATCHED_INVOICE": "Facture non rapprochée",
    "UNMATCHED_GL": "Écriture non rapprochée",
}

STATUS_COLORS = {
    "FULLY_RECONCILED": "FFC6EFCE",
    "PARTIALLY_RECONCILED": "FFFFEB9C",
    "DISCREPANCY": "FFFFC7CE",
    "MISSING_DOCUMENT": "FFF8CBAD",
    "MANUAL_REVIEW": "FFD9E1F2",
    "UNMATCHED_INVOICE": "FFE4DFEC",
    "UNMATCHED_GL": "FFE4DFEC",
}

SEVERITY_LABELS = {"H": "Élevée", "M": "Moyenne", "L": "Faible"}
SEVERITY_COLORS = {"H": "FFFFC7CE", "M": "FFFFEB9C", "L": "FFE2EFDA"}
