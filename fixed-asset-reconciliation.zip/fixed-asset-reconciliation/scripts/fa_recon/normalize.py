"""Text, date, money and quantity normalisation.

The reconciliation must survive real client data: accented French labels,
brand aliases (HP / Hewlett-Packard), "1 250 000 FCFA" amounts, dates as
dd/mm/yy or Excel serials, and descriptions written differently on an
invoice, the register and the physical count.
"""
from __future__ import annotations

import datetime as _dt
import re
import unicodedata
from difflib import SequenceMatcher

# ---------------------------------------------------------------- text

_WS = re.compile(r"\s+")
_NON_WORD = re.compile(r"[^A-Z0-9]+")


def strip_accents(text):
    if not isinstance(text, str):
        text = str(text)
    return "".join(c for c in unicodedata.normalize("NFKD", text)
                   if not unicodedata.combining(c))


def norm_text(value):
    """Uppercase, accent-free, single-spaced, punctuation -> space."""
    if value is None:
        return ""
    text = strip_accents(value)
    text = text.upper().replace("N°", " N ").replace("Nº", " N ")
    text = _NON_WORD.sub(" ", text)
    return _WS.sub(" ", text).strip()


def norm_key(value):
    """Compact key for identifiers (invoice numbers, asset codes)."""
    return _NON_WORD.sub("", strip_accents("" if value is None else str(value)).upper())


def compact_code(value):
    """Identifiers keep their separators visible but comparable."""
    text = norm_text(value)
    return text.replace(" ", "")


# Brand aliases. Keys are normalised spellings; values are canonical brands.
BRAND_ALIASES = {
    "HEWLETT PACKARD": "HP",
    "HEWLETT PACKARD HP": "HP",
    "HEWLETT PACKARD COMPANY": "HP",
    "HP INC": "HP",
    "HPI": "HP",
    "LENOVO GROUP": "LENOVO",
    "SAMSUNG ELECTRONICS": "SAMSUNG",
    "DELL INC": "DELL",
    "DELL COMPUTER": "DELL",
    "CANON INC": "CANON",
    "SEIKO EPSON": "EPSON",
    "EPSON FRANCE": "EPSON",
    "MICROSOFT CORPORATION": "MICROSOFT",
    "APPLE INC": "APPLE",
    "ACER INC": "ACER",
    "ASUSTEK": "ASUS",
    "PHILIPS ELECTRONICS": "PHILIPS",
    "LG ELECTRONICS": "LG",
    "BROTHER INDUSTRIES": "BROTHER",
    "KYOCERA MITA": "KYOCERA",
    "RICOH COMPANY": "RICOH",
    "TOSHIBA CORPORATION": "TOSHIBA",
    "HUAWEI TECHNOLOGIES": "HUAWEI",
    "XEROX CORPORATION": "XEROX",
    "SCHNEIDER ELECTRIC": "SCHNEIDER",
    "SIEMENS AG": "SIEMENS",
    "TOYOTA MOTOR": "TOYOTA",
    "MITSUBISHI ELECTRIC": "MITSUBISHI",
    "YAMAHA MOTOR": "YAMAHA",
    "PEUGEOT AUTOMOBILES": "PEUGEOT",
    "RENAULT SAS": "RENAULT",
    "MERCEDES BENZ": "MERCEDES",
    "MERCEDES-BENZ": "MERCEDES",
    "GENERAL ELECTRIC": "GE",
}


def brand_key(value):
    text = norm_text(value)
    if not text:
        return ""
    return BRAND_ALIASES.get(text, text.split(" ")[0] if len(text.split(" ")) == 1 else text)


# Description synonyms: canonical token sequences (applied before tokenising).
# Longest phrases first so "ORDINATEUR PORTABLE" wins over "ORDINATEUR".
SYNONYMS = [
    ("ORDINATEUR PORTABLE", "LAPTOP"),
    ("ORDINATEUR DE BUREAU", "DESKTOP"),
    ("PC PORTABLE", "LAPTOP"),
    ("PC DE BUREAU", "DESKTOP"),
    ("UNITE CENTRALE", "DESKTOP"),
    ("IMPRIMANTE LASER", "PRINTER"),
    ("IMPRIMANTE JET ENCRE", "PRINTER"),
    ("PHOTOCOPIEUR", "COPIER"),
    ("PHOTOCOPIEUSE", "COPIER"),
    ("COPIEUR", "COPIER"),
    ("CLIMATISEUR", "AC"),
    ("CLIMATISATION", "AC"),
    ("GROUPE ELECTROGENE", "GENERATOR"),
    ("GROUPE ELECTROGENE", "GENERATOR"),
    ("MOTEUR ELECTROGENE", "GENERATOR"),
    ("ONDULEUR", "UPS"),
    ("ALIMENTATION SANS INTERRUPTION", "UPS"),
    ("FAUTEUIL", "CHAIR"),
    ("CHAISE", "CHAIR"),
    ("SIEGE", "CHAIR"),
    ("FAUTEUILS", "CHAIR"),
    ("CHAISES", "CHAIR"),
    ("TABLE", "DESK"),
    ("BUREAU", "DESK"),
    ("ARMOIRE", "CABINET"),
    ("ETAGERE", "SHELF"),
    ("RAYONNAGE", "SHELF"),
    ("VEHICULE", "VEHICLE"),
    ("VOITURE", "VEHICLE"),
    ("AUTOMOBILE", "VEHICLE"),
    ("MOTOCYCLE", "MOTORCYCLE"),
    ("TELEPHONE", "PHONE"),
    ("TELEPHONE MOBILE", "PHONE"),
    ("TELEVISEUR", "TV"),
    ("TELEVISION", "TV"),
    ("REFRIGERATEUR", "FRIDGE"),
    ("FRIGO", "FRIDGE"),
    ("ORDINATEUR", "COMPUTER"),
    ("ECRAN", "MONITOR"),
    ("MONITEUR", "MONITOR"),
    ("SCANNER", "SCANNER"),
    ("VIDEOPROJECTEUR", "PROJECTOR"),
    ("PROJECTEUR", "PROJECTOR"),
    ("SERVEUR", "SERVER"),
    ("SWITCH", "SWITCH"),
    ("ROUTEUR", "ROUTER"),
    ("FIREWALL", "FIREWALL"),
    ("GROUPE", "GENERATOR"),
    ("MACHINE A LAVER", "WASHER"),
    ("MACHINE A COUDRE", "SEWING MACHINE"),
    ("TRONCONNEUSE", "CHAINSAW"),
    ("TONDEUSE", "MOWER"),
    ("ECHOGRAPHE", "ULTRASOUND"),
    ("AUTOCLAVE", "AUTOCLAVE"),
    ("GROUPE FROID", "CHILLER"),
    ("CAMION", "TRUCK"),
    ("CAMIONNETTE", "VAN"),
    ("MOTO", "MOTORCYCLE"),
    ("LAPTOP", "LAPTOP"),
    ("NOTEBOOK", "LAPTOP"),
    ("DESKTOP", "DESKTOP"),
    ("PRINTER", "PRINTER"),
    ("CHAIR", "CHAIR"),
    ("SEAT", "CHAIR"),
]

NOISE = {
    "DE", "DU", "DES", "LA", "LE", "LES", "L", "D", "A", "AU", "AUX", "ET", "EN",
    "POUR", "SUR", "AVEC", "UN", "UNE", "U", "X", "N", "NEUF", "NEUVE", "NEUFS",
    "DIVERS", "DIVERSE", "ARTICLE", "ARTICLES", "EQUIPEMENT", "EQUIPEMENTS",
    "MATERIEL", "MATERIELS", "PIECE", "PIECES", "PCS", "UNITE", "UNITES", "LOT",
    "OF", "THE", "AND", "WITH", "FOR", "NEW", "ITEM", "ITEMS", "ASSET",
}

_SYNONYM_RE = [(re.compile(r"\b" + re.escape(src) + r"\b"), dst) for src, dst in
               sorted(SYNONYMS, key=lambda p: -len(p[0]))]


def desc_tokens(value):
    """Canonical tokens used for fuzzy description comparison."""
    text = norm_text(value)
    for pattern, replacement in _SYNONYM_RE:
        text = pattern.sub(replacement, text)
    tokens = [t for t in text.split(" ") if t and t not in NOISE]
    # Keep order but remove duplicates while preserving stable comparison.
    seen, out = set(), []
    for token in tokens:
        if token not in seen:
            seen.add(token)
            out.append(token)
    return out


def desc_key(value):
    return " ".join(desc_tokens(value))


def token_set_ratio(a_tokens, b_tokens):
    """Similarity that tolerates extra words and word order."""
    if not a_tokens or not b_tokens:
        return 0.0
    a, b = set(a_tokens), set(b_tokens)
    inter = len(a & b)
    if inter == 0:
        return 0.0
    containment = inter / min(len(a), len(b))
    jaccard = inter / len(a | b)
    return 0.65 * containment + 0.35 * jaccard


def similarity(a, b):
    """Blended description similarity in [0, 1]."""
    if isinstance(a, str):
        a = desc_tokens(a)
    if isinstance(b, str):
        b = desc_tokens(b)
    if not a or not b:
        return 0.0
    seq = SequenceMatcher(None, " ".join(a), " ".join(b)).ratio()
    return max(token_set_ratio(a, b), 0.55 * seq + 0.45 * token_set_ratio(a, b))


def text_similarity(a, b):
    if not a or not b:
        return 0.0
    na, nb = norm_text(a), norm_text(b)
    if na == nb:
        return 1.0
    return SequenceMatcher(None, na, nb).ratio()


# ---------------------------------------------------------------- dates

FRENCH_MONTHS = {
    "JANVIER": 1, "FEVRIER": 2, "MARS": 3, "AVRIL": 4, "MAI": 5, "JUIN": 6,
    "JUILLET": 7, "AOUT": 8, "SEPTEMBRE": 9, "OCTOBRE": 10, "NOVEMBRE": 11,
    "DECEMBRE": 12,
}

_DATE_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%Y/%m/%d",
                 "%d/%m/%y", "%d-%m-%y", "%m/%d/%Y", "%Y%m%d", "%d %m %Y",
                 "%d %B %Y", "%d %b %Y")


def parse_date(value):
    """Return (date|None, ambiguous:bool, error:str|None)."""
    if value is None or value == "":
        return None, False, None
    if isinstance(value, _dt.datetime):
        return value.date(), False, None
    if isinstance(value, _dt.date):
        return value, False, None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        # Excel serial date (1900 date system).
        if 20000 <= float(value) <= 80000:
            base = _dt.date(1899, 12, 30)
            return base + _dt.timedelta(days=int(value)), False, None
        return None, False, "valeur numérique non datable"
    text = strip_accents(str(value)).strip()
    text = _WS.sub(" ", text)
    # 12 janvier 2024 / 12 JAN 2024
    match = re.match(r"^(\d{1,2})[ /-]([A-Za-z]+)[ /-](\d{2,4})$", text)
    if match:
        month = FRENCH_MONTHS.get(match.group(2).upper())
        if month:
            year = int(match.group(3))
            year = year + 2000 if year < 100 else year
            try:
                return _dt.date(year, month, int(match.group(1))), False, None
            except ValueError:
                return None, False, "date invalide"
    cleaned = text.replace("T00:00:00", "").split(" ")[0]
    for fmt in _DATE_FORMATS:
        try:
            return _dt.datetime.strptime(cleaned, fmt).date(), False, None
        except ValueError:
            continue
    return None, False, "format de date non reconnu"


# ---------------------------------------------------------------- money

_CURRENCY_WORDS = re.compile(
    r"(FCFA|XOF|CFA|F\s?CFA|EUR|EUROS?|USD|DOLLARS?|GBP|£|€|\$)", re.I)


def parse_money(value):
    """Return (float|None, ambiguous:bool, error:str|None).

    Handles '1 250 000', '1.250.000', '1,250,000.00', '1 250 000 FCFA',
    '(12 500)' for negatives and trailing currency codes.
    """
    if value is None or value == "":
        return None, False, None
    if isinstance(value, bool):
        return None, False, "valeur booléenne"
    if isinstance(value, (int, float)):
        return float(value), False, None
    text = strip_accents(str(value)).strip()
    negative = text.startswith("(") and text.endswith(")")
    text = _CURRENCY_WORDS.sub("", text).strip()
    text = text.replace(" ", "").replace("\u00a0", "").replace("'", "")
    text = text.replace("−", "-").replace("–", "-")
    text = re.sub(r"[^0-9,.\-]", "", text)
    if text in ("", "-", ".", ","):
        return None, False, "montant vide"
    ambiguous = False
    if "," in text and "." in text:
        if text.rfind(",") > text.rfind("."):
            text = text.replace(".", "").replace(",", ".")
        else:
            text = text.replace(",", "")
    elif "," in text:
        parts = text.split(",")
        if len(parts) > 2:
            # 1,250,000 -> thousands separators
            text = "".join(parts)
        elif (len(parts[-1]) == 3 and len(parts[0]) <= 3
              and parts[0] not in ("0", "") and len(parts) == 2):
            # 1,250 is far more likely thousands than 1.25 in FCFA context
            text = "".join(parts)
            ambiguous = True
        else:
            text = text.replace(",", ".")
    elif "." in text:
        parts = text.split(".")
        if len(parts) > 2:
            text = "".join(parts)
        elif (len(parts[-1]) == 3 and len(parts[0]) <= 3
              and parts[0] not in ("0", "")):
            # 1.250 -> thousands
            text = "".join(parts)
            ambiguous = True
    try:
        number = float(text)
    except ValueError:
        return None, ambiguous, "montant non reconnu"
    if negative:
        number = -abs(number)
    return round(number, 2), ambiguous, None


_QTY_UNITS = re.compile(
    r"(UNITES?|U|PCS|PIECES?|ENSEMBLE|LOTS?|KG|L|M|M2|M3|SACS?|CARTONS?)\s*$", re.I)


def parse_qty(value):
    """Return (float|None, error|None). Blank is None, never silently 1."""
    if value is None or value == "":
        return None, None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return float(value), None
    text = strip_accents(str(value)).strip().replace(",", ".")
    text = _QTY_UNITS.sub("", text).strip()
    text = re.sub(r"[^0-9.\-]", "", text)
    if text in ("", "-", "."):
        return None, "quantité non reconnue"
    try:
        return float(text), None
    except ValueError:
        return None, "quantité non reconnue"


# ---------------------------------------------------------------- misc

def money_equal(a, b, tol_abs=1000.0, tol_pct=0.005):
    if a is None or b is None:
        return None
    diff = abs(a - b)
    return diff <= max(tol_abs, tol_pct * max(abs(a), abs(b)))


def days_between(a, b):
    if a is None or b is None:
        return None
    return (a - b).days


def fiscal_year_of(date):
    return date.year if date else None
