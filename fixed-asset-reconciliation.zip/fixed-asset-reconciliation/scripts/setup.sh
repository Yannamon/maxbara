#!/bin/sh
# Create an isolated environment for the reconciliation toolkit.
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
./.venv/bin/python -m pip install --quiet --upgrade pip
./.venv/bin/pip install --quiet -r requirements.txt
echo "Environnement prêt: $(pwd)/.venv"
echo "Exécuter: ./.venv/bin/python reconcile.py demo -o /tmp/rapprochement_demo"
