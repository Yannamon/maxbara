---
name: Fixed-Asset Reconciliation
description: Reconcile a fixed-asset audit file across physical inventory, supplier invoices (including scanned PDFs and photos), fixed-asset register and general ledger; extract invoices, match assets across the four sources, flag discrepancies and produce a consolidated audit workbook.
---

# Fixed-Asset Reconciliation

Reconcile the four sources of a fixed-asset audit over a five-year window:

1. **Physical inventory** — Excel list of assets counted at each site.
2. **Supplier invoices** — scanned PDFs, photos, or a pre-extracted table.
3. **Fixed-asset register** — the client's list of capitalised assets.
4. **General ledger** — fixed-asset transactions for the same period.

The engine matches assets across all four, explains every match, flags
discrepancies and produces an audit workbook with the sources side by side.

## Non-negotiable core

This is the scope to insist on with a developer or an internal team. A tool
that only compares four Excel files does **not** meet it.

- Read **scanned invoices** (PDF and image), not just spreadsheets.
- Extract invoice number, supplier, invoice date, delivery date, description,
  brand, quantity, unit price, line total and invoice total — with page and
  confidence for every line.
- Identify the **same asset** across four sources even when the description,
  brand spelling, quantity split or date differs.
- Suggest possible matches instead of silently dropping uncertain records.
- Flag missing register entries, missing physical assets, missing invoices,
  missing ledger entries, quantity/amount/description/date variances,
  duplicates and unmatched transactions.
- Produce one consolidated table with the four sources side by side and a
  status per asset: fully reconciled, partially reconciled, discrepancy,
  missing document, manual verification.
- Keep every figure traceable to the source file, sheet, row or invoice page.

The bundled engine implements this workflow. The agent is the OCR/IDP layer
for scans; the scripts handle normalization, matching, rules and reporting.

## Before you start

Collect and confirm:

| Item | Why it matters |
| --- | --- |
| Client name, period start/end (5 fiscal years) | Scope and cut-off tests |
| Sites and site naming convention | Physical existence and site mismatch |
| Currency (default FCFA) and VAT rate | Amount comparison (18% UEMOA default) |
| Materiality / amount tolerance | What counts as an amount discrepancy |
| Intangible assets policy | Software/licences are not physically countable |
| Disposals and assets acquired before the period | Avoid false "not found" findings |
| Invoice folder and whether scans have a text layer | Extraction workload |
| Whether the register is complete or only additions | Interpretation of "not in register" |

Ask for files **as they are**. Do not ask the client to retype invoices or
reshape spreadsheets; the engine maps common French and English headers and
the agent reads the scans.

## Setup

```sh
SKILL=~/.config/opencode/skills/fixed-asset-reconciliation
sh "$SKILL/scripts/setup.sh"
PY="$SKILL/scripts/.venv/bin/python"
```

Python 3.9+ is enough. `openpyxl` is required; `pypdf` is optional and only
used to count pages and detect text layers.

Check the install with the built-in demo:

```sh
"$PY" "$SKILL/scripts/reconcile.py" demo -o /tmp/fa_demo
```

## Workflow

### 1. Create or map the input files

```sh
"$PY" "$SKILL/scripts/reconcile.py" templates -o ./modeles
```

Four workbooks are created: `modele_inventory.xlsx`, `modele_invoices.xlsx`,
`modele_register.xlsx`, `modele_gl.xlsx`. Each has a data sheet, a field
notice with accepted French/English headers, and an example sheet.

Prefer the client's original files when their headers are recognisable. The
loader auto-detects headers in the first 25 rows and maps aliases such as
`N° inventaire`, `Code immo`, `Désignation`, `Valeur brute`, `N° facture`,
`Date écriture`, `Débit`. Unrecognised columns are listed in
`07_Qualite_donnees`; they are never silently dropped.

### 2. Triage the invoice folder

```sh
"$PY" "$SKILL/scripts/reconcile.py" manifest ./factures -o ./manifeste_factures.csv
```

The manifest records, for every PDF/image: type (text PDF, scanned PDF,
image), page count, size, SHA-256 and exact duplicates. Process it before
extraction:

- identical hashes → one scan, not two invoices;
- text PDFs → text extraction is possible, but still verify line layout;
- scans/photos → vision extraction page by page;
- encrypted or damaged files → list as exceptions, do not guess.

### 3. Extract the invoices

Use your file-reading/vision capability to open each PDF or image. Work page
by page and transcribe into the canonical invoice table. The full protocol,
field rules, confidence rubric and JSON schema are in
`references/invoice-extraction.md`.

Minimum per line:

```
invoice_number, supplier, invoice_date, delivery_date, description, brand,
model, quantity, unit_price, line_total, invoice_total, currency, line_no,
po_number, asset_code, source_file, source_page, extraction_confidence,
review_status
```

Rules that protect the audit:

- Copy what is printed. Do not "improve" the description during extraction;
  normalization happens later and must remain reversible.
- One row per invoice line. Repeat header fields on every line.
- If a field is illegible or absent, leave it blank and flag it. Never invent
  an amount, a date or a supplier.
- Record the source file and page for every line.
- Set `extraction_confidence`: 0.97+ typed text, 0.90–0.96 clear scan,
  0.75–0.89 readable but noisy, below 0.75 manual re-read.
- Check quantity × unit price = line total, and sum of lines = invoice total.
  Report differences; do not correct them silently.
- Credit notes, delivery notes and pro-forma invoices are not purchase
  invoices: flag them, do not net them without instruction.

Validate the extraction:

```sh
"$PY" "$SKILL/scripts/reconcile.py" check-invoices ./factures_extraites.xlsx
```

The command reports missing columns/values, arithmetic errors, duplicates and
low-confidence lines. Fix the extraction file, not the client's documents.

### 4. Run the reconciliation

```sh
"$PY" "$SKILL/scripts/reconcile.py" run \
  --inventory ./inventaire.xlsx \
  --invoices ./factures_extraites.xlsx \
  --register ./registre.xlsx \
  --gl ./grand_livre.xlsx \
  --period-start 2021-01-01 \
  --period-end 2025-12-31 \
  --client "CLIENT SARL" \
  --output ./sortie
```

Optional: `--config seuils.json` to change matching thresholds, amount
tolerances, VAT rate assumptions or the minimum extraction confidence. The
defaults are in `references/matching-and-discrepancies.md`.

Output:

```
sortie/
  rapprochement_immobilisations_YYYYMMDD_HHMM.xlsx
  ecarts.csv
  verification_manuelle.csv
  factures_non_rapprochees.csv
  ecritures_non_rapprochees.csv
  doublons.csv
```

### 5. Read the workbook in order

| Sheet | What to do |
| --- | --- |
| `00_Lisez-moi` | Check scope, files, hashes, thresholds, limitations |
| `01_Tableau_de_bord` | Counts, value at risk, tie-out by fiscal year, top codes |
| `02_Rapprochement` | The four sources side by side, status, score, action |
| `03_Ecarts` | Every finding with expected/observed value and evidence |
| `04_Verification_manuelle` | Ambiguous or low-confidence items to accept/reject |
| `05_Doublons` | Duplicate invoices, asset codes, serials, ledger entries |
| `06_Factures_non_rapprochees` | Invoices and GL entries without an asset |
| `07_Qualite_donnees` | Import anomalies: columns, dates, amounts, missing fields |
| `08_Journal_extraction` | Invoice line provenance and confidence |
| `09_Tracabilite` | File hashes, parameters, run metadata |

Do not treat an automatic match as validated. The review queue exists because
fuzzy matching is probabilistic and extraction can be wrong. Record decisions
in the `Décision` and `Commentaire` columns; keep the workbook as audit
evidence.

### 6. Quality gates before delivering

- **Coverage**: every page in the manifest has been processed or explicitly
  listed as an exception.
- **Extraction**: critical-field completeness ≥ 98%; arithmetic consistency
  ≥ 99%; low-confidence lines all reviewed.
- **Matching**: auto-match rate is plausible for the data quality (typically
  70–85%); review queue 10–25%; unmatched items investigated, not ignored.
- **Tie-out**: invoice total, register cost and GL debits are compared by
  fiscal year; differences are explained by identified items (cut-off,
  missing documents, amount variances).
- **High-severity findings**: each has a decision or a documented follow-up.
- **Traceability**: every line in `02_Rapprochement` points to a file and row
  or an invoice page.
- **No silent loss**: every source row appears in a cluster or in an
  unmatched/quality sheet.

If a gate fails, fix the input or extraction and rerun. Do not hand-edit the
output workbook and call it reconciled.

### 7. Deliver

Give the client/auditor:

1. the workbook (the working paper);
2. the discrepancy CSV for follow-up;
3. the extraction journal (what was read, from which page, with what
   confidence);
4. a short narrative: scope, sources, method, key findings, limitations,
   items requiring client response.

## Reading a status

| Status | Meaning | Typical action |
| --- | --- | --- |
| `FULLY_RECONCILED` | Four sources agree within tolerance | Sample-check evidence |
| `PARTIALLY_RECONCILED` | Minor variance only (description, brand, site, date, cut-off) | Confirm with client |
| `DISCREPANCY` | Existence, quantity or amount issue | Investigate and document |
| `MISSING_DOCUMENT` | Asset or invoice lacks a document or ledger entry | Request/obtain evidence |
| `MANUAL_REVIEW` | Ambiguous match or low-confidence extraction | Accept/reject in review queue |
| `UNMATCHED_INVOICE` | Invoice line with no asset | Identify the asset or expense |
| `UNMATCHED_GL` | Ledger entry with no asset | Identify the asset or reclassify |

The full code list is in `references/matching-and-discrepancies.md`.

## Excel or dedicated software?

Short answer: **Excel alone cannot meet the requirement; a thin dedicated
tool with Excel as input/output is the right target.** Pure Excel cannot read
scans reliably, cannot do explainable cross-source entity resolution, and has
no audit trail or review workflow. Power Query and Copilot help with clean
tables, not with scanned invoices and fuzzy asset identity.

Use this skill's Python engine as the phase-1 prototype. Move to a small web
application when the work becomes recurring, multi-client, multi-user, or
when invoice volume and evidence retention make a folder of workbooks unsafe.
The full assessment, architecture, effort ranges, acceptance criteria and
questions to ask a developer are in `references/build-vs-excel.md` and
`references/developer-brief.md`.

## Guardrails

- **Never invent data.** Blank plus a flag is always better than a plausible
  guess. This applies to extraction, matching and reporting.
- **Never modify client files.** Write to a separate output directory.
- **Every match must be explainable.** A score without components and source
  evidence is not audit evidence.
- **Human validation is mandatory** for fuzzy matches, low-confidence scans,
  duplicates and high-severity findings.
- **Confidentiality.** Invoices and ledgers contain supplier and payroll-adjacent
  data. Keep files local, encrypt storage, limit access, and follow the firm's
  retention policy.
- **No accounting advice beyond the evidence.** The tool reconciles documents;
  it does not decide the accounting treatment or the audit opinion.
- **State limitations.** Illegible scans, missing pages, incomplete registers
  and incompatible periods must be disclosed, not smoothed over.

## Files

```
SKILL.md
references/
  build-vs-excel.md             Excel vs dedicated software, architecture, effort
  developer-brief.md            One-page brief + acceptance tests + red flags
  data-model.md                 Canonical schema, aliases, normalization
  invoice-extraction.md         OCR/vision protocol, confidence, prompt, validation
  matching-and-discrepancies.md Scoring, thresholds, codes, edge cases
  deliverable-spec.md           Workbook structure and review workflow
scripts/
  setup.sh                      Create .venv and install dependencies
  reconcile.py                  CLI: templates, manifest, check-invoices, run, demo
  fa_recon/                     Engine (loaders, normalize, matching, rules, report)
```
